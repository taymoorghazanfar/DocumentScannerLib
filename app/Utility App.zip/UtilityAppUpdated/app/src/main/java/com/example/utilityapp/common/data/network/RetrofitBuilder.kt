package com.example.utilityapp.common.data.network

import com.example.utilityapp.translator.common.data.network.api.TranslatorApiService
import com.example.utilityapp.weather.data.network.api.WeatherApiService
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitBuilder {

    private fun getRetrofit(baseUrl: String, forTranslation: Boolean): Retrofit {

        val okHttpClient = OkHttpClient().newBuilder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
//            .addConverterFactory(GsonConverterFactory.create())
            .addConverterFactory(
                if (forTranslation) ScalarsConverterFactory.create()
                else GsonConverterFactory.create()
            )
            .client(okHttpClient)
            .build() //Doesn't require the adapter
    }

    fun getTranslatorApiService(baseUrl: String): TranslatorApiService {

        return getRetrofit(baseUrl, true).create(TranslatorApiService::class.java)
    }

    fun getWeatherApiService(baseUrl: String): WeatherApiService {

        return getRetrofit(baseUrl, false).create(WeatherApiService::class.java)
    }
}