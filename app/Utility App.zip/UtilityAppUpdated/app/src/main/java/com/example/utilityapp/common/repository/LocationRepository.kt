package com.example.utilityapp.common.repository

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.core.app.ActivityCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class LocationRepository(context: Context) : LocationListener {
    private val context: Context
    private val locationLiveData: MutableLiveData<Location?> = MutableLiveData<Location?>()
    private val lastLocationLiveData: MutableLiveData<Location?> = MutableLiveData<Location?>()
    private val locationManager: LocationManager

    init {

        this.context = context
        locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    fun requestCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(
                context,
                "android.permission.ACCESS_FINE_LOCATION"
            ) == 0 || ActivityCompat.checkSelfPermission(
                context, "android.permission.ACCESS_COARSE_LOCATION"
            ) == 0
        ) {

            val lastKnownLocation = locationManager.getLastKnownLocation("network")

            if (lastKnownLocation != null) {

                locationLiveData.postValue(lastKnownLocation)

            } else {

                locationManager.requestLocationUpdates("network", 0, 0.0f, this)
            }

        } else {
            locationLiveData.postValue(null)
        }
    }

    fun getLastKnownLocation() {

        lastLocationLiveData.value = locationManager.getLastKnownLocation("network")
    }

    fun getLocationLiveData(): LiveData<Location?> {
        return locationLiveData
    }

    fun getLastLocationLiveData(): LiveData<Location?> {
        return lastLocationLiveData
    }

    override fun onLocationChanged(location: Location) {

        locationLiveData.postValue(location)
    }
}
