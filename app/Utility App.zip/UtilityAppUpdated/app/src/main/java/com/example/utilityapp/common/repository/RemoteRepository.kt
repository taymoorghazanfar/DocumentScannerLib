package com.example.utilityapp.common.repository

import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.BuildConfig
import com.example.utilityapp.R
import com.example.utilityapp.common.data.RemoteConfig
import com.google.firebase.ktx.Firebase
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfigSettings

class RemoteRepository {

    private var remoteConfig: FirebaseRemoteConfig
    private var remoteLiveData: MutableLiveData<Boolean> = MutableLiveData()

    init {

        remoteConfig = getFirebaseRemoteConfig()
    }

    private fun getFirebaseRemoteConfig(): FirebaseRemoteConfig {

        val remoteConfig = Firebase.remoteConfig

        val configSettings = remoteConfigSettings {

            minimumFetchIntervalInSeconds = if (BuildConfig.DEBUG) {

                0 // Kept 0 for quick debug

            } else {

                60 * 60 // Change this based on your requirement
            }
        }

        remoteConfig.setConfigSettingsAsync(configSettings)
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

        remoteConfig.fetchAndActivate().addOnCompleteListener {
//            Log.d(TAG, "addOnCompleteListener")
        }

        return remoteConfig
    }

    fun getRemoteLiveData(): MutableLiveData<Boolean> {

        return this.remoteLiveData
    }

    fun getRemoteData() {

        remoteConfig
            .fetchAndActivate()
            .addOnCompleteListener {

                val data = HashMap<String, String>()

                data["translation_api_url"] = remoteConfig.getString("translation_api_url")
                data["weather_api_image_url"] = remoteConfig.getString("weather_api_image_url")
                data["weather_api_key"] = remoteConfig.getString("weather_api_key")
                data["weather_api_url"] = remoteConfig.getString("weather_api_url")

                for (key in data.keys.toList()) {

                    if (data[key] == null) {

                        remoteLiveData.value = false
                        break
                    }
                }

                RemoteConfig.translationApiUrl = data["translation_api_url"]
                RemoteConfig.weatherApiUrl = data["weather_api_url"]
                RemoteConfig.weatherApiKey = data["weather_api_key"]
                RemoteConfig.weatherApiImageUrl = data["weather_api_image_url"]

                remoteLiveData.value = true
            }
            .addOnFailureListener {

                remoteLiveData.value = false
            }
    }
}