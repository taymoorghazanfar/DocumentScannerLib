package com.example.utilityapp.weather.ui.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.utilityapp.R
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.weather.model.ForecastData
import java.text.SimpleDateFormat

class RecyclerAdapterForecast(
    val context: Context,
) :
    RecyclerView.Adapter<RecyclerAdapterForecast.ViewHolder>() {

    private val data = ArrayList<ForecastData>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val textViewDay: TextView = itemView.findViewById(R.id.text_view_day)
        val textViewTemperature: TextView = itemView.findViewById(R.id.text_view_weather)
        val textViewHigh: TextView = itemView.findViewById(R.id.text_view_high)
        val textViewLow: TextView = itemView.findViewById(R.id.text_view_low)
        val imageViewIcon: ImageView = itemView.findViewById(R.id.image_view_icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_item_forecast_weather,
            parent, false
        )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val forecast = data[position]

        holder.textViewTemperature.text = forecast.title
        holder.textViewDay.text = forecast.day
        holder.textViewHigh.text = forecast.high
        holder.textViewLow.text = forecast.low

        Glide
            .with(context)
            .load(RemoteConfig.weatherApiImageUrl + forecast.icon)
            .into(holder.imageViewIcon)
    }

    override fun getItemCount(): Int {

        return data.size
    }

    @SuppressLint("SimpleDateFormat")
    fun updateData(newList: List<ForecastData>) {

        data.clear()
        data.addAll(newList)

        data.sortedByDescending { forecast ->

            val sdf = SimpleDateFormat("EEE")
            sdf.parse(forecast.day)?.time
        }

        notifyItemRangeChanged(0, data.size)
    }
}