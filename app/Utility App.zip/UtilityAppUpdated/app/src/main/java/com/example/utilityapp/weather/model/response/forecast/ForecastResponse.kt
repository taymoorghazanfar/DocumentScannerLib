package com.example.utilityapp.weather.model.response.forecast

import com.example.utilityapp.weather.model.response.weather.WeatherResponse
import com.google.gson.annotations.SerializedName

class ForecastResponse {

    @SerializedName("cod")
    var cod: Int

    @SerializedName("message")
    var message: Int

    @SerializedName("count")
    var count: Int

    @SerializedName("list")
    var list: List<WeatherItem>

    constructor(cod: Int, message: Int, count: Int, list: List<WeatherItem>) {
        this.cod = cod
        this.message = message
        this.count = count
        this.list = list
    }
}