package com.example.utilityapp.common.viewmodel

import android.app.Application
import android.content.Context
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.utilityapp.common.repository.LocationRepository

class LocationViewModel(application: Application?) : AndroidViewModel(application!!) {

    private lateinit var locationLiveData: LiveData<Location?>
    private lateinit var locationRepository: LocationRepository

    fun init(context: Context) {

        locationRepository = LocationRepository(context)
        locationLiveData = locationRepository.getLocationLiveData()
    }

    fun requestCurrentLocation() {
        locationRepository.requestCurrentLocation()
    }

    fun getLocationLiveData(): LiveData<Location?> {
        return locationLiveData
    }
}
