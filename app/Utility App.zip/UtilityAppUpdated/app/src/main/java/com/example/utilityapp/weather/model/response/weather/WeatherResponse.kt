package com.example.utilityapp.weather.model.response.weather

import com.example.utilityapp.weather.model.response.*
import com.google.gson.annotations.SerializedName

class WeatherResponse {

    @SerializedName("coord")
    var coordinates: Coordinates

    @SerializedName("weather")
    var weather: List<Weather>

    @SerializedName("base")
    var base: String

    @SerializedName("main")
    var main: Main

    @SerializedName("visibility")
    var visibility: Long

    @SerializedName("wind")
    var wind: Wind

    @SerializedName("rain")
    var rain: Rain

    @SerializedName("clouds")
    var clouds: Clouds

    @SerializedName("dt")
    var timestamp: Long

    @SerializedName("sys")
    var sys: Sys

    @SerializedName("timezone")
    var timezone: Long

    @SerializedName("id")
    var id: Long

    @SerializedName("name")
    var name: String

    @SerializedName("cod")
    var code: Int

    constructor(
        coordinates: Coordinates,
        weather: List<Weather>,
        base: String,
        main: Main,
        visibility: Long,
        wind: Wind,
        rain: Rain,
        clouds: Clouds,
        timestamp: Long,
        sys: Sys,
        timezone: Long,
        id: Long,
        name: String,
        code: Int
    ) {
        this.coordinates = coordinates
        this.weather = weather
        this.base = base
        this.main = main
        this.visibility = visibility
        this.wind = wind
        this.rain = rain
        this.clouds = clouds
        this.timestamp = timestamp
        this.sys = sys
        this.timezone = timezone
        this.id = id
        this.name = name
        this.code = code
    }
}