package com.example.utilityapp.qrscanner.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.utilityapp.qrscanner.data.database.dao.BarcodesDao
import com.example.utilityapp.qrscanner.model.MBarcode

@Database(entities = [MBarcode::class], version = 10, exportSchema = false)

abstract class BarcodesDatabase : RoomDatabase() {

    abstract fun getBarcodesDao(): BarcodesDao

    companion object {

        @Volatile
        private var INSTANCE: BarcodesDatabase? = null

        fun getDatabase(context: Context): BarcodesDatabase {

            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BarcodesDatabase::class.java,
                    "barcodes_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                // return instance
                instance
            }
        }
    }
}