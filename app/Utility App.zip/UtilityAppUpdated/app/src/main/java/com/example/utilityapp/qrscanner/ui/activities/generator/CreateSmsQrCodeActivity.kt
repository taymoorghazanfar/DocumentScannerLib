package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateSmsQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreateSmsQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateSmsQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateSmsQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Message"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent = Intent(this@CreateSmsQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }

        viewModel.getAllBarcodes().observe(this@CreateSmsQrCodeActivity) {

            Log.d("gen_size", "initViewModel: " + it.size)
        }
    }

    private fun createQrCode() {

        val phoneNumber: String = binding.content.editTextPhoneNumber.text.toString().trim()
        val message: String = binding.content.editTextMessage.text.toString().trim()

        var isInputValid = true

        if (phoneNumber.isEmpty()) {

            binding.content.editTextPhoneNumber.error = "Phone number is required"
            isInputValid = false
        }

        if (message.isEmpty()) {

            binding.content.editTextMessage.error = "Message is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createSmsQrCode(1,phoneNumber, message)
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}