package com.example.utilityapp.pdfreader.repository

import androidx.lifecycle.LiveData
import com.example.utilityapp.pdfreader.data.database.PdfsDao
import com.example.utilityapp.pdfreader.model.MPdf

class PdfsRepository(private val pdfsDao: PdfsDao) {

    val allPdfs: LiveData<List<MPdf>> = pdfsDao.getAllPdfs()

     fun insert(pdf: MPdf):Long {
        return pdfsDao.insert(pdf)
    }

    suspend fun deleteById(id: Int) {
        pdfsDao.deleteById(id)
    }

    suspend fun update(pdf: MPdf) {
        pdfsDao.update(pdf)
    }

    fun getPdf(uri: String): MPdf {

        return pdfsDao.getPdf(uri)
    }
}