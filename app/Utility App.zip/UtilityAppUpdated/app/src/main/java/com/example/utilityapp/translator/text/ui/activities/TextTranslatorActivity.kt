package com.example.utilityapp.translator.text.ui.activities

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.common.ui.views.CutCopyPasteEditText.OnCutCopyPasteListener
import com.example.utilityapp.databinding.ActivityTextTranslatorBinding
import com.example.utilityapp.translator.common.ui.adapters.LanguageAdapter
import com.example.utilityapp.translator.model.MTranslation
import com.example.utilityapp.translator.text.viewmodel.TextTranslatorViewModel
import com.example.utilityapp.translator.utils.LanguagesManager
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.math.BigInteger
import java.util.*

class TextTranslatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTextTranslatorBinding
    private lateinit var viewModel: TextTranslatorViewModel

    // variables
    private var sourceLanguageName: String? = null
    private var sourceLanguageCode: String? = null
    private var targetLanguageName: String? = null
    private var targetLanguageCode: String? = null

    // counters for spinners to avoid onCreate detection
    private var sourceClicks = 0;
    private var targetClicks = 0;
    private var currentSourceIndex = 0;
    private var currentTargetIndex = 0;
    private var fromSwap = false

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityTextTranslatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initHeader()

        val url = RemoteConfig.translationApiUrl

        initTranslatorViewModel(url!!)
    }

    private fun getData() {

        val text: String? = intent.getStringExtra("text")
        val output: String? = intent.getStringExtra("output")
        val sourceIndex: Int = intent.getIntExtra("source", -1)
        val targetIndex: Int = intent.getIntExtra("target", -1)
        val viewing: Boolean = intent.getBooleanExtra("viewing", false)

        if (text != null && sourceIndex != -1 && targetIndex != -1) {

            binding.header.textViewTitle.text =
                if (viewing) "Text Translator" else "Image Translator"

            binding.content.spinnerSourceLanguage.setSelection(sourceIndex)
            binding.content.spinnerTargetLanguage.setSelection(targetIndex)

            currentSourceIndex = binding.content.spinnerSourceLanguage.selectedItemPosition
            currentTargetIndex = binding.content.spinnerTargetLanguage.selectedItemPosition

            setSourceLanguage(
                binding.content.spinnerSourceLanguage.getItemAtPosition(sourceIndex).toString()
            )
            setTargetLanguage(
                binding.content.spinnerTargetLanguage.getItemAtPosition(targetIndex).toString()
            )

            binding.content.editTextInput.setText(text)

            if (!output.isNullOrEmpty()) {

                binding.content.textViewOutput.text = output

            } else {

                translateText()
            }
        }
    }

    private fun initHeader() {

        binding.header.textViewTitle.text = "Text Translator"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initTranslatorViewModel(url: String) {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[TextTranslatorViewModel::class.java]

        viewModel.init(url)

        viewModel
            .getTranslationLiveData()
            .observe(this@TextTranslatorActivity) { translation ->

                parseTranslationResponse(translation)
            }

        initViews()
        getData()
    }

    private fun parseTranslationResponse(translation: String?) {

        if (translation == null) {

            Snackbar
                .make(
                    binding.root,
                    "No internet connection or text is malformed",
                    Snackbar.LENGTH_SHORT
                )
                .show()

        } else {

            CoroutineScope(Dispatchers.IO).launch {

                val t = MTranslation(
                    0,
                    binding.header.textViewTitle.text.toString()
                        .replace(" Translator", ""),
                    currentSourceIndex,
                    currentTargetIndex,
                    binding.content.editTextInput.text.toString(),
                    translation,
                    com.example.utilityapp.common.util.StringUtils.getCurrentDateTime()
                )

                viewModel.save(t)
            }

            val animOut: Animation =
                AnimationUtils.loadAnimation(
                    this@TextTranslatorActivity,
                    com.example.utilityapp.R.anim.fade_out_fast
                )
            val animIn: Animation =
                AnimationUtils.loadAnimation(
                    this@TextTranslatorActivity,
                    com.example.utilityapp.R.anim.fade_in_fast
                )

            animOut.setAnimationListener(object :
                Animation.AnimationListener {
                override fun onAnimationStart(p0: Animation?) {

                }

                override fun onAnimationRepeat(p0: Animation?) {

                }

                override fun onAnimationEnd(p0: Animation?) {

                    binding.content.textViewOutput.text = translation

                    binding.content.scrollView.post {

                        binding.content.scrollView.fullScroll(View.FOCUS_DOWN);
                    }

                    binding.content.textViewOutput.startAnimation(animIn)
                }
            })

            binding.content.textViewOutput.startAnimation(animOut)
        }
    }

    private fun initViews() {

        binding.content.editTextInput.setOnCutCopyPasteListener(object : OnCutCopyPasteListener {
            override fun onCut() {
                // Do your onCut reactions
            }

            override fun onCopy() {
                // Do your onCopy reactions
            }

            override fun onPaste() {

                translateText()

                val imm =
                    getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(binding.root.windowToken, 0)
            }
        })

        // edit text
        binding.content.editTextInput.imeOptions = EditorInfo.IME_ACTION_DONE
        binding.content.editTextInput.setRawInputType(InputType.TYPE_CLASS_TEXT)
        binding.content.editTextInput.onSubmit { translateText() }
        binding.content.editTextInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {

                if (binding.content.editTextInput.text.toString().trim().isEmpty()) {

                    resetInputs()
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }
        })

        // source spinner
        val languageAdapterSource = LanguageAdapter(
            this@TextTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterSource.init(0)
        binding.content.spinnerSourceLanguage.adapter = languageAdapterSource
        binding.content.spinnerSourceLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (sourceClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == targetLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentSourceIndex = parent.selectedItemPosition
                            setSourceLanguage(selectedLanguage)
                        }
                    }
                }
            }

        // target spinner
        val languageAdapterTarget = LanguageAdapter(
            this@TextTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterTarget.init(1)
        binding.content.spinnerTargetLanguage.adapter = languageAdapterTarget
        binding.content.spinnerTargetLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (targetClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == sourceLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentTargetIndex = parent.selectedItemPosition
                            setTargetLanguage(selectedLanguage)

                            // translate text if input is not empty
                            if (binding.content.editTextInput.text.toString().trim().isNotEmpty()) {

                                if (!fromSwap) {

                                    translateText()

                                } else {

                                    fromSwap = false
                                }
                            }
                        }
                    }
                }
            }

        // switch language button
        binding.content.buttonSwitchLanguage.setOnClickListener {

            val sourceLanguageIndex = binding.content.spinnerSourceLanguage.selectedItemPosition
            val targetLanguageIndex = binding.content.spinnerTargetLanguage.selectedItemPosition

            swapLanguages(sourceLanguageIndex, targetLanguageIndex)
        }

        // initially setting languages
        binding.content.spinnerSourceLanguage.setSelection(0)
        binding.content.spinnerTargetLanguage.setSelection(1)

        currentSourceIndex = 0
        currentTargetIndex = 1

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }

    private fun setSourceLanguage(languageName: String) {

        sourceLanguageName = languageName
        sourceLanguageCode = LanguagesManager.languages[sourceLanguageName]

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewLanguage1FullName.text = sourceLanguageName
                binding.content.textViewLanguage1FullName.startAnimation(animIn)
            }
        })

        binding.content.textViewLanguage1FullName.startAnimation(animOut)
    }

    private fun setTargetLanguage(languageName: String) {

        targetLanguageName = languageName
        targetLanguageCode = LanguagesManager.languages[targetLanguageName]

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewLanguage2FullName.text = targetLanguageName
                binding.content.textViewLanguage2FullName.startAnimation(animIn)
            }
        })

        binding.content.textViewLanguage2FullName.startAnimation(animOut)
    }

    private fun swapLanguages(sourceLanguageIndex: Int, targetLanguageIndex: Int) {

        fromSwap = true

        resetInputs()

        currentSourceIndex = targetLanguageIndex
        currentTargetIndex = sourceLanguageIndex

        binding.content.spinnerSourceLanguage.setSelection(targetLanguageIndex)
        binding.content.spinnerTargetLanguage.setSelection(sourceLanguageIndex)

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }

    private fun translateText() {

        var inputText: String = binding.content.editTextInput.text.toString()

        if (inputText.isEmpty()) {

            binding.content.editTextInput.error = "Field is required"

        } else {

            inputText = inputText.replace("\n", " ")
            inputText = inputText.replace(".", " ")


            Log.d("input_text", "translateText: " + inputText)

            viewModel.getTranslation(sourceLanguageCode!!, targetLanguageCode!!, inputText)
        }
    }

    private fun resetInputs() {

        val animOut1: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_out_fast
            )
        val animIn1: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_in_fast
            )

        val animOut2: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_out_fast
            )
        val animIn2: Animation =
            AnimationUtils.loadAnimation(
                this@TextTranslatorActivity,
                com.example.utilityapp.R.anim.fade_in_fast
            )

        animOut2.setAnimationListener(object : Animation.AnimationListener {

            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.editTextInput.text.clear()
                binding.content.editTextInput.startAnimation(animIn2)
            }
        })

        binding.content.editTextInput.startAnimation(animOut2)

        animOut1.setAnimationListener(object : Animation.AnimationListener {

            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewOutput.text = ""
                binding.content.textViewOutput.startAnimation(animIn1)
            }
        })

        binding.content.textViewOutput.startAnimation(animOut1)
    }

    // extension
    private fun EditText.onSubmit(func: () -> Unit) {
        setOnEditorActionListener { _, actionId, _ ->

            if (actionId == EditorInfo.IME_ACTION_DONE) {
                func()
                val imm =
                    context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(windowToken, 0)
            }

            true
        }
    }
}