package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Rain {

    @SerializedName("1h")
    var oneHour: Double

    constructor(oneHour: Double) {
        this.oneHour = oneHour
    }
}