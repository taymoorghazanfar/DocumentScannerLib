package com.example.utilityapp.common.ui.views

import android.R
import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.widget.EditText

@SuppressLint("AppCompatCustomView")
class CutCopyPasteEditText : EditText {
    interface OnCutCopyPasteListener {
        fun onCut()
        fun onCopy()
        fun onPaste()
    }

    private var mOnCutCopyPasteListener: OnCutCopyPasteListener? = null

    /**
     * Set a OnCutCopyPasteListener.
     * @param listener
     */
    fun setOnCutCopyPasteListener(listener: OnCutCopyPasteListener?) {
        mOnCutCopyPasteListener = listener
    }

    /*
        Just the constructors to create a new EditText...
     */
    constructor(context: Context?) : super(context) {}
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {}
    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    ) {
    }

    /**
     *
     * This is where the "magic" happens.
     *
     * The menu used to cut/copy/paste is a normal ContextMenu, which allows us to
     * overwrite the consuming method and react on the different events.
     * @see [Original Implementation](http://grepcode.com/file/repository.grepcode.com/java/ext/com.google.android/android/2.3_r1/android/widget/TextView.java.TextView.onTextContextMenuItem%28int%29)
     */
    override fun onTextContextMenuItem(id: Int): Boolean {
        // Do your thing:
        val consumed = super.onTextContextMenuItem(id)
        when (id) {
            R.id.cut -> onCut()
            R.id.copy -> onCopy()
            R.id.paste -> onPaste()
        }
        return consumed
    }

    /**
     * Text was cut from this EditText.
     */
    fun onCut() {
        if (mOnCutCopyPasteListener != null) mOnCutCopyPasteListener!!.onCut()
    }

    /**
     * Text was copied from this EditText.
     */
    fun onCopy() {
        if (mOnCutCopyPasteListener != null) mOnCutCopyPasteListener!!.onCopy()
    }

    /**
     * Text was pasted into the EditText.
     */
    fun onPaste() {
        if (mOnCutCopyPasteListener != null) mOnCutCopyPasteListener!!.onPaste()
    }
}