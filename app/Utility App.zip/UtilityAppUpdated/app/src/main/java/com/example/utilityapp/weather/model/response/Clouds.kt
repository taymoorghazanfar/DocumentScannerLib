package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Clouds {

    @SerializedName("all")
    var all:Double

    constructor(all: Double) {
        this.all = all
    }
}