package com.example.utilityapp.translator.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translations")
class MTranslation:java.io.Serializable {

    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    var id: Int

    @ColumnInfo(name = "type")
    var type:String

    @ColumnInfo(name = "source_language_index")
    var sourceLanguageIndex:Int

    @ColumnInfo(name = "target_language_index")
    var targetLanguageIndex:Int

    @ColumnInfo(name = "text")
    var text: String

    @ColumnInfo(name = "output")
    var output: String

    @ColumnInfo(name = "date_created")
    var dateCreated: String

    constructor(
        id: Int,
        type: String,
        sourceLanguageIndex: Int,
        targetLanguageIndex: Int,
        text: String,
        output: String,
        dateCreated: String
    ) {
        this.id = id
        this.type = type
        this.sourceLanguageIndex = sourceLanguageIndex
        this.targetLanguageIndex = targetLanguageIndex
        this.text = text
        this.output = output
        this.dateCreated = dateCreated
    }
}