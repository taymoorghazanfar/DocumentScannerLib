package com.example.utilityapp.pdfreader.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recent_pdfs")
class MPdf : java.io.Serializable {

    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    var id: Int

    @ColumnInfo(name = "uri")
    var uri: String

    @ColumnInfo(name = "name")
    var name: String

    @ColumnInfo(name = "total_page")
    var totalPages: Int

    @ColumnInfo(name = "current_page")
    var currentPage: Int

    @ColumnInfo(name = "last_read_time")
    var lastReadTime: String

    constructor(
        id: Int,
        uri: String,
        name: String,
        totalPages: Int,
        currentPage: Int,
        lastReadTime: String
    ) {
        this.id = id
        this.uri = uri
        this.name = name
        this.totalPages = totalPages
        this.currentPage = currentPage
        this.lastReadTime = lastReadTime
    }
}
