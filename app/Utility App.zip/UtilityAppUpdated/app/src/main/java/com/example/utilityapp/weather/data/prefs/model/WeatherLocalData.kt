package com.example.utilityapp.weather.data.prefs.model

import com.example.utilityapp.weather.model.ForecastData
import com.example.utilityapp.weather.model.TodayData
import com.example.utilityapp.weather.model.WeatherData

class WeatherLocalData {

    var dateFetched:String
    var lat:Double
    var lng:Double
    var weatherData: WeatherData

    constructor(dateFetched: String, lat: Double, lng: Double, weatherData: WeatherData) {
        this.dateFetched = dateFetched
        this.lat = lat
        this.lng = lng
        this.weatherData = weatherData
    }
}