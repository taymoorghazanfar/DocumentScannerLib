package com.example.utilityapp.weather.data.prefs.model

import com.example.utilityapp.weather.model.ForecastData

class ForecastLocalData {

    var dateFetched: String
    var lat: Double
    var lng: Double
    var forecastData: List<ForecastData>

    constructor(dateFetched: String, lat: Double, lng: Double, forecastData: List<ForecastData>) {
        this.dateFetched = dateFetched
        this.lat = lat
        this.lng = lng
        this.forecastData = forecastData
    }
}