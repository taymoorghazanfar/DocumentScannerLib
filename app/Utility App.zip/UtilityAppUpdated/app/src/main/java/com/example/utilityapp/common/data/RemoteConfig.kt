package com.example.utilityapp.common.data

class RemoteConfig {

    companion object {

        var translationApiUrl: String? = null
        var weatherApiUrl: String? = null
        var weatherApiKey: String? = null
        var weatherApiImageUrl: String? = null
    }
}