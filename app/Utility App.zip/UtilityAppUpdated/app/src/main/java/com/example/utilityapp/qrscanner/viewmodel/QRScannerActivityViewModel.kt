package com.example.utilityapp.qrscanner.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.camera.core.ImageProxy
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.qrscanner.model.BarcodeScanResponse
import com.example.utilityapp.qrscanner.repository.QRScannerRepository
import com.google.mlkit.vision.common.InputImage

class QRScannerActivityViewModel(application: Application) : AndroidViewModel(application) {

    private var repository: QRScannerRepository = QRScannerRepository()
    private var imageScanLiveData: MutableLiveData<BarcodeScanResponse?> =
        repository.getImageScanLiveData()

    fun getImageScanLiveData(): MutableLiveData<BarcodeScanResponse?> {

        return imageScanLiveData
    }

    fun scanGalleryImage(context: Context, imageBitmap: Bitmap, isFromGallery: Boolean) {

        repository.scanImage(context, imageBitmap, isFromGallery)
    }

    fun processImage(
        inputImage: InputImage,
        imageProxy: ImageProxy? = null,
        isFromGallery: Boolean
    ) {

        repository.processImage(inputImage, imageProxy, isFromGallery)
    }
}