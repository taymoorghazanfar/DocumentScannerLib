package com.example.utilityapp.translator.voice.ui.activities

import android.Manifest
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.SpeechRecognizer
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.R
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityVoiceTranslatorBinding
import com.example.utilityapp.translator.common.ui.adapters.LanguageAdapter
import com.example.utilityapp.translator.model.MTranslation
import com.example.utilityapp.translator.utils.LanguagesManager
import com.example.utilityapp.translator.voice.viewmodel.VoiceTranslatorViewModel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.math.BigInteger
import java.util.*

class VoiceTranslatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVoiceTranslatorBinding
    private lateinit var viewModel: VoiceTranslatorViewModel

    private var sourceLanguageName: String? = null
    private var sourceLanguageCode: String? = null
    private var targetLanguageName: String? = null
    private var targetLanguageCode: String? = null

    private var sourceClicks = 0
    private var targetClicks = 0
    private var currentSourceIndex = 0
    private var currentTargetIndex = 0
    private var fromSwap = false

    private var isRecording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVoiceTranslatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()

        val url = RemoteConfig.translationApiUrl

        initViewModel(url!!)
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Voice Translator"

        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    fun initViewModel(url: String) {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[VoiceTranslatorViewModel::class.java]
        viewModel.init(this@VoiceTranslatorActivity, url)

        viewModel
            .getSpeechLiveData()
            .observe(this@VoiceTranslatorActivity) { speech ->

                parseSpeechResponse(speech)
            }

        viewModel
            .getTranslationLiveData()
            .observe(this@VoiceTranslatorActivity) { translation ->

                parseTranslationResponse(translation)
            }

        initViews()
    }

    private fun parseSpeechResponse(speech: String?) {

        if (speech == null) {

            stopRecording()

        } else {

            stopRecording()

            binding.content.textViewSpeech.text = speech

            translateText()
        }
    }

    private fun parseTranslationResponse(translation: String?) {

        if (translation == null) {

            Snackbar
                .make(
                    binding.root,
                    "No internet connection or text is malformed",
                    Snackbar.LENGTH_SHORT
                )
                .show()

        } else {

            CoroutineScope(Dispatchers.IO).launch {

                val t = MTranslation(
                    0,
                    "Voice",
                    currentSourceIndex,
                    currentTargetIndex,
                    binding.content.textViewSpeech.text.toString(),
                    translation,
                    StringUtils.getCurrentDateTime()
                )

                viewModel!!.save(t)
            }

            val animOut: Animation =
                AnimationUtils.loadAnimation(
                    this@VoiceTranslatorActivity,
                    R.anim.fade_out_fast
                )
            val animIn: Animation =
                AnimationUtils.loadAnimation(
                    this@VoiceTranslatorActivity,
                    R.anim.fade_in_fast
                )

            animOut.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(p0: Animation?) {

                }

                override fun onAnimationRepeat(p0: Animation?) {

                }

                override fun onAnimationEnd(p0: Animation?) {

                    binding.content.textViewOutput.text = translation

                    binding.content.scrollView.post {

                        binding.content.scrollView.fullScroll(View.FOCUS_DOWN);
                    }

                    binding.content.textViewOutput.startAnimation(animIn)
                }
            })

            binding.content.textViewOutput.startAnimation(animOut)
        }
    }

    private fun initViews() {

        binding.content.options.buttonRecord.setOnClickListener {

            if (isRecording) {

                if (viewModel != null) {

                    stopRecording()
                }

            } else {

                if (SpeechRecognizer.isRecognitionAvailable(this@VoiceTranslatorActivity)) {

                    if (isGoogleAppInstalled()) {

                        if (viewModel != null) {

                            startRecording()
                        }

                    } else {

                        Snackbar
                            .make(
                                binding.root,
                                "Install or enable Google App for speech recognition",
                                Snackbar.LENGTH_SHORT
                            )
                            .show()
                    }

                } else {

                    Snackbar
                        .make(
                            binding.root,
                            "Your device does not support speech to text service",
                            Snackbar.LENGTH_SHORT
                        )
                        .show()
                }
            }
        }

        // source spinner
        val languageAdapterSource = LanguageAdapter(
            this@VoiceTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterSource.init(0)
        binding.content.spinnerSourceLanguage.adapter = languageAdapterSource
        binding.content.spinnerSourceLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (sourceClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == targetLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentSourceIndex = parent.selectedItemPosition
                            setSourceLanguage(selectedLanguage)
                        }
                    }
                }
            }

        // target spinner
        val languageAdapterTarget = LanguageAdapter(
            this@VoiceTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterTarget.init(1)
        binding.content.spinnerTargetLanguage.adapter = languageAdapterTarget
        binding.content.spinnerTargetLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (targetClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == sourceLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentTargetIndex = parent.selectedItemPosition
                            setTargetLanguage(selectedLanguage)

                            // translate text if input is not empty
                            if (binding.content.textViewSpeech.text.toString().trim()
                                    .isNotEmpty()
                            ) {

                                if (!fromSwap) {

                                    translateText()

                                } else {

                                    fromSwap = false
                                }
                            }
                        }
                    }
                }
            }

        // switch language button
        binding.content.buttonSwitchLanguage.setOnClickListener {

            val sourceLanguageIndex = binding.content.spinnerSourceLanguage.selectedItemPosition
            val targetLanguageIndex = binding.content.spinnerTargetLanguage.selectedItemPosition

            swapLanguages(sourceLanguageIndex, targetLanguageIndex)
        }

        // initially setting languages
        binding.content.spinnerSourceLanguage.setSelection(0)
        binding.content.spinnerTargetLanguage.setSelection(1)

        currentSourceIndex = 0
        currentTargetIndex = 1

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }

    private fun isGoogleAppInstalled(): Boolean {

        val pkg = "com.google.android.googlequicksearchbox"

        return try {

            packageManager.getPackageInfo(pkg, 0);

            val ai: ApplicationInfo = packageManager.getApplicationInfo(pkg, 0);
            ai.enabled

        } catch (e: PackageManager.NameNotFoundException) {

            false
        }
    }

    private fun setSourceLanguage(languageName: String) {

        sourceLanguageName = languageName
        sourceLanguageCode = LanguagesManager.languages[sourceLanguageName]

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewLanguage1FullName.text = sourceLanguageName
                binding.content.textViewLanguage1FullName.startAnimation(animIn)
            }
        })

        binding.content.textViewLanguage1FullName.startAnimation(animOut)
    }

    private fun setTargetLanguage(languageName: String) {

        targetLanguageName = languageName
        targetLanguageCode = LanguagesManager.languages[targetLanguageName]

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewLanguage2FullName.text = targetLanguageName
                binding.content.textViewLanguage2FullName.startAnimation(animIn)
            }
        })

        binding.content.textViewLanguage2FullName.startAnimation(animOut)
    }

    private fun swapLanguages(sourceLanguageIndex: Int, targetLanguageIndex: Int) {

        fromSwap = true

        resetInputs()

        currentSourceIndex = targetLanguageIndex
        currentTargetIndex = sourceLanguageIndex

        binding.content.spinnerSourceLanguage.setSelection(targetLanguageIndex)
        binding.content.spinnerTargetLanguage.setSelection(sourceLanguageIndex)

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }

    private fun translateText() {

        var inputText: String = binding.content.textViewSpeech.text.toString()

        if (inputText.isNotEmpty()) {

            inputText = inputText.replace("\n", " ")
            inputText = inputText.replace(".", " ")

            viewModel!!.getTranslation(sourceLanguageCode!!, targetLanguageCode!!, inputText)
        }
    }

    private fun resetInputs() {

        val animOut1: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn1: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        val animOut2: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn2: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        animOut2.setAnimationListener(object : Animation.AnimationListener {

            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewSpeech.text = ""
                binding.content.textViewSpeech.startAnimation(animIn2)
            }
        })

        binding.content.textViewSpeech.startAnimation(animOut2)

        animOut1.setAnimationListener(object : Animation.AnimationListener {

            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.textViewOutput.text = ""
                binding.content.textViewOutput.startAnimation(animIn1)
            }
        })

        binding.content.textViewOutput.startAnimation(animOut1)
    }

    private fun startRecording() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            startListening()

        } else {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_CODE_AUDIO_PERMISSION
            )
        }
    }

    private fun startListening() {

        binding.content.textViewSpeech.text = ""
        binding.content.textViewOutput.text = ""
        isRecording = true
        toggleRecordingViews(true)
        viewModel!!.startRecording()
    }

    private fun stopRecording() {

        isRecording = false
        viewModel!!.stopRecording()
        toggleRecordingViews(false)
    }

    private fun toggleRecordingViews(isRecording: Boolean) {

        setRecorderButtonImage(if (isRecording) R.drawable.btn_recording_voice else R.drawable.btn_record)

        setRecorderImageVisibility(if (isRecording) View.VISIBLE else View.INVISIBLE)

        setRecorderStatusText(if (isRecording) "Recording" else "Tap to record")
    }

    private fun setRecorderButtonImage(drawable: Int) {

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding
                    .content
                    .options
                    .buttonRecord
                    .setImageDrawable(
                        ContextCompat.getDrawable(
                            this@VoiceTranslatorActivity, drawable
                        )
                    )

                binding
                    .content
                    .options
                    .buttonRecord.startAnimation(animIn)
            }
        })

        binding
            .content
            .options
            .buttonRecord.startAnimation(animOut)
    }

    private fun setRecorderImageVisibility(visibility: Int) {

        binding.content.options.waveLeft.visibility = visibility
        binding.content.options.waveRight.visibility = visibility

//        binding
//            .content
//            .options
//            .imageViewVoiceRecording
//            .animate()
//            .alpha(if (visibility == View.GONE) 0.0f else 1.0f)
//            .setListener(object : AnimatorListenerAdapter() {
//
//                override fun onAnimationEnd(animation: Animator) {
//                    super.onAnimationEnd(animation)
//                    binding.content.options.imageViewVoiceRecording.visibility = visibility
//                }
//            })
//
//        if (visibility == View.VISIBLE) {
//
//            val animation1 = AnimationUtils.loadAnimation(
//                applicationContext,
//                R.anim.blink_anim
//            )
//
//            binding
//                .content
//                .options
//                .imageViewVoiceRecording
//                .startAnimation(animation1)
//        }
    }

    private fun setRecorderStatusText(text: String) {

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_out_fast
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@VoiceTranslatorActivity,
                R.anim.fade_in_fast
            )

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                binding.content.options.textViewRecorderStatus.text = text
                binding.content.options.textViewRecorderStatus.startAnimation(animIn)
            }
        })

        binding.content.options.textViewRecorderStatus.startAnimation(animOut)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_AUDIO_PERMISSION) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                startListening()

            } else {

                Snackbar.make(
                    binding.root,
                    "Audio recording permission is required to use this feature",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        if (viewModel != null) {

            viewModel!!.destroy()
        }
    }

    companion object {

        var REQUEST_CODE_AUDIO_PERMISSION = 1
    }
}