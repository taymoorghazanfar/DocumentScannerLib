package com.example.utilityapp.pdfreader.data.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.utilityapp.pdfreader.model.MPdf

@Dao
interface PdfsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(pdf: MPdf):Long

    @Query("DELETE FROM recent_pdfs WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("Select * from recent_pdfs order by last_read_time DESC")
    fun getAllPdfs(): LiveData<List<MPdf>>

    @Query("Select * from recent_pdfs where uri=:uri LIMIT 1")
    fun getPdf(uri: String): MPdf

    @Update
    suspend fun update(pdf: MPdf)
}