package com.example.utilityapp.qrscanner.ui.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.utilityapp.R
import com.example.utilityapp.common.ui.decorators.SpacesItemDecoration
import com.example.utilityapp.databinding.ActivityQrHomeBinding
import com.example.utilityapp.qrscanner.model.MBarcode
import com.example.utilityapp.qrscanner.ui.activities.generator.QrGeneratorHomeActivity
import com.example.utilityapp.qrscanner.ui.activities.generator.QrGeneratorResultActivity
import com.example.utilityapp.qrscanner.ui.activities.scanner.QRScannerActivity
import com.example.utilityapp.qrscanner.ui.adapters.IBarcodeClickListener
import com.example.utilityapp.qrscanner.ui.adapters.RecyclerAdapterBarcodes
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel


private lateinit var binding: ActivityQrHomeBinding
private lateinit var viewModel: QrCodeViewModel

@SuppressLint("StaticFieldLeak")
private lateinit var adapter: RecyclerAdapterBarcodes

class QrHomeActivity : AppCompatActivity(), IBarcodeClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        setupViews()
        setupViewModel()
    }

    private fun setupViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getAllBarcodes().observe(this) { barcodes ->

            adapter.updateData(barcodes)
        }
    }

    private fun setupViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            startActivity(Intent(this@QrHomeActivity, QrGeneratorHomeActivity::class.java))
        }

        binding.content.buttonScanQr.setOnClickListener {

            startActivity(Intent(this@QrHomeActivity, QRScannerActivity::class.java))
        }

        binding.content.recyclerView.layoutManager = LinearLayoutManager(this)
        val spacingInPixels = resources.getDimensionPixelSize(com.example.utilityapp.R.dimen.recycler_view_spacing)
        binding.content.recyclerView.addItemDecoration(SpacesItemDecoration(spacingInPixels,0))
        adapter = RecyclerAdapterBarcodes(this, this)
        binding.content.recyclerView.adapter = adapter
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = getString(R.string.qr_scanner)

        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    override fun onBarcodeClick(barcode: MBarcode) {

        val i = Intent(this@QrHomeActivity, QrGeneratorResultActivity::class.java)
        i.putExtra("barcode", barcode)

        startActivity(i)
    }
}