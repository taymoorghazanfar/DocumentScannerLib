package com.example.utilityapp.translator.image.repository

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions


class ImageTranslatorRepository {

    private lateinit var recognizer: TextRecognizer
    private lateinit var textLiveData: MutableLiveData<String?>

    fun init() {

        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        textLiveData = MutableLiveData()
    }

    fun getTextLiveData(): MutableLiveData<String?> {

        return this.textLiveData
    }

    fun scanImage(bitmap: Bitmap) {

        val image = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->

                if (visionText == null) {

                    textLiveData.value = null

                } else {

                    processText(visionText)
                }
            }
            .addOnFailureListener { e ->

                e.printStackTrace()
                textLiveData.value = null
            }
    }

    fun scanImage(context: Context, uri: Uri) {

        val image = InputImage.fromFilePath(context, uri)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->

                if (visionText == null) {

                    textLiveData.value = null

                } else {

                    processText(visionText)
                }
            }
            .addOnFailureListener { e ->

                e.printStackTrace()
                textLiveData.value = null
            }
    }

    private fun processText(text: Text?) {

        val blocks = text!!.textBlocks

        if (blocks.size == 0) {

            textLiveData.value = null

        } else {

            Log.d("input_text", "processText: " + blocks.toString())

            var outputText = ""

            for (block in text.textBlocks) {

                outputText += block.text + " "
            }

            textLiveData.value = outputText
        }
    }
}