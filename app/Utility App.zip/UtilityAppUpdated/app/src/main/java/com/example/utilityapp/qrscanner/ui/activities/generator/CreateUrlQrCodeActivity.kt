package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateUrlQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreateUrlQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateUrlQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateUrlQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "URL"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateUrlQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val url: String = binding.content.editTextUrl.text.toString().trim()

        var isInputValid = true

        if (url.isEmpty()) {

            binding.content.editTextUrl.error = "Field is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createUrlQrCode(1,url)
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}