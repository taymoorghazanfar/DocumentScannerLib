package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.R
import com.example.utilityapp.databinding.ActivityCreateWifiQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel
import com.google.mlkit.vision.barcode.common.Barcode

class CreateWifiQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateWifiQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateWifiQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "WIFI"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateWifiQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val ssid: String = binding.content.editTextSsid.text.toString().trim()
        val password: String = binding.content.editTextPassword.text.toString().trim()
        val securityType: Int

        val checkedButtonId = binding.content.radioGroup.checkedRadioButtonId

        securityType = when (checkedButtonId) {

            R.id.radio_none -> {

                Barcode.WiFi.TYPE_OPEN

            }
            R.id.radio_wpa -> {

                Barcode.WiFi.TYPE_WPA

            }
            else -> {

                Barcode.WiFi.TYPE_WEP
            }
        }

        var isInputValid = true

        if (ssid.isEmpty()) {

            binding.content.editTextSsid.error = "Field is required"
            isInputValid = false
        }

        if (password.isEmpty() && securityType != Barcode.WiFi.TYPE_OPEN) {

            binding.content.editTextPassword.error = "Field is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createWifiQrCode(
                1,ssid, password, securityType
            )
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}