package com.example.utilityapp.translator.image.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.translator.image.repository.ImageTranslatorRepository

class ImageTranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var repository: ImageTranslatorRepository
    private lateinit var textLiveData: MutableLiveData<String?>

    fun init() {

        repository = ImageTranslatorRepository()
        repository.init()

        textLiveData = repository.getTextLiveData()
    }

    fun getTextLiveData(): MutableLiveData<String?> {

        return this.textLiveData
    }

    fun scanImage(bitmap: Bitmap) {

        repository.scanImage(bitmap)
    }

    fun scanImage(context: Context, uri: Uri) {

        repository.scanImage(context, uri)
    }
}