package com.example.utilityapp.translator.model.response

class ThirdArray {

    var data:ArrayList<TranslationResponse>?=null
}