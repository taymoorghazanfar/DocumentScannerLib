package com.example.utilityapp.translator.text.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.utilityapp.translator.common.data.database.TranslationsDatabase
import com.example.utilityapp.common.data.network.RetrofitBuilder
import com.example.utilityapp.translator.common.repository.TranslationsRepository
import com.example.utilityapp.translator.text.repository.TextTranslatorRepository
import com.example.utilityapp.translator.model.MTranslation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TextTranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var repository: TextTranslatorRepository
    private lateinit var translationsRepository: TranslationsRepository
    private lateinit var translationLiveData: MutableLiveData<String?>

    fun init(baseUrl:String) {

        repository = TextTranslatorRepository()
        repository.init(RetrofitBuilder.getTranslatorApiService(baseUrl))

        translationLiveData = repository.getTranslationLiveData()

        translationsRepository = TranslationsRepository(
            TranslationsDatabase.getDatabase(getApplication()).getTranslationsDao()
        )
    }

    fun getTranslationLiveData(): MutableLiveData<String?> {

        return this.translationLiveData
    }

    fun save(translation: MTranslation) =
        viewModelScope.launch(Dispatchers.IO) {
           translationsRepository.insert(translation)
        }

    fun getTranslation(
        sourceLanguageCode: String,
        targetLanguageCode: String,
        text: String

    ) {

        repository.getTranslation(sourceLanguageCode, targetLanguageCode, text)
    }
}