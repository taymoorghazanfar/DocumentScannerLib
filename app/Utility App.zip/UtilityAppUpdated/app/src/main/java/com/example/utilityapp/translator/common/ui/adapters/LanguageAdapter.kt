package com.example.utilityapp.translator.common.ui.adapters

import android.content.Context
import android.graphics.Point
import android.util.DisplayMetrics
import android.view.Display
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.utilityapp.R
import com.example.utilityapp.translator.utils.FlagManager
import com.example.utilityapp.translator.utils.LanguagesManager

class LanguageAdapter
    (context: Context, languages: List<String?>) :
    ArrayAdapter<String>(context, 0, languages) {

    private var layoutDirection: Int = 0

    fun init(layoutDirection: Int) {

        this.layoutDirection = layoutDirection
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {

        var convertView = convertView
        val language: String = getItem(position)!!
        val languageCode: String = LanguagesManager.languages[language]!!
        val flagCode = FlagManager.flags[languageCode]

        if (convertView == null) {

            convertView =
                LayoutInflater.from(context)
                    .inflate(R.layout.spinner_item_language_source, parent, false)
        }

        val imageViewFlag = convertView!!.findViewById<View>(R.id.image_view_flag) as ImageView

        Glide
            .with(context)
            .load("https://countryflagsapi.com/png/$flagCode")
            .centerCrop()
            .into(imageViewFlag);

//        Picasso
//            .get()
//            .load("https://countryflagsapi.com/png/$flagCode")
//            .resize(100, 100)
//            .into(imageViewFlag)

        val textViewName =
            convertView.findViewById<View>(R.id.text_view_language) as TextView
        textViewName.text = language

        val display: DisplayMetrics = context.resources.displayMetrics
        val width: Int = display.widthPixels

        convertView.minimumWidth = ((width * (60.0f / 100.0f)).toInt())

        return convertView
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        var convertView = convertView
        val language: String = getItem(position)!!
        val languageCode: String = LanguagesManager.languages[language]!!
        val flagCode = FlagManager.flags[languageCode]

        if (convertView == null) {

            convertView =
                LayoutInflater.from(context).inflate(
                    R.layout.spinner_item_language_preview, parent, false)
        }

        val imageViewFlag = convertView!!.findViewById<View>(R.id.image_view_flag) as ImageView
        Glide
            .with(context)
            .load("https://countryflagsapi.com/png/$flagCode")
            .centerCrop()
            .into(imageViewFlag);

        val textViewName =
            convertView.findViewById<View>(R.id.text_view_language) as TextView
        textViewName.text = if (language.length <= 3) language else language.substring(0, 3)

        return convertView
    }
}