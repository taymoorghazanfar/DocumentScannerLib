package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateEmailQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreateEmailQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateEmailQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateEmailQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Email"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateEmailQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val address: String = binding.content.editTextAddress.text.toString().trim()
        val subject: String = binding.content.editTextSubject.text.toString().trim()
        val body: String = binding.content.editTextBody.text.toString().trim()

        var isInputValid = true

        if (address.isEmpty()) {

            binding.content.editTextAddress.error = "Field is required"
            isInputValid = false
        }

        if (subject.isEmpty()) {

            binding.content.editTextSubject.error = "Field is required"
            isInputValid = false
        }

        if (body.isEmpty()) {

            binding.content.editTextBody.error = "Field is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createEmailQrCode(
                1,
                address,
                subject,
                body
            )
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}