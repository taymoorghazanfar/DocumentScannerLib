package com.example.utilityapp.common.util

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED
import android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER


class PackageUtils {

    companion object {

        fun getAppState(context: Context, packageName: String): Boolean {
            val packageManager: PackageManager = context.packageManager

            // Check if the App is installed or not first
            val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
            val list =
                packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            return if (list.isEmpty()) {
                // App is not installed
                false
            } else {

                // Check if the App is enabled/disabled
                val appEnabledSetting = packageManager.getApplicationEnabledSetting(packageName)
                appEnabledSetting != COMPONENT_ENABLED_STATE_DISABLED &&
                        appEnabledSetting != COMPONENT_ENABLED_STATE_DISABLED_USER
            }
        }
    }
}