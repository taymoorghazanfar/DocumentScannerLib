package com.example.utilityapp.translator.common.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.utilityapp.translator.model.MTranslation

@Database(entities = [MTranslation::class], version = 5, exportSchema = false)
abstract class TranslationsDatabase : RoomDatabase() {

    abstract fun getTranslationsDao(): TranslationsDao

    companion object {

        @Volatile
        private var INSTANCE: TranslationsDatabase? = null

        fun getDatabase(context: Context): TranslationsDatabase {

            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TranslationsDatabase::class.java,
                    "translations_database"
                ).fallbackToDestructiveMigration().build()

                INSTANCE = instance

                instance
            }
        }
    }
}