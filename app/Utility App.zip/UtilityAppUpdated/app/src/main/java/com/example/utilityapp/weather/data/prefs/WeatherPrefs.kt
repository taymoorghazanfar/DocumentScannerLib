package com.example.utilityapp.weather.data.prefs

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.utilityapp.weather.data.prefs.model.ForecastLocalData
import com.example.utilityapp.weather.data.prefs.model.TodayLocalData
import com.example.utilityapp.weather.data.prefs.model.WeatherLocalData

import com.google.gson.Gson

class WeatherPrefs {

    companion object {

        private const val PREFS_NAME = "weather_prefs"
        private const val SAVED_WEATHER_DATA = "saved_weather_data"
        private const val SAVED_TODAY_DATA = "saved_today_data"
        private const val SAVED_FORECAST_DATA = "saved_forecast_data"

        fun saveWeatherData(context: Context, data: WeatherLocalData) {

            val gson = Gson()
            val str = gson.toJson(data)

            Log.d("wtr_prefs", "saveWeatherData: " + str)

            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString(SAVED_WEATHER_DATA, str)
            editor.apply()
        }

        fun saveTodayData(context: Context, data: TodayLocalData) {

            val gson = Gson()
            val str = gson.toJson(data)
            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString(SAVED_TODAY_DATA, str)
            editor.apply()
        }

        fun saveForecastData(context: Context, data: ForecastLocalData) {

            val gson = Gson()
            val str = gson.toJson(data)
            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString(SAVED_FORECAST_DATA, str)
            editor.apply()
        }

        fun getWeatherLocalData(context: Context): WeatherLocalData? {

            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val gson = Gson()
            val weatherGson = sharedPreferences.getString(SAVED_WEATHER_DATA, null) ?: return null

            return gson.fromJson(weatherGson, WeatherLocalData::class.java)
        }

        fun getTodayLocalData(context: Context): TodayLocalData? {

            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val gson = Gson()
            val weatherGson = sharedPreferences.getString(SAVED_TODAY_DATA, null) ?: return null
            return gson.fromJson(weatherGson, TodayLocalData::class.java)
        }

        fun getForecastLocalData(context: Context): ForecastLocalData? {

            val sharedPreferences: SharedPreferences = context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val gson = Gson()
            val weatherGson = sharedPreferences.getString(SAVED_FORECAST_DATA, null) ?: return null

            for(f in gson.fromJson(weatherGson, ForecastLocalData::class.java).forecastData){

                Log.d("wtr_prefs", "getForecastLocalData: " + f.high)
                Log.d("wtr_prefs", "getForecastLocalData: " + f.low)
            }
            return gson.fromJson(weatherGson, ForecastLocalData::class.java)
        }
    }
}