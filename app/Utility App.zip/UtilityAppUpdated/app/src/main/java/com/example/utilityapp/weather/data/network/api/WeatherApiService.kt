package com.example.utilityapp.weather.data.network.api

import com.example.utilityapp.weather.model.response.forecast.ForecastResponse
import com.example.utilityapp.weather.model.response.weather.WeatherResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApiService {

//    https://api.openweathermap.org/data/2.5/weather?lat=21.4858&lon=39&appid=18583c85f3e50312c724975158de9636&units=metric

    @GET("weather")
    fun getWeather(

        @Query("lat") lat: Double,
        @Query("lon") lng: Double,
        @Query("units") units: String,
        @Query("appid") appId: String,

        ): Call<WeatherResponse>

//    https://api.openweathermap.org/data/2.5/forecast?lat=21.4858&lon=39.1925&appid=18583c85f3e50312c724975158de9636&units=metric

    @GET("forecast")
    fun getForecast(

        @Query("lat") lat: Double,
        @Query("lon") lng: Double,
        @Query("units") units: String,
        @Query("appid") appId: String,

        ): Call<ForecastResponse>
}