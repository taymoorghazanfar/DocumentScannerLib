package com.example.utilityapp.weather.ui.interfaces

interface BSPickLocationListener {

    fun onCurrentLocationSelected()
    fun onMapSelected()
    fun onDialogDismissed()
}