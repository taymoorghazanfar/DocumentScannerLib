package com.example.utilityapp.translator.common.data.network.api

import retrofit2.Call
import retrofit2.http.POST
import retrofit2.http.Query

interface TranslatorApiService {

    // https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=my+name+is+taymoor
    @POST("single")
    fun getTranslation(

        @Query("client") client: String,
        @Query("sl") sourceLanguageCode: String,
        @Query("tl") targetLanguageCode: String,
        @Query("dt") dataType: String,
        @Query("q") text: String,

        ): Call<String>
}