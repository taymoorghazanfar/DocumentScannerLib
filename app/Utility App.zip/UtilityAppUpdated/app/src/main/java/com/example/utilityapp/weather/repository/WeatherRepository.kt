package com.example.utilityapp.weather.repository

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.weather.data.network.api.WeatherApiService
import com.example.utilityapp.weather.data.prefs.WeatherPrefs
import com.example.utilityapp.weather.data.prefs.model.ForecastLocalData
import com.example.utilityapp.weather.data.prefs.model.TodayLocalData
import com.example.utilityapp.weather.data.prefs.model.WeatherLocalData
import com.example.utilityapp.weather.model.ForecastData
import com.example.utilityapp.weather.model.TodayData
import com.example.utilityapp.weather.model.WeatherData
import com.example.utilityapp.weather.model.response.forecast.ForecastResponse
import com.example.utilityapp.weather.model.response.weather.WeatherResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.math.ln

class WeatherRepository {

    private lateinit var api: WeatherApiService
    private lateinit var weatherLiveData: MutableLiveData<WeatherData?>
    private lateinit var todayLiveData: MutableLiveData<List<TodayData>?>
    private lateinit var forecastLiveData: MutableLiveData<List<ForecastData>?>

    fun init(apiService: WeatherApiService) {

        this.api = apiService
        weatherLiveData = MutableLiveData()
        todayLiveData = MutableLiveData()
        forecastLiveData = MutableLiveData()
    }

    fun getWeatherLiveData(): MutableLiveData<WeatherData?> {

        return this.weatherLiveData
    }

    fun getTodayLiveData(): MutableLiveData<List<TodayData>?> {

        return this.todayLiveData
    }

    fun getForecastLiveData(): MutableLiveData<List<ForecastData>?> {

        return this.forecastLiveData
    }

    fun getWeatherUpdates(context: Context, lat: Double, lng: Double, newUpdate: Boolean) {

        val localData = WeatherPrefs.getWeatherLocalData(context)
        val currentDate = StringUtils.getCurrentDate()

        if (!newUpdate && (localData != null &&
                    localData.dateFetched == currentDate)
        ) {

            Log.d("wtr_dta", "getWeatherUpdates: loading weather locally")

            weatherLiveData.value = localData.weatherData

        } else {

            CoroutineScope(Dispatchers.IO).launch {

                api
                    .getWeather(lat, lng, "metric", RemoteConfig.weatherApiKey!!)
                    .enqueue(object : Callback<WeatherResponse> {

                        override fun onResponse(
                            call: Call<WeatherResponse>,
                            response: Response<WeatherResponse>
                        ) {

                            if (response.isSuccessful && response.code() <= 299 && response.body() != null) {

                                parseWeatherResponse(context, response.body()!!, lat, lng)

                            } else {

                                CoroutineScope(Dispatchers.Main).launch {

                                    weatherLiveData.value = null
                                }
                            }
                        }

                        override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {

                            CoroutineScope(Dispatchers.Main).launch {

                                weatherLiveData.value = null
                            }
                        }
                    })
            }
        }
    }

    fun getForecastUpdates(context: Context, lat: Double, lng: Double, newUpdate: Boolean) {

        val todayData = WeatherPrefs.getTodayLocalData(context)
        val forecastData = WeatherPrefs.getForecastLocalData(context)
        val currentDate = StringUtils.getCurrentDate()

        if (!newUpdate && (todayData != null && forecastData != null &&
                    todayData.dateFetched == currentDate && forecastData.dateFetched == currentDate)
        ) {

            Log.d("wtr_dta", "getWeatherUpdates: loading today/forecast locally")

            todayLiveData.value = todayData.todayData
            forecastLiveData.value = forecastData.forecastData

        } else {

            CoroutineScope(Dispatchers.IO).launch {

                api
                    .getForecast(lat, lng, "metric", RemoteConfig.weatherApiKey!!)
                    .enqueue(object : Callback<ForecastResponse> {

                        override fun onResponse(
                            call: Call<ForecastResponse>,
                            response: Response<ForecastResponse>
                        ) {

                            if (response.isSuccessful && response.code() <= 299 && response.body() != null) {

                                parseForecastResponse(context, response.body()!!, lat, lng)

                            } else {

                                CoroutineScope(Dispatchers.Main).launch {

                                    weatherLiveData.value = null
                                }
                            }
                        }

                        override fun onFailure(call: Call<ForecastResponse>, t: Throwable) {

                            CoroutineScope(Dispatchers.Main).launch {

                                weatherLiveData.value = null
                            }
                        }
                    })
            }
        }
    }


    private fun parseWeatherResponse(
        context: Context,
        response: WeatherResponse,
        lat: Double,
        lng: Double
    ) {

        var cityNameDate: String
        var currentTime: String
        var weatherIconUrl: String
        var temperature: String
        var weatherTitle: String
        var lastUpdated: String

        var rain: String
        var humidity: String
        var wind: String

        CoroutineScope(Dispatchers.IO).launch {

            try {

                cityNameDate = response.name + ", " + StringUtils.getCurrentDateForWeather()
                currentTime = StringUtils.getCurrentTime()
                weatherIconUrl = response.weather[0].icon + "@4x.png"
                temperature =
                    StringUtils.getRoundOffValue(response.main.temp, 2).toString() + " \u2103"
                weatherTitle = response.weather[0].main
                lastUpdated = "Update " + StringUtils.getCurrentTime()

                rain =
                    if (response.rain == null || response.rain.oneHour == null) "0 mm"
                    else response.rain.oneHour.toString() + " mm"

                humidity = response.main.humidity.toString() + "%"

                wind = response.wind.speed.toString() + " km/h"

                val weatherData = WeatherData(
                    cityNameDate,
                    currentTime,
                    weatherIconUrl,
                    temperature,
                    weatherTitle,
                    lastUpdated,
                    rain,
                    humidity,
                    wind
                )

                // save to local storage
                WeatherPrefs.saveWeatherData(
                    context,
                    WeatherLocalData(StringUtils.getCurrentDate(), lat, lng, weatherData)
                )

                CoroutineScope(Dispatchers.Main).launch {

                    weatherLiveData.value = weatherData
                }

            } catch (e: Exception) {

                e.printStackTrace()

                Log.d("wtr_dta", "parseResponse: error: " + e.message)

                CoroutineScope(Dispatchers.Main).launch {

                    weatherLiveData.value = null
                }
            }
        }
    }

    private fun parseForecastResponse(
        context: Context,
        response: ForecastResponse,
        lat: Double,
        lng: Double
    ) {

        val todayData: ArrayList<TodayData> = ArrayList()
        val forecastData: ArrayList<ForecastData> = ArrayList()

        val forecastMap: LinkedHashMap<String, ForecastMap> = LinkedHashMap()

        try {

            CoroutineScope(Dispatchers.IO).launch {

                for (day in response.list) {

                    val currentDate = day.dateString.substring(
                        0,
                        day.dateString.length.coerceAtMost(10)
                    )

                    val todayDate = StringUtils.getCurrentDate()

                    // get today weather
                    if (todayDate == currentDate) {

                        val iconUrl = day.weather[0].icon + "@4x.png"
                        val temperature =
                            StringUtils.getRoundOffValue(day.main.temp, 2).toString() + " \u2103"
                        val time = StringUtils.dateToTime(day.dateString)

                        val today = TodayData(iconUrl, temperature, time)

                        todayData.add(today)

                        // get forecast data for one day
                    } else {

                        if (forecastMap[currentDate] == null) {

                            forecastMap[currentDate] =
                                ForecastMap(
                                    LinkedHashMap(),
                                    LinkedHashMap(),
                                    LinkedHashMap(),
                                    LinkedHashMap()
                                )
                        }

                        // titles
                        if (forecastMap[currentDate]!!.titles[day.weather[0].main] == null) {

                            forecastMap[currentDate]!!.titles[day.weather[0].main] = 1

                        } else {

                            forecastMap[currentDate]!!.titles[day.weather[0].main] =
                                forecastMap[currentDate]!!.titles[day.weather[0].main]!! + 1
                        }

                        // highs
                        if (forecastMap[currentDate]!!.highs[day.main.maximumTemperature] == null) {

                            forecastMap[currentDate]!!.highs[day.main.maximumTemperature] = 1

                        } else {

                            forecastMap[currentDate]!!.highs[day.main.maximumTemperature] =
                                forecastMap[currentDate]!!.highs[day.main.maximumTemperature]!! + 1
                        }

                        // lows
                        if (forecastMap[currentDate]!!.lows[day.main.minimumTemperature] == null) {

                            forecastMap[currentDate]!!.lows[day.main.minimumTemperature] = 1

                        } else {

                            forecastMap[currentDate]!!.lows[day.main.minimumTemperature] =
                                forecastMap[currentDate]!!.lows[day.main.minimumTemperature]!! + 1
                        }

                        // icons
                        if (forecastMap[currentDate]!!.icons[day.weather[0].icon] == null) {

                            forecastMap[currentDate]!!.icons[day.weather[0].icon] = 1

                        } else {

                            forecastMap[currentDate]!!.icons[day.weather[0].icon] =
                                forecastMap[currentDate]!!.icons[day.weather[0].icon]!! + 1
                        }
                    }
                }

                for (date in forecastMap.keys.toList()) {

                    var title = ""
                    var high = 0.0
                    var low = 0.0
                    var icon = ""

                    // title
                    var maxTitle = 0
                    for (key in forecastMap[date]!!.titles.keys.toList()) {

                        if (forecastMap[date]!!.titles[key]!! > maxTitle) {

                            maxTitle = forecastMap[date]!!.titles[key]!!
                            title = key
                        }
                    }

                    // high
                    var maxHigh = 0
                    for (key in forecastMap[date]!!.highs.keys.toList()) {

                        if (forecastMap[date]!!.highs[key]!! > maxHigh) {

                            maxHigh = forecastMap[date]!!.highs[key]!!
                            high = key
                        }
                    }

                    // low
                    var maxLow = 0
                    for (key in forecastMap[date]!!.lows.keys.toList()) {

                        if (forecastMap[date]!!.lows[key]!! > maxLow) {

                            maxLow = forecastMap[date]!!.lows[key]!!
                            low = key
                        }
                    }

                    // icon
                    var maxIcon = 0
                    for (key in forecastMap[date]!!.icons.keys.toList()) {

                        if (forecastMap[date]!!.icons[key]!! > maxIcon) {

                            maxIcon = forecastMap[date]!!.icons[key]!!
                            icon = key
                        }
                    }

                    val forecast = ForecastData(
                        StringUtils.getDayName(date),
                        title,
                        "${StringUtils.getRoundOffValue(high, 2)} \u2103",
                        "${StringUtils.getRoundOffValue(low, 2)} \u2103",
                        "$icon@4x.png"
                    )

                    forecastData.add(forecast)
                }

                // save to local storage
                WeatherPrefs.saveTodayData(
                    context,
                    TodayLocalData(StringUtils.getCurrentDate(), lat, lng, todayData)
                )

                WeatherPrefs.saveForecastData(
                    context,
                    ForecastLocalData(StringUtils.getCurrentDate(), lat, lng, forecastData)
                )

                CoroutineScope(Dispatchers.Main).launch {

                    todayLiveData.value = todayData
                    forecastLiveData.value = forecastData
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()

            todayLiveData.value = null
            forecastLiveData.value = null
        }
    }

    class ForecastMap(
        var titles: LinkedHashMap<String, Int>,
        var highs: LinkedHashMap<Double, Int>,
        var lows: LinkedHashMap<Double, Int>,
        var icons: LinkedHashMap<String, Int>
    )
}