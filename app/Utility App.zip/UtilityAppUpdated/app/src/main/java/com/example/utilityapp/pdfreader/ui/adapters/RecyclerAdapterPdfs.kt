package com.example.utilityapp.pdfreader.ui.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.utilityapp.R
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.pdfreader.model.MPdf
import java.text.SimpleDateFormat

class RecyclerAdapterPdfs(
    val context: Context,
    private val pdfClickListener: IPdfClickListener
) :
    RecyclerView.Adapter<RecyclerAdapterPdfs.ViewHolder>() {

    private val pdfs = ArrayList<MPdf>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val textViewName: TextView = itemView.findViewById(R.id.text_view_name)
        val textViewDate: TextView = itemView.findViewById(R.id.text_view_date)
        val textViewPagesCount: TextView = itemView.findViewById(R.id.text_view_page_count)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_item_pdf,
            parent, false
        )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val pdf = pdfs[position]

        holder.textViewDate.text =
            if (StringUtils.isDateToday(pdf.lastReadTime)) "Today" else pdf.lastReadTime

        holder.textViewName.text = pdf.name
        holder.textViewPagesCount.text =
            if (pdf.totalPages <= 1) "${pdf.totalPages} Page" else "${pdf.totalPages} Pages"

        holder.itemView.setOnClickListener {

            pdfClickListener.onPdfClick(pdfs[position])
        }
    }

    override fun getItemCount(): Int {

        return pdfs.size
    }

    @SuppressLint("SimpleDateFormat")
    fun updateData(newList: List<MPdf>) {

        pdfs.clear()
        pdfs.addAll(newList)

        // sort all barcodes
        pdfs.sortedByDescending { barcode ->

            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            sdf.parse(barcode.lastReadTime)?.time
        }

        notifyItemRangeChanged(0, pdfs.size)
    }
}

interface IPdfClickListener {

    fun onPdfClick(pdf: MPdf)
}