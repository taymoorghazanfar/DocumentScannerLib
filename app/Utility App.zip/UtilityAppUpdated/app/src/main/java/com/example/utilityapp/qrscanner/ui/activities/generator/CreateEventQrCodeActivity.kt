package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateEventQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel
import com.google.android.material.snackbar.Snackbar
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog
import java.util.*


class CreateEventQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateEventQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    private var startDate: String? = null
    private var startTime: String? = null
    private var endDate: String? = null
    private var endTime: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateEventQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Event"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }

        binding.content.textViewStartDate.setOnClickListener {

            val calendar = Calendar.getInstance()

            val datePicker: DatePickerDialog = DatePickerDialog.newInstance(

                { _, year, monthOfYear, dayOfMonth ->

                    var monthString = (monthOfYear + 1).toString()
                    var dayString = dayOfMonth.toString()

                    if (monthString.length == 1) {

                        monthString = "0$monthString"
                    }
                    if (dayString.length == 1) {

                        dayString = "0$dayString"
                    }

                    startDate = "$year$monthString$dayString"

                    binding.content.textViewStartDate.text = "$dayString-$monthString-$year"

                    Log.d("p_d", "initViews: " + startDate)
                },

                calendar[Calendar.YEAR],
                calendar[Calendar.MONTH],
                calendar[Calendar.DAY_OF_MONTH]
            )

            datePicker.show(this.supportFragmentManager, "date_picker")
        }

        binding.content.textViewStartTime.setOnClickListener {

            val calendar: Calendar = Calendar.getInstance()
            val datePicker: TimePickerDialog =
                TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->

                    try {

                        var hourString = hourOfDay.toString()

                        var minuteString = minute.toString()

                        if (hourString.length == 1) {

                            hourString = "0$hourString"
                        }

                        if (minuteString.length == 1) {

                            minuteString = "0$minuteString"
                        }

                        startTime = "T$hourString${minuteString}00"

                        binding.content.textViewStartTime.text = "$hourString:$minuteString:00"

                        Log.d("p_d", "initViews: " + startTime)

                    } catch (ignored: Exception) {


                    }
                }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true)

            datePicker.show(this.supportFragmentManager, "time_picker")
        }

        binding.content.textViewEndDate.setOnClickListener {

            val calendar = Calendar.getInstance()

            val datePicker: DatePickerDialog = DatePickerDialog.newInstance(

                { _, year, monthOfYear, dayOfMonth ->

                    var monthString = (monthOfYear + 1).toString()
                    var dayString = dayOfMonth.toString()

                    if (monthString.length == 1) {

                        monthString = "0$monthString"
                    }
                    if (dayString.length == 1) {

                        dayString = "0$dayString"
                    }

                    endDate = "$year$monthString$dayString"

                    binding.content.textViewEndDate.text = "$dayString-$monthString-$year"

                    Log.d("p_d", "initViews: " + endDate)
                },

                calendar[Calendar.YEAR],
                calendar[Calendar.MONTH],
                calendar[Calendar.DAY_OF_MONTH]
            )

            datePicker.show(this.supportFragmentManager, "date_picker")
        }

        binding.content.textViewEndTime.setOnClickListener {

            val calendar: Calendar = Calendar.getInstance()
            val datePicker: TimePickerDialog =
                TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->

                    try {

                        var hourString = hourOfDay.toString()

                        var minuteString = minute.toString()

                        if (hourString.length == 1) {

                            hourString = "0$hourString"
                        }

                        if (minuteString.length == 1) {

                            minuteString = "0$minuteString"
                        }

                        endTime = "T$hourString${minuteString}00"

                        binding.content.textViewEndTime.text = "$hourString:$minuteString:00"

                        Log.d("p_d", "initViews: " + endTime)

                    } catch (ignored: Exception) {


                    }
                }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true)

            datePicker.show(this.supportFragmentManager, "time_picker")

        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateEventQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val summary: String = binding.content.editTextSummary.text.toString().trim()
        val location: String = binding.content.editTextLocation.text.toString().trim()
        val description: String = binding.content.editTextDescription.text.toString().trim()

        var isInputValid = true

        if (summary.isEmpty()) {

            binding.content.editTextSummary.error = "Field is required"
            isInputValid = false
        }

        if (location.isEmpty()) {

            binding.content.editTextLocation.error = "Field is required"
            isInputValid = false
        }

        if (description.isEmpty()) {

            binding.content.editTextDescription.error = "Field is required"
            isInputValid = false
        }

        if (startTime == null || endDate == null) {

            Snackbar.make(binding.root, "Start time is required", Snackbar.LENGTH_SHORT).show()
            isInputValid = false
        }

        if (endTime == null || endDate == null) {

            Snackbar.make(binding.root, "End time is required", Snackbar.LENGTH_SHORT).show()
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createEventQrCode(
                1,
                summary,
                location,
                description,
                startDate + startTime!!,
                endDate + endTime!!
            )
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}