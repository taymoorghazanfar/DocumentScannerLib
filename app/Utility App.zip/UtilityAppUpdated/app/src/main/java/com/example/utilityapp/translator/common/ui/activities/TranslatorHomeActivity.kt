package com.example.utilityapp.translator.common.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.utilityapp.common.ui.decorators.SpacesItemDecoration
import com.example.utilityapp.databinding.ActivityTranslatorHomeBinding
import com.example.utilityapp.translator.common.ui.dialogs.PickImageBottomSheet
import com.example.utilityapp.translator.common.ui.interfaces.BSPickImageListener
import com.example.utilityapp.translator.common.viewmodel.TranslationsViewModel
import com.example.utilityapp.translator.home.ui.adapter.ITranslationClickListener
import com.example.utilityapp.translator.home.ui.adapter.RecyclerAdapterTranslations
import com.example.utilityapp.translator.image.ui.activities.ImageTranslatorActivity
import com.example.utilityapp.translator.model.MTranslation
import com.example.utilityapp.translator.text.ui.activities.TextTranslatorActivity
import com.example.utilityapp.translator.voice.ui.activities.VoiceTranslatorActivity
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TranslatorHomeActivity : AppCompatActivity(), BSPickImageListener, ITranslationClickListener {

    private lateinit var binding: ActivityTranslatorHomeBinding
    private lateinit var viewModel: TranslationsViewModel
    private lateinit var bottomSheet: PickImageBottomSheet
    private var fromCameraIntent = false

    @SuppressLint("StaticFieldLeak")
    private lateinit var adapter: RecyclerAdapterTranslations

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTranslatorHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initHeader()

        initViewModel()

        initViews()
    }

    private fun initViews() {

        binding.content.buttonText.setOnClickListener {

            startActivity(
                Intent(
                    this@TranslatorHomeActivity,
                    TextTranslatorActivity::class.java
                )
            )
        }

        binding.content.buttonCamera.setOnClickListener {

            bottomSheet = PickImageBottomSheet()
            bottomSheet.setListener(this)
            bottomSheet.show(supportFragmentManager, bottomSheet.tag)
        }

        binding.content.buttonVoice.setOnClickListener {

            startActivity(
                Intent(
                    this@TranslatorHomeActivity,
                    VoiceTranslatorActivity::class.java
                )
            )
        }

        binding.content.recyclerView.layoutManager = LinearLayoutManager(this)
        val spacingInPixels =
            resources.getDimensionPixelSize(com.example.utilityapp.R.dimen.recycler_view_spacing)
        binding.content.recyclerView.addItemDecoration(
            SpacesItemDecoration(spacingInPixels,0)
        )
        adapter = RecyclerAdapterTranslations(this, this)
        binding.content.recyclerView.adapter = adapter
    }

    private fun initHeader() {

        binding.header.textViewTitle.text = "Translator"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[TranslationsViewModel::class.java]

        viewModel.init()

        viewModel.getAllTranslationsLiveData().observe(this) { translations ->

            adapter.updateData(translations)
        }
    }

    override fun onGallerySelected() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            bottomSheet.dismiss()

            ImagePicker.with(this)
                .galleryOnly()
                .crop()
                .start()

        } else {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                REQUEST_CODE_STORAGE_PERMISSION
            )
        }
    }

    override fun onCameraSelected() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            fromCameraIntent = true

            bottomSheet.dismiss()

            ImagePicker.with(this)
                .cameraOnly()
                .crop()
                .start()

        } else {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                REQUEST_CODE_STORAGE_PERMISSION
            )
        }
    }

    override fun onDismissed() {


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (resultCode) {

            Activity.RESULT_OK -> {

                CoroutineScope(Dispatchers.Main).launch {

                    val uri: Uri = data?.data!!
                    val i = Intent(this@TranslatorHomeActivity, ImageTranslatorActivity::class.java)
                    i.putExtra("uri", uri)
                    i.putExtra("camera", fromCameraIntent)

                    fromCameraIntent = false

                    if (bottomSheet != null) {

                        bottomSheet.dismiss()
                    }
                    startActivity(i)
                }
            }

            ImagePicker.RESULT_ERROR -> {

                Snackbar.make(
                    binding.root,
                    ImagePicker.getError(data),
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                ImagePicker.with(this)
                    .galleryOnly()
                    .compress(1024)
                    .maxResultSize(800, 800)
                    .start()

            } else {

                Snackbar.make(
                    binding.root,
                    "Storage permission is required to use this feature",
                    Snackbar.LENGTH_SHORT
                ).show()
            }

        } else if (requestCode == REQUEST_CODE_CAMERA_PERMISSION) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                ImagePicker.with(this)
                    .cameraOnly()
                    .compress(1024)
                    .maxResultSize(800, 800)
                    .start()

            } else {

                Snackbar.make(
                    binding.root,
                    "Storage permission is required to use this feature",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onTranslationClick(translation: MTranslation) {

        val i = Intent(this@TranslatorHomeActivity, TextTranslatorActivity::class.java)

        i.putExtra("text", translation.text)
        i.putExtra("output", translation.output)
        i.putExtra("source", translation.sourceLanguageIndex)
        i.putExtra("target", translation.targetLanguageIndex)
        i.putExtra("viewing", true)

        startActivity(i)
    }

    companion object {

        var REQUEST_CODE_STORAGE_PERMISSION = 1
        var REQUEST_CODE_CAMERA_PERMISSION = 2
    }
}