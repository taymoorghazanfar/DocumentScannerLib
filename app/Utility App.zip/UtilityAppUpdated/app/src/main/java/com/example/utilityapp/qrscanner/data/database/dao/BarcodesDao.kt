package com.example.utilityapp.qrscanner.data.database.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.utilityapp.qrscanner.model.MBarcode

@Dao
interface BarcodesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(barcode: MBarcode)

    @Query("Select * from barcodes order by date_created DESC")
    fun getAllBarcodes(): LiveData<List<MBarcode>>
}