package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Wind {

    @SerializedName("speed")
    var speed: Double

    @SerializedName("deg")
    var degree: Double

    @SerializedName("gust")
    var gust: Double

    constructor(speed: Double, degree: Double, gust: Double) {
        this.speed = speed
        this.degree = degree
        this.gust = gust
    }
}