package com.example.utilityapp.common.interfaces

interface IAlertButtonClickListener {

    fun onAlertButtonClick(action:Int)
}