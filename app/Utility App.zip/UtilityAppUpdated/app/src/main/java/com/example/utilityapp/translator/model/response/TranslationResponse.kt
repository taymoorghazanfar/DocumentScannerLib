package com.example.utilityapp.translator.model.response

class TranslationResponse(var translatedText: String?, var originalText: String?) {

}