package com.example.utilityapp.translator.common.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.utilityapp.translator.common.data.database.TranslationsDatabase
import com.example.utilityapp.translator.common.repository.TranslationsRepository
import com.example.utilityapp.translator.model.MTranslation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TranslationsViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var repository: TranslationsRepository
    private lateinit var allTranslationsLiveData: LiveData<List<MTranslation>>

    fun init() {

        repository = TranslationsRepository(
            TranslationsDatabase.getDatabase(getApplication()).getTranslationsDao()
        )
        this.allTranslationsLiveData = repository.allTranslations
    }

    fun getAllTranslationsLiveData(): LiveData<List<MTranslation>> {

        return this.allTranslationsLiveData
    }

    private fun save(translation: MTranslation) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(translation)
        }

    fun update(translation: MTranslation) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(translation)
        }

    fun deleteById(id: Int) {

        viewModelScope.launch(Dispatchers.IO) {

            repository.deleteById(id)
        }
    }
}