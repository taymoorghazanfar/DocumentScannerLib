package com.example.utilityapp.translator.voice.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.utilityapp.translator.common.data.database.TranslationsDatabase
import com.example.utilityapp.common.data.network.RetrofitBuilder
import com.example.utilityapp.translator.common.repository.TranslationsRepository
import com.example.utilityapp.translator.model.MTranslation
import com.example.utilityapp.translator.text.repository.TextTranslatorRepository
import com.example.utilityapp.translator.voice.repository.VoiceTranslatorRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class VoiceTranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var voiceTranslatorRepository: VoiceTranslatorRepository
    private lateinit var textTranslatorRepository: TextTranslatorRepository
    private lateinit var translationsRepository: TranslationsRepository

    private lateinit var speechLiveData: MutableLiveData<String?>
    private lateinit var translationLiveData: MutableLiveData<String?>

    fun init(context: Context, url:String) {

        voiceTranslatorRepository = VoiceTranslatorRepository()
        voiceTranslatorRepository.init(context)

        textTranslatorRepository = TextTranslatorRepository()
        textTranslatorRepository.init(RetrofitBuilder.getTranslatorApiService(url))

        translationsRepository = TranslationsRepository(
            TranslationsDatabase.getDatabase(getApplication()).getTranslationsDao()
        )

        speechLiveData = voiceTranslatorRepository.getSpeechLiveData()
        translationLiveData = textTranslatorRepository.getTranslationLiveData()
    }

    fun getSpeechLiveData(): MutableLiveData<String?> {

        return this.speechLiveData
    }

    fun getTranslationLiveData(): MutableLiveData<String?> {

        return this.translationLiveData
    }

    fun startRecording() {

        voiceTranslatorRepository.startRecording()
    }

    fun stopRecording() {

        voiceTranslatorRepository.stopRecording()
    }

    fun destroy() {

        voiceTranslatorRepository.destroy()
    }

    fun save(translation: MTranslation) =
        viewModelScope.launch(Dispatchers.IO) {
            translationsRepository.insert(translation)
        }

    fun getTranslation(
        sourceLanguageCode: String,
        targetLanguageCode: String,
        text: String

    ) {

        textTranslatorRepository.getTranslation(sourceLanguageCode, targetLanguageCode, text)
    }
}