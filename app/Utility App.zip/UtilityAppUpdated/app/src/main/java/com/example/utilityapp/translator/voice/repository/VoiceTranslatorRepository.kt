package com.example.utilityapp.translator.voice.repository

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.lifecycle.MutableLiveData

class VoiceTranslatorRepository {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechRecognizerIntent: Intent
    private lateinit var speechLiveData: MutableLiveData<String?>
    private var isRecording = false
    private var speechText = ""

    fun init(context: Context) {

        speechLiveData = MutableLiveData()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)

        speechRecognizer.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(bundle: Bundle) {

                Log.d("sp_rec", "onBeginningOfSpeech: listening...")
            }

            override fun onBeginningOfSpeech() {

                Log.d("sp_rec", "onBeginningOfSpeech: ")
            }

            override fun onRmsChanged(v: Float) {

                Log.d("sp_rec", "onRmsChanged: " + v)
            }

            override fun onBufferReceived(bytes: ByteArray) {

                Log.d("sp_rec", "onBufferReceived: ")
            }

            override fun onEndOfSpeech() {

                Log.d("sp_rec", "onBeginningOfSpeech: stopped...")
//                Log.d("sp_rec", "onBeginningOfSpeech: " + isRecording)
//
//                if (isRecording) {
//
//                    speechRecognizer.cancel()
//                    speechRecognizer.startListening(speechRecognizerIntent)
//                }
            }

            override fun onError(i: Int) {

                Log.d("sp_rec", "onError: " + i)

//                if(i == 8){
//
//                    speechRecognizer.cancel()
//                    speechRecognizer.startListening(speechRecognizerIntent)
//                }
//
//                else{
//
//                    if (isRecording) {
//
//                        speechRecognizer.stopListening()
//                        speechRecognizer.startListening(speechRecognizerIntent)
//                    }
//                }
            }

            override fun onResults(bundle: Bundle) {

                Log.d("sp_rec", "onResults: checking results")

                try {

                    val data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

                    if (data != null && data.isNotEmpty()) {

                        Log.d("sp_rec", "onResults: result size: " + data.size)

                        speechLiveData.value = data[0]

//                        speechText += if (speechText.isEmpty()) data[0] else " " + data[0]
//
//                        if (!isRecording) {
//
//                            speechLiveData.value = speechText
//                            speechText = ""
//                        }

                    } else {

                        Log.d("sp_rec", "onResults: no results")
                    }

                } catch (e: Exception) {

                    e.printStackTrace()
                }
            }

            override fun onPartialResults(bundle: Bundle) {

            }

            override fun onEvent(i: Int, bundle: Bundle) {

                Log.d("sp_rec", "onEvent: ")
            }
        })
    }

    fun getSpeechLiveData(): MutableLiveData<String?> {

        return this.speechLiveData
    }

    fun startRecording() {

        try {

            isRecording = true
            speechRecognizer.startListening(speechRecognizerIntent)

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    fun stopRecording() {

        try {

            isRecording = false
            speechRecognizer.stopListening()

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    fun destroy() {

        try {

            speechRecognizer.destroy()

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }
}