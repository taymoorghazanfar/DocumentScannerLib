package com.example.utilityapp.pdfreader.ui.activities

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.utilityapp.R
import com.example.utilityapp.common.util.DeviceDimensionHelper
import com.example.utilityapp.common.util.ImageUtils
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityPdfViewerBinding
import com.example.utilityapp.pdfreader.model.MPdf
import com.example.utilityapp.pdfreader.viewmodel.PdfFilesViewModel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.abs

class PdfViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfViewerBinding
    private lateinit var viewModel: PdfFilesViewModel

    private var fileDescriptor: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null

    private var currentPage: PdfRenderer.Page? = null
    private var currentPageIndex: Int = 0
    private var totalPages: Int = 0

    private var pdf: MPdf? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getData(savedInstanceState)
    }

    private fun getData(savedInstanceState: Bundle?) {

        initErrorViews()

        // todo: check in saved instance

        try {

            pdf = if (Build.VERSION.SDK_INT >= 33) {

                intent.getSerializableExtra("pdf", MPdf::class.java)

            } else {

                intent.getSerializableExtra("pdf") as MPdf
            }

            if (pdf != null) {

                if (savedInstanceState != null) {

                    currentPageIndex =
                        savedInstanceState.getInt("current_page", -1)
                }

                if (currentPageIndex == -1 || currentPageIndex == 0) {

                    currentPageIndex = pdf!!.currentPage
                }

                totalPages = pdf!!.totalPages

                initRenderer()

                initViewModel()

                initHeader()

                initViews()

                showPage(currentPageIndex)

            } else {

                showError()
            }

        } catch (e: Exception) {

            e.printStackTrace()

            showError()
        }
    }

    private fun initErrorViews() {

        CoroutineScope(Dispatchers.Main).launch {

            binding.layoutError.root.visibility = View.GONE
            binding.layoutError.buttonBack.setOnClickListener {

                finish()
            }
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[PdfFilesViewModel::class.java]

        viewModel.init()
    }

    private fun initHeader() {

        CoroutineScope(Dispatchers.Main).launch {

            binding.header.textViewFileName.text = pdf!!.name

            binding.header.buttonBack.setOnClickListener {

                finish()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putInt("current_page", currentPageIndex)
    }

    override fun onPause() {

        super.onPause()

        try {

            pdf!!.currentPage = currentPageIndex
            pdf!!.lastReadTime = StringUtils.getCurrentDateTime()

            viewModel.updatePdfFile(pdf!!)

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    override fun onDestroy() {

        super.onDestroy()

        try {

            closeRenderer()

        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun initRenderer() {

        try {

            val parcelFileDescriptor: ParcelFileDescriptor =
                contentResolver.openFileDescriptor(Uri.parse(pdf!!.uri), "r")!!

            fileDescriptor = parcelFileDescriptor

            pdfRenderer = PdfRenderer(fileDescriptor!!)

        } catch (e: Exception) {

            e.printStackTrace()

            showError()
        }
    }

    private fun closeRenderer() {

        try {

            currentPage?.close()
            pdfRenderer!!.close()
            fileDescriptor!!.close()

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun showPage(index: Int) {

        binding.content.buttonPrevious.isEnabled = false
        binding.content.buttonNext.isEnabled = false

        try {

            CoroutineScope(Dispatchers.IO).launch {

                // Make sure to close the current page before opening another one.
                if (currentPage != null) {

                    currentPage?.close()
                }

                //open a specific page in PDF file
                currentPage = pdfRenderer!!.openPage(index)

                CoroutineScope(Dispatchers.IO).launch {

                    // Important: the destination bitmap must be ARGB (not RGB).
                    val bitmap = Bitmap.createBitmap(
                        currentPage!!.width.toPixelDimension(),
                        currentPage!!.height.toPixelDimension(),
                        Bitmap.Config.ARGB_8888
                    )

                    val height: Int = DeviceDimensionHelper.getDisplayHeight(this@PdfViewerActivity)

                    val scaledBitmap: Bitmap? = ImageUtils.scaleToFitHeight(bitmap, height)

                    if (scaledBitmap != null) {

                        // Here, we render the page onto the Bitmap.
                        currentPage!!.render(
                            scaledBitmap,
                            null,
                            null,
                            PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                        )

                        withContext(Dispatchers.Main) {

                            setPageImage(scaledBitmap)
                            updatePageCount()
                        }

                    } else {

                        showError()
                    }
                }

//                val scaledBitmap:Bitmap = Bitmap.createScaledBitmap(
//                    bitmap,
//                    ((bitmap.width * 0.3).toInt()),
//                    ((bitmap.height * 0.3).toInt()),
//                    true
//                );
            }

        } catch (e: Exception) {

            e.printStackTrace()
            showError()
        }
    }

    private fun setPageImage(image: Bitmap?) {

        val animOut: Animation =
            AnimationUtils.loadAnimation(this@PdfViewerActivity, R.anim.fade_out_fast)
        val animIn: Animation =
            AnimationUtils.loadAnimation(this@PdfViewerActivity, R.anim.fade_in_fast)

        animOut.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                Glide
                    .with(this@PdfViewerActivity)
                    .load(image)
                    .into(binding.content.image)

//                binding.content.image.setImageBitmap(image)

                binding.content.image.startAnimation(animIn)
                binding.content.image.reset()
            }
        })
        binding.content.image.startAnimation(animOut)
    }

    private fun updatePageCount() {

        binding.content.buttonPrevious.isEnabled = true
        binding.content.buttonNext.isEnabled = true

        binding.content.textViewPageCount.text = buildString {
            append(currentPageIndex + 1)
            append(" / ")
            append(totalPages)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun initViews() {

        binding.content.buttonNext.setOnClickListener {

            gotoNextPage()
        }

        binding.content.buttonPrevious.setOnClickListener {

            gotoPreviousPage()
        }

//        val flingActionVar =
//            GestureDetector(
//                this@PdfViewerActivity,
//                object : GestureDetector.SimpleOnGestureListener() {
//                    val flingActionMinDstVac = 120
//                    val flingActionMinSpdVac = 200
//                    override fun onFling(
//                        fstMsnEvtPsgVal: MotionEvent,
//                        lstMsnEvtPsgVal: MotionEvent,
//                        flingActionXcoSpdPsgVal: Float,
//                        flingActionYcoSpdPsgVal: Float
//                    ): Boolean {
//                        if (fstMsnEvtPsgVal.x - lstMsnEvtPsgVal.x > flingActionMinDstVac && abs(
//                                flingActionXcoSpdPsgVal
//                            ) > flingActionMinSpdVac
//                        ) {
//                            // TskTdo :=> On Right to Left fling
//                            gotoNextPage()
//                            return false
//                        } else if (lstMsnEvtPsgVal.x - fstMsnEvtPsgVal.x > flingActionMinDstVac && abs(
//                                flingActionXcoSpdPsgVal
//                            ) > flingActionMinSpdVac
//                        ) {
//                            // TskTdo :=> On Left to Right fling
//                            gotoPreviousPage()
//                            return false
//                        }
//                        if (fstMsnEvtPsgVal.y - lstMsnEvtPsgVal.y > flingActionMinDstVac && abs(
//                                flingActionYcoSpdPsgVal
//                            ) > flingActionMinSpdVac
//                        ) {
//                            // TskTdo :=> On Bottom to Top fling
//                            return false
//                        } else if (lstMsnEvtPsgVal.y - fstMsnEvtPsgVal.y > flingActionMinDstVac && abs(
//                                flingActionYcoSpdPsgVal
//                            ) > flingActionMinSpdVac
//                        ) {
//                            // TskTdo :=> On Top to Bottom fling
//                            return false
//                        }
//                        return false
//                    }
//                })
//
//        binding.content.image.setOnTouchListener { _, event ->
//
//            flingActionVar.onTouchEvent(event)
//        }

        updatePageCount()
    }


    private fun gotoPreviousPage() {

        if (currentPageIndex - 1 >= 0) {

            currentPageIndex -= 1

            showPage(currentPageIndex)
        }
    }

    private fun gotoNextPage() {

        if (currentPageIndex + 1 < totalPages) {

            currentPageIndex += 1

            showPage(currentPageIndex)
        }
    }

    private fun showError() {

        binding.header.root.visibility = View.GONE
        binding.content.root.visibility = View.GONE
        binding.bannerAd.root.visibility = View.GONE

        binding.layoutError.root.visibility = View.VISIBLE

        Snackbar.make(
            binding.root,
            "Error occurred while reading the file",
            Snackbar.LENGTH_SHORT
        ).show()
    }

    private fun Int.toPixelDimension(scaleFactor: Float = 0.4f): Int {

        val densityDpi = resources.displayMetrics.densityDpi
        return ((densityDpi * this / PDF_RESOLUTION_DPI) * scaleFactor).toInt()
    }

    companion object {

        const val PDF_RESOLUTION_DPI = 72
    }
}