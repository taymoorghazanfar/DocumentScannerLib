package com.example.utilityapp.qrscanner.ui.activities.scanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.ContactsContract
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.R
import com.example.utilityapp.common.util.PackageUtils
import com.example.utilityapp.databinding.ActivityScannerResultBinding
import com.example.utilityapp.qrscanner.model.MBarcode
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.mlkit.vision.barcode.common.Barcode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QRScannerResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScannerResultBinding
    private lateinit var viewModel: QrCodeViewModel
    private lateinit var barcode: MBarcode

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScannerResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getData()
        setupHeader()
        initViewModel()
    }

    private fun getData() {

        try {

            barcode = intent.getSerializableExtra("barcode") as MBarcode

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = getString(R.string.result)
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()
        viewModel.getBarcodeImageLiveData().observe(this) { barcodeBitmap ->

            readBarcode(barcodeBitmap)
        }

        viewModel.generateQrCode(barcode)
    }

    private fun readBarcode(barcodeImage: Bitmap) {

        setBarcodeImage(barcodeImage)

        try {

            when (barcode.type) {

                Barcode.TYPE_URL -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.url)
                        binding.content.textViewData.text = barcode.readableValue
                        binding.content.buttonAction.text = getString(R.string.open_in_browser)
                        binding.content.buttonAction.setOnClickListener {

                            try {

                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(barcode.data)))

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_CALENDAR_EVENT -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.calender_event)
                        binding.content.textViewData.text = barcode.readableValue

                        binding.content.buttonAction.text = getString(R.string.open_in_calender)
                        binding.content.buttonAction.setOnClickListener {

                            try {

                                var summary = ""
                                var start = ""
                                var end = ""
                                var location = ""
                                var description = ""

                                val contactData = barcode.data.split("\n")

                                for (value: String in contactData) {

                                    if (value.contains("SUMMARY:")) {

                                        summary = value.trim().replace("SUMMARY:", "")
                                        continue
                                    }
                                    if (value.contains("DTSTART:")) {

                                        start = value.trim().replace("DTSTART:", "")
                                        continue
                                    }
                                    if (value.contains("DTEND:")) {

                                        end = value.trim().replace("DTEND:", "")
                                        continue
                                    }
                                    if (value.contains("LOCATION:")) {

                                        location = value.trim().replace("LOCATION:", "")
                                        continue
                                    }
                                    if (value.contains("DESCRIPTION:")) {

                                        description = value.trim().replace("DESCRIPTION:", "")
                                        continue
                                    }
                                }

                                val i = Intent(Intent.ACTION_INSERT).apply {

                                    data = CalendarContract.Events.CONTENT_URI
                                    putExtra(CalendarContract.Events.TITLE, summary)
                                    putExtra(CalendarContract.Events.DESCRIPTION, description)
                                    putExtra(CalendarContract.Events.EVENT_LOCATION, location)
                                    putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                                    putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
                                }

                                startActivity(i)

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_CONTACT_INFO -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.contact_info)
                        binding.content.textViewData.text = barcode.readableValue
                        binding.content.buttonAction.text = getString(R.string.open_in_contacts)

                        binding.content.buttonAction.setOnClickListener {

                            try {
                                var name = ""
                                var org = ""
                                var adr = ""
                                var tel = ""
                                var email = ""

                                val contactData = barcode.data.split("\n")

                                for (value: String in contactData) {

                                    if (value.contains("N:")) {

                                        name = value.trim().replace("N:", "")
                                        continue
                                    }
                                    if (value.contains("ORG:")) {

                                        org = value.trim().replace("ORG:", "")
                                        continue
                                    }
                                    if (value.contains("ADR:")) {

                                        adr = value.trim().replace("ADR:", "")
                                        continue
                                    }
                                    if (value.contains("TEL:")) {

                                        tel = value.trim().replace("TEL:", "")
                                        continue
                                    }
                                    if (value.contains("EMAIL:")) {

                                        email = value.trim().replace("EMAIL:", "")
                                        continue
                                    }
                                }

                                val i = Intent(Intent.ACTION_INSERT).apply {
                                    type = ContactsContract.Contacts.CONTENT_TYPE
                                    putExtra(ContactsContract.Intents.Insert.NAME, name)
                                    putExtra(ContactsContract.Intents.Insert.EMAIL, email)
                                    putExtra(ContactsContract.Intents.Insert.COMPANY, org)
                                    putExtra(ContactsContract.Intents.Insert.POSTAL, adr)
                                    putExtra(ContactsContract.Intents.Insert.PHONE, tel)
                                }

                                startActivity(i)

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_EMAIL -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.email)
                        binding.content.textViewData.text = barcode.readableValue

                        binding.content.buttonAction.text = getString(R.string.open_in_email)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val selectorIntent = Intent(Intent.ACTION_SENDTO)
                                selectorIntent.data = Uri.parse(barcode.data)
                                startActivity(selectorIntent)

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_GEO -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.geo_point)
                        binding.content.textViewData.text = barcode.readableValue
                        binding.content.buttonAction.text = getString(R.string.open_in_maps)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val data = barcode.data.split("geo:")
                                val geos = data[1].split(",")
                                val directionUrl =
                                    "http://maps.google.com/maps?daddr=" + geos[0] + "," + geos[1]

                                if (PackageUtils.getAppState(
                                        this@QRScannerResultActivity,
                                        "com.google.android.apps.maps"
                                    )
                                ) {
                                    val intent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse(directionUrl)
                                    )
                                    startActivity(intent)

                                } else {
                                    Snackbar
                                        .make(
                                            binding.root,
                                            "Install or enable google maps to view location",
                                            Snackbar.LENGTH_SHORT
                                        ).show()
                                }

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_PHONE -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.phone_number)
                        binding.content.textViewData.text = barcode.readableValue

                        binding.content.buttonAction.text = getString(R.string.open_in_dialer)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val intent = Intent(Intent.ACTION_DIAL)
                                intent.data = Uri.parse(barcode.data)
                                startActivity(intent)

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_SMS -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.sms)
                        binding.content.textViewData.text = barcode.readableValue

                        binding.content.buttonAction.text = getString(R.string.open_in_sms)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val smsData = barcode.data.split(":")

                                if (smsData.isNotEmpty()) {

                                    // if barcode also contains sms body
                                    if (smsData.size > 1) {

                                        val uri = Uri.parse("smsto:${smsData[1]}")
                                        val intent = Intent(Intent.ACTION_SENDTO, uri)
                                        intent.putExtra("sms_body", smsData[2])
                                        startActivity(intent)

                                    } else {

                                        val uri = Uri.parse("smsto:${smsData[1]}")
                                        val intent = Intent(Intent.ACTION_SENDTO, uri)
                                        startActivity(intent)
                                    }
                                } else {

                                    Snackbar.make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    )
                                        .show()
                                }

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_TEXT -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.text)
                        binding.content.textViewData.text = barcode.readableValue

                        binding.content.buttonAction.text = getString(R.string.copy_to_clipboard)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val text: String = barcode.data
                                val myClip: ClipData = ClipData.newPlainText("text", text)
                                val clipboardManager: ClipboardManager =
                                    getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

                                clipboardManager.setPrimaryClip(myClip)

                                Snackbar
                                    .make(
                                        binding.root,
                                        "Text Copied",
                                        Snackbar.LENGTH_SHORT
                                    ).show()

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                Barcode.TYPE_WIFI -> {

                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = getString(R.string.wifi)
                        binding.content.textViewData.text = barcode.readableValue
                        binding.content.buttonAction.text = getString(R.string.connect_to_wifi)

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                startActivity(Intent(WifiManager.ACTION_PICK_WIFI_NETWORK))

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }

                else -> {

                    // show simple barcode
                    CoroutineScope(Dispatchers.Main).launch {

                        binding.content.textViewType.text = "Barcode"
                        binding.content.textViewData.text = barcode.readableValue
                        binding.content.buttonAction.text = "Search On Web"

                        binding.content.buttonAction.setOnClickListener {

                            try {

                                val url = "https://www.google.com/search?q=${barcode.data}"

                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

                            } catch (e: Exception) {

                                e.printStackTrace()

                                Snackbar
                                    .make(
                                        binding.root,
                                        "An error occurred",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                            }
                        }
                    }
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun setBarcodeImage(barcodeImage: Bitmap?) {

        try {

            if (barcodeImage != null) {

                CoroutineScope(Dispatchers.Main).launch {

                    binding.content.imageViewQrCode.setImageBitmap(barcodeImage)
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }
}