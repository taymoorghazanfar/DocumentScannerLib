package com.example.utilityapp.common.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.common.repository.RemoteRepository

class RemoteViewModel(application: Application) : AndroidViewModel(application) {

    private var repository: RemoteRepository = RemoteRepository()
    private var remoteLiveData: MutableLiveData<Boolean> =
        repository.getRemoteLiveData()

    fun getRemoteLiveData(): MutableLiveData<Boolean> {

        return this.remoteLiveData
    }

    fun getTranslationApiUrl() {

        repository.getRemoteData()
    }
}