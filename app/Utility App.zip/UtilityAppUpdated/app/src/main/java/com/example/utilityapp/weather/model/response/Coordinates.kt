package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Coordinates {

    @SerializedName("lat")
    var lat:Double

    @SerializedName("lon")
    var lng:Double

    constructor(lat: Double, lng: Double) {
        this.lat = lat
        this.lng = lng
    }
}