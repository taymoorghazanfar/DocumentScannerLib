package com.example.utilityapp.translator.image.ui.activities

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.common.util.ImageUtils
import com.example.utilityapp.databinding.ActivityImageTranslatorBinding
import com.example.utilityapp.translator.common.ui.adapters.LanguageAdapter
import com.example.utilityapp.translator.image.viewmodel.ImageTranslatorViewModel
import com.example.utilityapp.translator.text.ui.activities.TextTranslatorActivity
import com.example.utilityapp.translator.utils.LanguagesManager
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ImageTranslatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImageTranslatorBinding
    private lateinit var viewModel: ImageTranslatorViewModel

    private var sourceLanguageName: String? = null
    private var sourceLanguageCode: String? = null
    private var targetLanguageName: String? = null
    private var targetLanguageCode: String? = null

    private var sourceClicks = 0
    private var targetClicks = 0
    private var currentSourceIndex = 0
    private var currentTargetIndex = 0

    private lateinit var bitmap: Bitmap
    private lateinit var uri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageTranslatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getData()

        initViewModel()

        setupHeader()

        initViews()
    }

    private fun getData() {

        try {

            CoroutineScope(Dispatchers.IO).launch {

                uri = intent.getParcelableExtra("uri")!!
                intent.getBooleanExtra("camera", false)

                val sourceBitmap =
                    ImageUtils.getThumbnail(this@ImageTranslatorActivity, uri, 500.0)!!

                /////////////////////////////////////

                val exif = ExifInterface(uri.path!!)
                val rotation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
                val rotationInDegrees: Int = exifToDegrees(rotation)
                val matrix = Matrix()
                if (rotation != 0) {
                    matrix.preRotate(rotationInDegrees.toFloat())
                }

                bitmap = Bitmap.createBitmap(
                    sourceBitmap,
                    0,
                    0,
                    sourceBitmap.width,
                    sourceBitmap.height,
                    matrix,
                    true
                );
                /////////////////////////////////////

                CoroutineScope(Dispatchers.Main).launch {

                    binding.content.imageView.setImageBitmap(bitmap)
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()

            val builder = AlertDialog.Builder(this)
            builder.setTitle("An error occurred")
            builder.setMessage("Please try again later")
            builder.setCancelable(false)

            builder.setPositiveButton("OK") { _, _ ->
                finish()
            }

            builder.show()
        }
    }

    private fun exifToDegrees(exifOrientation: Int): Int {
        return when (exifOrientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> {
                90
            }
            ExifInterface.ORIENTATION_ROTATE_180 -> {
                180
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> {
                270
            }
            else -> 0
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[ImageTranslatorViewModel::class.java]
        viewModel.init()

        viewModel
            .getTextLiveData()
            .observe(this@ImageTranslatorActivity) { text ->

                if (text == null) {

                    Snackbar
                        .make(
                            binding.root,
                            "Failed to recognize text in the image",
                            Snackbar.LENGTH_SHORT
                        )
                        .show()

                } else {

                    val i = Intent(this@ImageTranslatorActivity, TextTranslatorActivity::class.java)
                    i.putExtra("text", text)
                    i.putExtra("source", currentSourceIndex)
                    i.putExtra("target", currentTargetIndex)

                    startActivity(i)
                    finish()
                }
            }
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Image Translator"

        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonScan.setOnClickListener {

            Log.d("scan_result", "initViews: starting scan")
            viewModel.scanImage(bitmap)
        }

        // source spinner
        val languageAdapterSource = LanguageAdapter(
            this@ImageTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterSource.init(0)
        binding.content.spinnerSourceLanguage.adapter = languageAdapterSource
        binding.content.spinnerSourceLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (sourceClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == targetLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentSourceIndex = parent.selectedItemPosition
                            setSourceLanguage(selectedLanguage)
                        }
                    }
                }
            }

        // target spinner
        val languageAdapterTarget = LanguageAdapter(
            this@ImageTranslatorActivity,
            LanguagesManager.languages.keys.toList()
        )
        languageAdapterTarget.init(1)
        binding.content.spinnerTargetLanguage.adapter = languageAdapterTarget
        binding.content.spinnerTargetLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (targetClicks++ >= 1) {

                        val selectedLanguage = parent!!.getItemAtPosition(position).toString()

                        if (selectedLanguage == sourceLanguageName) {

                            // swap languages
                            swapLanguages(currentSourceIndex, currentTargetIndex)

                        } else {

                            currentTargetIndex = parent.selectedItemPosition
                            setTargetLanguage(selectedLanguage)
                        }
                    }
                }
            }

        // switch language button
        binding.content.buttonSwitchLanguage.setOnClickListener {

            val sourceLanguageIndex = binding.content.spinnerSourceLanguage.selectedItemPosition
            val targetLanguageIndex = binding.content.spinnerTargetLanguage.selectedItemPosition

            swapLanguages(sourceLanguageIndex, targetLanguageIndex)
        }

        // initially setting languages
        binding.content.spinnerSourceLanguage.setSelection(0)
        binding.content.spinnerTargetLanguage.setSelection(1)

        currentSourceIndex = 0
        currentTargetIndex = 1

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }

    private fun setSourceLanguage(languageName: String) {

        sourceLanguageName = languageName
        sourceLanguageCode = LanguagesManager.languages[sourceLanguageName]
    }

    private fun setTargetLanguage(languageName: String) {

        targetLanguageName = languageName
        targetLanguageCode = LanguagesManager.languages[targetLanguageName]
    }

    private fun swapLanguages(sourceLanguageIndex: Int, targetLanguageIndex: Int) {

        currentSourceIndex = targetLanguageIndex
        currentTargetIndex = sourceLanguageIndex

        binding.content.spinnerSourceLanguage.setSelection(targetLanguageIndex)
        binding.content.spinnerTargetLanguage.setSelection(sourceLanguageIndex)

        setSourceLanguage(binding.content.spinnerSourceLanguage.selectedItem.toString())
        setTargetLanguage(binding.content.spinnerTargetLanguage.selectedItem.toString())
    }
}