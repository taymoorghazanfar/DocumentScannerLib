package com.example.utilityapp.qrscanner.util

import com.google.mlkit.vision.barcode.common.Barcode

class BarcodeReadableDataParser {

    companion object {

        fun getBarcodeReadableData(barcode: Barcode): String? {

            when (barcode.valueType) {

                Barcode.TYPE_URL -> {

                    return getUrlReadableData(barcode)
                }

                Barcode.TYPE_CALENDAR_EVENT -> {

                    return getCalenderEventReadableData(barcode)
                }

                Barcode.TYPE_CONTACT_INFO -> {

                    return getContactReadableData(barcode)
                }

                Barcode.TYPE_EMAIL -> {

                    return getEmailReadableData(barcode)
                }

                Barcode.TYPE_GEO -> {

                    return getLocationReadableData(barcode)
                }

                Barcode.TYPE_PHONE -> {

                    return getPhoneReadableData(barcode)
                }

                Barcode.TYPE_SMS -> {

                    return getSmsReadableData(barcode)
                }

                Barcode.TYPE_TEXT -> {

                    return getTextReadableData(barcode)
                }

                Barcode.TYPE_WIFI -> {

                    return getWifiReadableData(barcode)
                }
                else -> {

                    return barcode.rawValue
                }
            }
        }

        fun getWifiReadableData(
            barcode: Barcode? = null,
            ssid: String? = null,
            securityType: Int? = null,
            password: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.wifi == null) {

                    return null
                }

                var data = ""

                if (!barcode.wifi!!.ssid.isNullOrEmpty()) {

                    data += "ssid: " + barcode.wifi!!.ssid.toString()
                }

                data += when (barcode.wifi!!.encryptionType) {
                    Barcode.WiFi.TYPE_WPA -> {

                        "\nsecurity: WPA"

                    }
                    Barcode.WiFi.TYPE_WEP -> {

                        "\nsecurity: WEP"
                    }
                    else -> {

                        "\nsecurity: None"
                    }
                }

                if (!barcode.wifi!!.password.isNullOrEmpty()) {

                    data += "\npassword: " + barcode.wifi!!.password.toString()
                }

                return data
            }

            return when (securityType) {

                Barcode.WiFi.TYPE_WPA -> {

                    "ssid: $ssid\nsecurity: WPA\npassword: $password"
                }

                Barcode.WiFi.TYPE_WEP -> {

                    "ssid: $ssid\nsecurity: WEP\npassword: $password"
                }

                else -> {

                    "ssid: $ssid\nsecurity: None"
                }
            }
        }

        fun getTextReadableData(barcode: Barcode? = null, text: String? = null): String? {

            if (barcode != null) {

                if (barcode.rawValue == null) {

                    return null
                }

                return barcode.rawValue.toString()
            }

            return text
        }

        fun getSmsReadableData(
            barcode: Barcode? = null,
            phoneNumber: String? = null,
            message: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.sms == null) {

                    return null
                }

                var data = ""

                if (!barcode.sms!!.phoneNumber.isNullOrEmpty()) {

                    data += "phone number: " + barcode.sms!!.phoneNumber.toString()
                }

                if (!barcode.sms!!.message.isNullOrEmpty()) {

                    data += "\nmessage: " + barcode.sms!!.message.toString()
                }

                return data
            }

            return "phone number: $phoneNumber\nmessage: $message"
        }

        fun getPhoneReadableData(barcode: Barcode? = null, phoneNumber: String? = null): String? {

            if (barcode != null) {

                if (barcode.phone == null) {

                    return null
                }

                var phoneNumber1 = ""

                if (!barcode.phone!!.number.isNullOrEmpty()) {

                    phoneNumber1 = barcode.phone!!.number.toString()
                }

                return phoneNumber1
            }

            return phoneNumber
        }

        fun getLocationReadableData(
            barcode: Barcode? = null,
            lat: Float? = null,
            lng: Float? = null

        ): String? {

            if (barcode != null) {

                if (barcode.geoPoint == null) {

                    return null
                }

                return "lat: ${barcode.geoPoint!!.lat}\nlng: ${barcode.geoPoint!!.lng}"
            }

            return "lat: $lat\nlng: $lng"
        }

        fun getEmailReadableData(
            barcode: Barcode? = null,
            address: String? = null,
            subject: String? = null,
            body: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.email == null) {

                    return null
                }

                var data = ""

                if (!barcode.email!!.address.isNullOrEmpty()) {

                    data += "address: " + barcode.email!!.address.toString()
                }

                if (!barcode.email!!.subject.isNullOrEmpty()) {

                    data += "\nsubject: " + barcode.email!!.subject.toString()
                }

                if (!barcode.email!!.body.isNullOrEmpty()) {

                    data += "\nbody: " + barcode.email!!.body.toString()
                }

                return data
            }

            return "address: $address\nsubject: $subject\nbody: $body"
        }

        fun getContactReadableData(
            barcode: Barcode? = null,
            firstName: String? = null,
            lastName: String? = null,
            phone: String? = null,
            email: String? = null,
            company: String? = null,
            address: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.contactInfo == null) {

                    return null
                }

                var rawValue = ""

                if (!barcode.contactInfo!!.name?.first.isNullOrEmpty()) {

                    rawValue += "first name: " + barcode.contactInfo!!.name!!.first.toString()
                }

                if (!barcode.contactInfo!!.name?.last.isNullOrEmpty()) {

                    rawValue += if (rawValue == "") {

                        "name: " + barcode.contactInfo!!.name!!.last.toString()

                    } else {

                        "\nlast name: " + barcode.contactInfo!!.name!!.last.toString()
                    }
                }

                if (!barcode.contactInfo!!.phones[0].number.isNullOrEmpty()) {

                    rawValue += "\nphone number: " + barcode.contactInfo!!.phones[0].number.toString()
                }

                if (!barcode.contactInfo!!.emails[0].address.isNullOrEmpty()) {

                    rawValue += "\nemail: " + barcode.contactInfo!!.emails[0].address.toString()
                }

                if (!barcode.contactInfo!!.organization.isNullOrEmpty()) {

                    rawValue += "\ncompany: " + barcode.contactInfo!!.organization.toString()
                }

                if (barcode.contactInfo!!.addresses.isNotEmpty()) {

                    if (barcode.contactInfo!!.addresses[0].addressLines.isNotEmpty()) {

                        rawValue += "\naddress: " + barcode.contactInfo!!.addresses[0].addressLines[0].toString()
                    }
                }

                return rawValue
            }

            return "full name: $firstName $lastName\n" +
                    "company: $company\n" +
                    "address: $address\n" +
                    "phone number: $phone\n" +
                    "email: $email"
        }

        fun getCalenderEventReadableData(
            barcode: Barcode? = null,
            summary: String? = null,
            location: String? = null,
            start: String? = null,
            end: String? = null,
            description: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.calendarEvent == null) {

                    return null
                }

                var rawValue = ""

                if (!barcode.calendarEvent!!.summary.isNullOrEmpty()) {

                    rawValue += "summary: " + barcode.calendarEvent!!.summary!!
                }

                if (!barcode.calendarEvent!!.location.isNullOrEmpty()) {

                    rawValue += "\nlocation: " + barcode.calendarEvent!!.location.toString()
                }

                if (barcode.calendarEvent!!.start != null) {

                    val startValue = barcode.calendarEvent!!.start

                    val time =
                        startValue!!.year.toString() +
                                startValue.month.toString() +
                                startValue.day.toString() + "T" +
                                startValue.hours.toString() +
                                startValue.minutes.toString() +
                                startValue.seconds.toString()

                    rawValue += "\nstart date: $time"
                }

                if (barcode.calendarEvent!!.end != null) {

                    val endValue = barcode.calendarEvent!!.end

                    val time =
                        endValue!!.year.toString() +
                                endValue.month.toString() +
                                endValue.day.toString() + "T" +
                                endValue.hours.toString() +
                                endValue.minutes.toString() +
                                endValue.seconds.toString()

                    rawValue += "\nend date: $time"
                }

                if (!barcode.calendarEvent!!.description.isNullOrEmpty()) {

                    rawValue += "\ndescription: " + barcode.calendarEvent!!.description.toString()
                }

                return rawValue
            }

            return "summary: $summary\n" +
                    "location: $location\n" +
                    "description: $description\n" +
                    "start date: $start\n" +
                    "end date: $end\n"
        }

        fun getUrlReadableData(barcode: Barcode? = null, url: String? = null): String? {

            if (barcode != null) {

                if (barcode.url == null) {

                    return null
                }

                return barcode.url!!.url
            }

            return url
        }
    }
}