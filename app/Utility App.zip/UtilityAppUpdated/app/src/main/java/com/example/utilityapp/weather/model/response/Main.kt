package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Main {

    @SerializedName("temp")
    var temp: Double

    @SerializedName("feels_like")
    var feelsLike: Double

    @SerializedName("temp_min")
    var minimumTemperature: Double

    @SerializedName("temp_max")
    var maximumTemperature: Double

    @SerializedName("pressure")
    var pressure: Int

    @SerializedName("humidity")
    var humidity: Int

    @SerializedName("sea_level")
    var seaLevel: Int

    @SerializedName("grnd_level")
    var groundLevel: Int

    constructor(
        temp: Double,
        feelsLike: Double,
        minimumTemperature: Double,
        maximumTemperature: Double,
        pressure: Int,
        humidity: Int,
        seaLevel: Int,
        groundLevel: Int
    ) {
        this.temp = temp
        this.feelsLike = feelsLike
        this.minimumTemperature = minimumTemperature
        this.maximumTemperature = maximumTemperature
        this.pressure = pressure
        this.humidity = humidity
        this.seaLevel = seaLevel
        this.groundLevel = groundLevel
    }
}