package com.example.utilityapp.common.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.media.Image
import android.net.Uri
import android.renderscript.*
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer


class ImageUtils {

    companion object {

        @Throws(FileNotFoundException::class, IOException::class)
        fun getThumbnail(context: Context, uri: Uri?, thumbnailSize: Double): Bitmap? {

            try {

                var input: InputStream? = context.contentResolver.openInputStream(uri!!)
                val onlyBoundsOptions = BitmapFactory.Options()
                onlyBoundsOptions.inJustDecodeBounds = true
                onlyBoundsOptions.inDither = true //optional
                onlyBoundsOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //optional
                BitmapFactory.decodeStream(input, null, onlyBoundsOptions)
                input?.close()
                if (onlyBoundsOptions.outWidth == -1 || onlyBoundsOptions.outHeight == -1) {
                    return null
                }
                val originalSize =
                    if (onlyBoundsOptions.outHeight > onlyBoundsOptions.outWidth) onlyBoundsOptions.outHeight else onlyBoundsOptions.outWidth
                val ratio = if (originalSize > thumbnailSize) originalSize / thumbnailSize else 1.0
                val bitmapOptions = BitmapFactory.Options()
                bitmapOptions.inSampleSize = getPowerOfTwoForSampleRatio(ratio)
                bitmapOptions.inDither = true //optional
                bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //
                input = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions)
                input?.close()

                return bitmap

            } catch (e: Exception) {

                return null
            }
        }

        private fun getPowerOfTwoForSampleRatio(ratio: Double): Int {
            val k = Integer.highestOneBit(Math.floor(ratio).toInt())
            return if (k == 0) 1 else k
        }

        fun cropToSquare(bitmap: Bitmap?): Bitmap? {

            return try {

                val width = bitmap!!.width
                val height = bitmap.height
                val newWidth = if (height > width) width else height
                val newHeight = if (height > width) height - (height - width) else height
                var cropW = (width - height) / 2
                cropW = if (cropW < 0) 0 else cropW
                var cropH = (height - width) / 2
                cropH = if (cropH < 0) 0 else cropH

                Bitmap.createBitmap(bitmap, cropW, cropH, newWidth, newHeight)

            } catch (e: Exception) {

                null
            }
        }

        fun getRotatedBitmap2(bmp: Bitmap, rotation: Int): Bitmap? {
            val matrix = Matrix()
            matrix.preRotate(rotation.toFloat())
            return Bitmap.createBitmap(
                bmp, 0, 0,
                bmp.width, bmp.height,
                matrix, false
            )
        }

        fun getBitmapFromImage(image: Image?): Bitmap? {

            return try {

                val buffer: ByteBuffer = image!!.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)

                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, null)

            } catch (e: Exception) {

                null
            }
        }

        fun bitmapToBase64(bitmap: Bitmap?): String? {

            return try {

                // further compress if performance issue exist
                val stream = ByteArrayOutputStream()
                bitmap?.compress(Bitmap.CompressFormat.JPEG, 50, stream)
                val bytes: ByteArray = stream.toByteArray()

                Base64.encodeToString(bytes, Base64.DEFAULT)

            } catch (e: Exception) {

                null
            }
        }

        fun base64ToBitmap(base64String: String?): Bitmap? {

            return try {

                val decodedBytes: ByteArray = Base64.decode(base64String, Base64.DEFAULT)

                BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)

            } catch (e: Exception) {

                null
            }
        }

        fun yuv420ToBitmap(image: Image?, context: Context): Bitmap? {

            try {

                val rs = RenderScript.create(context)
                val script = ScriptIntrinsicYuvToRGB.create(rs, Element.U8_4(rs))

                // Refer the logic in a section below on how to convert a YUV_420_888 image
                // to single channel flat 1D array. For sake of this example I'll abstract it
                // as a method.
                val yuvByteArray: ByteArray? = image2byteArray(image)
                val yuvType: Type.Builder =
                    Type.Builder(rs, Element.U8(rs)).setX(yuvByteArray!!.size)
                val `in` = Allocation.createTyped(rs, yuvType.create(), Allocation.USAGE_SCRIPT)
                val rgbaType: Type.Builder = Type.Builder(rs, Element.RGBA_8888(rs))
                    .setX(image!!.width)
                    .setY(image.height)
                val out = Allocation.createTyped(rs, rgbaType.create(), Allocation.USAGE_SCRIPT)

                // The allocations above "should" be cached if you are going to perform
                // repeated conversion of YUV_420_888 to Bitmap.
                `in`.copyFrom(yuvByteArray)
                script.setInput(`in`)
                script.forEach(out)
                val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
                out.copyTo(bitmap)

                return bitmap

            } catch (e: Exception) {

                return null
            }
        }

        private fun image2byteArray(image: Image?): ByteArray? {

            try {
                require(image!!.format == ImageFormat.YUV_420_888) { "Invalid image format" }
                val width = image.width
                val height = image.height
                val yPlane = image.planes[0]
                val uPlane = image.planes[1]
                val vPlane = image.planes[2]
                val yBuffer = yPlane.buffer
                val uBuffer = uPlane.buffer
                val vBuffer = vPlane.buffer

                // Full size Y channel and quarter size U+V channels.
                val numPixels = (width * height * 1.5f).toInt()
                val nv21 = ByteArray(numPixels)
                var index = 0

                // Copy Y channel.
                val yRowStride = yPlane.rowStride
                val yPixelStride = yPlane.pixelStride
                for (y in 0 until height) {
                    for (x in 0 until width) {
                        nv21[index++] = yBuffer[y * yRowStride + x * yPixelStride]
                    }
                }

                // Copy VU data; NV21 format is expected to have YYYYVU packaging.
                // The U/V planes are guaranteed to have the same row stride and pixel stride.
                val uvRowStride = uPlane.rowStride
                val uvPixelStride = uPlane.pixelStride
                val uvWidth = width / 2
                val uvHeight = height / 2
                for (y in 0 until uvHeight) {
                    for (x in 0 until uvWidth) {
                        val bufferIndex = y * uvRowStride + x * uvPixelStride
                        // V channel.
                        nv21[index++] = vBuffer[bufferIndex]
                        // U channel.
                        nv21[index++] = uBuffer[bufferIndex]
                    }
                }

                return nv21

            } catch (e: Exception) {

                return null
            }
        }

        fun scaleToFitWidth(b: Bitmap, width: Int): Bitmap? {
            val factor = width / b.width.toFloat()
            return Bitmap.createScaledBitmap(b, width, (b.height * factor).toInt(), true)
        }

        fun scaleToFitHeight(b: Bitmap, height: Int): Bitmap? {
            val factor = height / b.height.toFloat()
            return Bitmap.createScaledBitmap(b, (b.width * factor).toInt(), height, true)
        }
    }
}