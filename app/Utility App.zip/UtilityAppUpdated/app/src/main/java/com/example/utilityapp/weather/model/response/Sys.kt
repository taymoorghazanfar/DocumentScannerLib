package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Sys {

    @SerializedName("type")
    var type: Int

    @SerializedName("id")
    var id: Int

    @SerializedName("country")
    var country: String

    @SerializedName("sunrise")
    var sunrise: Long

    @SerializedName("sunset")
    var sunset: Long

    constructor(type: Int, id: Int, country: String, sunrise: Long, sunset: Long) {
        this.type = type
        this.id = id
        this.country = country
        this.sunrise = sunrise
        this.sunset = sunset
    }
}