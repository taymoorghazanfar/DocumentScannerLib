package com.example.utilityapp.translator.common.repository

import androidx.lifecycle.LiveData
import com.example.utilityapp.translator.common.data.database.TranslationsDao
import com.example.utilityapp.translator.model.MTranslation

class TranslationsRepository(private val translationsDao: TranslationsDao) {

    val allTranslations: LiveData<List<MTranslation>> = translationsDao.getAllTranslations()

    suspend fun insert(translations: MTranslation) {
        translationsDao.insert(translations)
    }

    suspend fun deleteById(id: Int) {
        translationsDao.deleteById(id)
    }

    suspend fun update(translation: MTranslation) {
        translationsDao.update(translation)
    }
}