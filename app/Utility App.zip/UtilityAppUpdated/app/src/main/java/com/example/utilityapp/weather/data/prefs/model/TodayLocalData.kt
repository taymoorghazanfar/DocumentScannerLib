package com.example.utilityapp.weather.data.prefs.model

import com.example.utilityapp.weather.model.TodayData
import com.example.utilityapp.weather.model.WeatherData

class TodayLocalData {

    var dateFetched:String
    var lat:Double
    var lng:Double
    var todayData:List<TodayData>

    constructor(dateFetched: String, lat: Double, lng: Double, todayData: List<TodayData>) {
        this.dateFetched = dateFetched
        this.lat = lat
        this.lng = lng
        this.todayData = todayData
    }
}