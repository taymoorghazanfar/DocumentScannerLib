package com.example.utilityapp.weather.ui.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.utilityapp.R
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.weather.model.TodayData
import java.text.SimpleDateFormat

class RecyclerAdapterToday(
    val context: Context,
) :
    RecyclerView.Adapter<RecyclerAdapterToday.ViewHolder>() {

    private val data = ArrayList<TodayData>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val textViewTemperature: TextView = itemView.findViewById(R.id.text_view_temperature)
        val textViewTime: TextView = itemView.findViewById(R.id.text_view_time)
        val imageViewIcon: ImageView = itemView.findViewById(R.id.image_view_icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_item_today_weather,
            parent, false
        )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val today = data[position]

        holder.textViewTime.text = today.time

        holder.textViewTemperature.text = today.temperature

        Glide
            .with(context)
            .load(RemoteConfig.weatherApiImageUrl + today.iconUrl)
            .into(holder.imageViewIcon)
    }

    override fun getItemCount(): Int {

        return data.size
    }

    @SuppressLint("SimpleDateFormat")
    fun updateData(newList: List<TodayData>) {

        data.clear()
        data.addAll(newList)

        // sort all barcodes
        data.sortedByDescending { today ->

            val sdf = SimpleDateFormat("hh:mm a")
            sdf.parse(today.time)?.time
        }

        notifyItemRangeChanged(0, data.size)
    }
}