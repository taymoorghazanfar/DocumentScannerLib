package com.example.utilityapp.qrscanner.ui.activities.generator

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityQrGeneratorResultBinding
import com.example.utilityapp.qrscanner.model.MBarcode
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.*

class QrGeneratorResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQrGeneratorResultBinding
    private lateinit var viewModel: QrCodeViewModel
    private lateinit var barcode: MBarcode
    private var bitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrGeneratorResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getData()
        setupHeader()
        initViewModel()
    }

    private fun getData() {

        try {

            barcode = intent.getSerializableExtra("barcode") as MBarcode

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()
        viewModel.getBarcodeImageLiveData().observe(this) { barcodeBitmap ->

            bitmap = barcodeBitmap
            setupViews()
        }

        viewModel.generateBarcodeImage(barcode.data, true)
    }

    private fun setupViews() {

        setQrCodeImage(bitmap)

        binding.content.buttonSave.setOnClickListener {

            saveQrCode()
        }

        binding.content.buttonShare.setOnClickListener {

            shareQrCode()
        }
    }

    private fun saveQrCode() {

        if (!isPermissionGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_CODE_STORAGE_PERMISSION
            )
        } else {

            saveQrCodeToStorage()
        }
    }

    private fun saveQrCodeToStorage() {

        try {

            if (bitmap == null) {

                Snackbar.make(
                    binding.root,
                    "Failed to save QR code",
                    Snackbar.LENGTH_SHORT
                ).show()

                return
            }

            val filename = "BARCODE_${System.currentTimeMillis()}.jpg"

            var fos: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                contentResolver?.also { resolver ->

                    val contentValues = ContentValues().apply {

                        put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpg")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                    }

                    val imageUri: Uri? =
                        resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    fos = imageUri?.let { resolver.openOutputStream(it) }
                }

            } else {

                val imagesDir =
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val image = File(imagesDir, filename)

                fos = FileOutputStream(image)
            }
            fos?.use {

                bitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, it)
                Snackbar.make(
                    binding.root,
                    "QR code saved to /Pictures",
                    Snackbar.LENGTH_SHORT
                ).show()
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun shareQrCode() {

        try {

            CoroutineScope(Dispatchers.Default).launch {

                if (bitmap == null) {

                    CoroutineScope(Dispatchers.Main).launch {

                        Snackbar.make(
                            binding.root,
                            "Failed to share QR code",
                            Snackbar.LENGTH_SHORT
                        )
                            .show()
                    }

                } else {

                    CoroutineScope(Dispatchers.Main).launch {

                        val cachePath = File(externalCacheDir, "cached_images/")
                        cachePath.mkdirs()

                        //create png file
                        val file = File(cachePath, "BARCODE_${System.currentTimeMillis()}.jpg")
                        val fileOutputStream: FileOutputStream
                        try {
                            fileOutputStream = FileOutputStream(file)
                            bitmap!!.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
                            fileOutputStream.flush()
                            fileOutputStream.close()
                        } catch (e: FileNotFoundException) {
                            e.printStackTrace()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }

                        val myImageFileUri: Uri = FileProvider.getUriForFile(
                            this@QrGeneratorResultActivity,
                            applicationContext.packageName + ".provider",
                            file
                        )

                        val intent = Intent(Intent.ACTION_SEND)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        intent.putExtra(Intent.EXTRA_STREAM, myImageFileUri)
                        intent.type = "image/jpg"
                        startActivity(Intent.createChooser(intent, "Share with"))
                    }
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun setQrCodeImage(bitmap: Bitmap?) {

        try {

            if (bitmap != null) {

                CoroutineScope(Dispatchers.Main).launch {

                    binding.content.imageViewQrCode.setImageBitmap(bitmap)
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = StringUtils.getBarcodeType(barcode.type)

        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun isPermissionGranted(permission: String): Boolean {

        return ContextCompat
            .checkSelfPermission(baseContext, permission) ==
                PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {

            if (!isPermissionGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                Snackbar.make(
                    binding.root,
                    "Storage permission is required to save QR code",
                    Snackbar.LENGTH_SHORT
                ).show()

                return
            }

            saveQrCodeToStorage()
        }
    }

    companion object {

        private const val REQUEST_CODE_STORAGE_PERMISSION = 0
    }
}