package com.example.utilityapp.pdfreader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.utilityapp.common.lifecycle.SingleLiveEvent
import com.example.utilityapp.pdfreader.data.database.PdfsDatabase
import com.example.utilityapp.pdfreader.model.MPdf
import com.example.utilityapp.pdfreader.repository.PdfsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PdfFilesViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var repository: PdfsRepository
    private lateinit var recentPdfFilesLiveData: LiveData<List<MPdf>>
    var queryPdf: SingleLiveEvent<MPdf> = SingleLiveEvent()
    var insertedPdfId: SingleLiveEvent<Long> = SingleLiveEvent()

    fun init() {

        repository = PdfsRepository(PdfsDatabase.getDatabase(getApplication()).getMPdfsDao())
        this.recentPdfFilesLiveData = repository.allPdfs
    }

    fun getRecentPdfFilesLiveData(): LiveData<List<MPdf>> {

        return this.recentPdfFilesLiveData
    }

    fun getPdfByUri(uri: String) {

        viewModelScope.launch(Dispatchers.IO) {

            val pdf: MPdf = repository.getPdf(uri)

            viewModelScope.launch(Dispatchers.Main) {

                queryPdf.value = pdf
            }
        }
    }

    fun savePdfFile(pdf: MPdf) =
        viewModelScope.launch(Dispatchers.IO) {

            val id: Long = repository.insert(pdf)

            viewModelScope.launch(Dispatchers.Main) {

                insertedPdfId.value = id
            }
        }

    fun updatePdfFile(pdf: MPdf) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(pdf)
        }

    fun deletePdfFile(id: Int) {

        viewModelScope.launch(Dispatchers.IO) {

            repository.deleteById(id)
        }
    }
}