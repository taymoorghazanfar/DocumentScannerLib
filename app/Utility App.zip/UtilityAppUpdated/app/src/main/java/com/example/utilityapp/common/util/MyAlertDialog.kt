package com.example.utilityapp.common.util

import android.app.AlertDialog
import android.content.Context
import com.example.utilityapp.common.interfaces.IAlertButtonClickListener

class MyAlertDialog {

    companion object {

        val ACTION_FINISH = 0
        val ACTION_CANCEL = 1

        fun showAlert(
            context: Context,
            listener: IAlertButtonClickListener,
            title: String,
            message: String,
            action: Int
        ) {

            val builder = AlertDialog.Builder(context)
            builder.setTitle(title)
            builder.setMessage(message)

            builder.setPositiveButton("OK") { _, _ ->

                listener.onAlertButtonClick(action)
            }

//            builder.setNegativeButton(android.R.string.no) { dialog, which ->
//                Toast.makeText(
//                    context,
//                    android.R.string.no, Toast.LENGTH_SHORT
//                ).show()
//            }

//            builder.setNeutralButton("Maybe") { dialog, which ->
//                Toast.makeText(
//                    context,
//                    "Maybe", Toast.LENGTH_SHORT
//                ).show()
//            }
            builder.show()
        }
    }
}