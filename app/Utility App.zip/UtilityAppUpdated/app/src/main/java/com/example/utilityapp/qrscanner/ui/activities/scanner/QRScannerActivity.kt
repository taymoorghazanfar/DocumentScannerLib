package com.example.utilityapp.qrscanner.ui.activities.scanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.Surface
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.R
import com.example.utilityapp.common.interfaces.IAlertButtonClickListener
import com.example.utilityapp.common.util.ImageUtils
import com.example.utilityapp.common.util.MyAlertDialog
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityQrscannerBinding
import com.example.utilityapp.qrscanner.model.MBarcode
import com.example.utilityapp.qrscanner.util.BarcodeDataParser
import com.example.utilityapp.qrscanner.util.BarcodeReadableDataParser
import com.example.utilityapp.qrscanner.viewmodel.CameraViewModel
import com.example.utilityapp.qrscanner.viewmodel.QRScannerActivityViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class QRScannerActivity : AppCompatActivity(), IAlertButtonClickListener {

    private var binding: ActivityQrscannerBinding? = null
    private var viewModel: QRScannerActivityViewModel? = null
    private var previewView: PreviewView? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraControl: CameraControl? = null
    private var cameraInfo: CameraInfo? = null
    private var cameraSelector: CameraSelector? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var previewUseCase: Preview? = null
    private var analysisUseCase: ImageAnalysis? = null

    private val screenAspectRatio: Int
        get() {
            val metrics = DisplayMetrics().also { previewView?.display?.getRealMetrics(it) }
            return aspectRatio(metrics.widthPixels, metrics.heightPixels)
        }

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { imageUri ->

        if (imageUri != null) {

            CoroutineScope(Dispatchers.Default).launch {

                //todo: decrease size if performance is slow
                val bitmap = ImageUtils.getThumbnail(this@QRScannerActivity, imageUri, 200.0)!!

                withContext(Dispatchers.Main) {

                    viewModel?.scanGalleryImage(
                        this@QRScannerActivity,
                        bitmap,
                        true
                    )
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrscannerBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        binding!!.textViewTitle.text = getString(R.string.scan_qr)

        if (!isPermissionGranted(Manifest.permission.CAMERA)) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                REQUEST_CODE_CAMERA_PERMISSION
            )

            return
        }

        init()
    }

    private fun init() {

        setupCamera()
        initViews()
        initViewModel()
    }

    private fun initViews() {

        binding?.buttonBack?.setOnClickListener {

            finish()
        }

        binding?.buttonSwitchCamera?.setOnClickListener {

            toggleCamera()
        }

        binding!!.zoomSeekbar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar, progress: Int,
                fromUser: Boolean
            ) {

                try {

                    val zoomValue = getSeekbarZoomValue(progress)

                    cameraControl?.setLinearZoom(zoomValue)

                } catch (e: Exception) {

                    e.printStackTrace()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
            }
        })

        binding!!.buttonGallery.setOnClickListener {

            if (!isPermissionGranted(Manifest.permission.READ_EXTERNAL_STORAGE)) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    REQUEST_CODE_STORAGE_PERMISSION
                )
            } else {

                pickImage.launch("image/*")
            }
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QRScannerActivityViewModel::class.java]

        viewModel!!.getImageScanLiveData().observe(this) { barcodeResult ->

            try {

                if (!stopScanning) {

                    if (barcodeResult != null) {

                        // if barcode scan was initiated from gallery and no barcode is found
                        if (barcodeResult.barcode == null && barcodeResult.isFromGallery) {

                            Snackbar.make(
                                binding!!.root,
                                "Error reading QR code or Barcode",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        }

                        // barcode is successfully found
                        else if (barcodeResult.barcode != null &&
                            barcodeResult.barcode.rawValue != null &&
                            !stopScanning
                        ) {
                            stopScanning = true

                            val data = BarcodeDataParser.getBarcodeData(barcodeResult.barcode)

                            val readableValue =
                                BarcodeReadableDataParser.getBarcodeReadableData(barcodeResult.barcode)

                            if (data != null && readableValue != null) {

                                val barcode = MBarcode(
                                    0,
                                    barcodeResult.barcode.valueType,
                                    0,
                                    data,
                                    readableValue,
                                    StringUtils.getCurrentDateTime()
                                )

                                val intent = Intent(this, QRScannerResultActivity::class.java)

                                intent.putExtra("barcode", barcode)
                                startActivityForResult(intent, REQUEST_CODE_SCAN_RESULT)
                            }
                        }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()
            }
        }
    }

    private fun setupCamera() {

        try {

            previewView = binding?.previewView

            cameraSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            ViewModelProvider(
                this, ViewModelProvider.AndroidViewModelFactory
                    .getInstance(application)
            )[CameraViewModel::class.java]
                .processCameraProvider
                .observe(this) { provider: ProcessCameraProvider? ->

                    cameraProvider = provider
                    bindCameraUseCases()
                }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun toggleCamera() {

        try {

            if (cameraProvider == null) {

                return
            }

            if (lensFacing == CameraSelector.LENS_FACING_BACK) {

                lensFacing = CameraSelector.LENS_FACING_FRONT
                binding!!.buttonTorch.isEnabled = false

            } else if (lensFacing == CameraSelector.LENS_FACING_FRONT) {

                lensFacing = CameraSelector.LENS_FACING_BACK
                binding!!.buttonTorch.isEnabled = true
            }

            cameraProvider!!.unbindAll()

            setupCamera()

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun bindCameraUseCases() {

        bindPreviewUseCase()
        bindAnalyseUseCase()
    }

    private fun bindPreviewUseCase() {

        try {

            if (cameraProvider == null) {

                return
            }
            if (previewUseCase != null) {

                cameraProvider!!.unbind(previewUseCase)
            }

            previewUseCase = Preview.Builder()
                .setTargetAspectRatio(screenAspectRatio)
                .setTargetRotation(Surface.ROTATION_90)
                .build()

            previewUseCase!!.setSurfaceProvider(previewView!!.surfaceProvider)

            try {
                val camera = cameraProvider!!.bindToLifecycle(
                    this,
                    cameraSelector!!,
                    previewUseCase
                )

                cameraControl = camera.cameraControl
                cameraInfo = camera.cameraInfo
                setupTorchControl()

            } catch (illegalStateException: IllegalStateException) {

                Log.e(TAG, illegalStateException.message ?: "IllegalStateException")

            } catch (illegalArgumentException: IllegalArgumentException) {

                Log.e(TAG, illegalArgumentException.message ?: "IllegalArgumentException")
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun bindAnalyseUseCase() {

        try {

            if (cameraProvider == null) {

                return
            }
            if (analysisUseCase != null) {

                cameraProvider!!.unbind(analysisUseCase)
            }

            analysisUseCase = ImageAnalysis.Builder()
                .setTargetAspectRatio(screenAspectRatio)
//            .setTargetRotation(Surface.ROTATION_90)
                .build()

            // Initialize our background executor
            val cameraExecutor = Executors.newSingleThreadExecutor()

            analysisUseCase?.setAnalyzer(
                cameraExecutor
            ) { imageProxy ->
                processImageProxy(imageProxy)
            }

            try {
                cameraProvider!!.bindToLifecycle(
                    this,
                    cameraSelector!!,
                    analysisUseCase,
                )
            } catch (illegalStateException: IllegalStateException) {

                Log.e(TAG, illegalStateException.message ?: "IllegalStateException")

            } catch (illegalArgumentException: IllegalArgumentException) {

                Log.e(TAG, illegalArgumentException.message ?: "IllegalArgumentException")
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun toggleTorch() {

        try {

            if (cameraInfo?.torchState?.value == TorchState.ON) {
                cameraControl?.enableTorch(false)
            } else {
                cameraControl?.enableTorch(true)
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun setupTorchControl() {

        try {

            binding!!.buttonTorch.setOnClickListener {

                toggleTorch()
            }
            cameraInfo?.torchState?.observe(this) { state ->
                if (state == TorchState.ON) {
                    binding!!.buttonTorch.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.btn_flash_on
                        )
                    )
                } else {
                    binding!!.buttonTorch.setImageDrawable(
                        ContextCompat.getDrawable(
                            this,
                            R.drawable.btn_flash_off
                        )
                    )
                }
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    @SuppressLint("UnsafeExperimentalUsageError", "UnsafeOptInUsageError")
    private fun processImageProxy(
        imageProxy: ImageProxy
    ) {

        try {

            CoroutineScope(Dispatchers.Main).launch {

                val inputImage =
                    InputImage.fromMediaImage(
                        imageProxy.image!!,
                        imageProxy.imageInfo.rotationDegrees
                    )

                viewModel?.processImage(inputImage, imageProxy, false)
            }

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    private fun getSeekbarZoomValue(progress: Int): Float {

        if (progress == 10) {

            return 1.0f
        }

        return ("0.$progress").toFloat()
    }

    private fun isPermissionGranted(permission: String): Boolean {

        return ContextCompat
            .checkSelfPermission(baseContext, permission) ==
                PackageManager.PERMISSION_GRANTED
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_SCAN_RESULT) {

            stopScanning = false
            binding?.zoomSeekbar?.progress = 0
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_CAMERA_PERMISSION) {

            if (!isPermissionGranted(Manifest.permission.CAMERA)) {
                MyAlertDialog.showAlert(
                    this,
                    this,
                    "Permissions Required",
                    "Camera permission is required to use this feature",
                    MyAlertDialog.ACTION_FINISH
                )

                return
            }

            init()

        } else if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {

            if (!isPermissionGranted(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                MyAlertDialog.showAlert(
                    this,
                    this,
                    "Permissions Required",
                    "Storage permission is required to use this feature",
                    MyAlertDialog.ACTION_CANCEL
                )

                return
            }

            pickImage.launch("image/*")
        }
    }

    private fun aspectRatio(width: Int, height: Int): Int {

        val previewRatio = max(width, height).toDouble() / min(width, height)

        if (abs(previewRatio - RATIO_4_3_VALUE) <= abs(previewRatio - RATIO_16_9_VALUE)) {

            return AspectRatio.RATIO_4_3
        }
        return AspectRatio.RATIO_16_9
    }

    override fun onAlertButtonClick(action: Int) {

        when (action) {

            MyAlertDialog.ACTION_FINISH -> finish()

            MyAlertDialog.ACTION_CANCEL -> {

                // do nothing
            }
        }
    }

    companion object {

        private const val TAG = "QRScannerActivity"
        private const val REQUEST_CODE_CAMERA_PERMISSION = 1
        private const val REQUEST_CODE_STORAGE_PERMISSION = 2
        private const val REQUEST_CODE_SCAN_RESULT = 3

        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0

        private var stopScanning: Boolean = false
    }
}