package com.example.utilityapp.pdfreader.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.utilityapp.pdfreader.model.MPdf

@Database(entities = [MPdf::class], version = 3, exportSchema = false)
abstract class PdfsDatabase : RoomDatabase() {

    abstract fun getMPdfsDao(): PdfsDao

    companion object {

        @Volatile
        private var INSTANCE: PdfsDatabase? = null

        fun getDatabase(context: Context): PdfsDatabase {

            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PdfsDatabase::class.java,
                    "pdfs_database"
                ).fallbackToDestructiveMigration().build()

                INSTANCE = instance

                instance
            }
        }
    }
}