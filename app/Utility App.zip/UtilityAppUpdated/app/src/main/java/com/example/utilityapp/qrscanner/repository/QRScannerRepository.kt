package com.example.utilityapp.qrscanner.repository

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.camera.core.ImageProxy
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.qrscanner.model.BarcodeScanResponse
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.IOException

class QRScannerRepository {

    private var barcodeScanner: BarcodeScanner = BarcodeScanning.getClient()
    private var imageScanLiveData: MutableLiveData<BarcodeScanResponse?> = MutableLiveData()

    fun getImageScanLiveData(): MutableLiveData<BarcodeScanResponse?> {

        return imageScanLiveData
    }

    fun scanImage(context: Context, imageUri: Uri, isFromGallery: Boolean) {

        val image: InputImage

        try {

            image = InputImage.fromFilePath(context, imageUri)

            processImage(image, null, isFromGallery)

        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun scanImage(context: Context, imageBitmap: Bitmap, isFromGallery: Boolean) {

        val image: InputImage

        try {

            image = InputImage.fromBitmap(imageBitmap, 0)

            processImage(image, null, isFromGallery)

        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun processImage(
        inputImage: InputImage,
        imageProxy: ImageProxy? = null,
        isFromGallery: Boolean = false
    ) {

        barcodeScanner.process(inputImage)
            .addOnSuccessListener { barcodes ->

                if (barcodes.isEmpty()) {

                    imageScanLiveData.setValue(BarcodeScanResponse(null, isFromGallery))

                } else {

                    val barcode = barcodes[0]

                    imageScanLiveData.setValue(BarcodeScanResponse(barcode, isFromGallery))
                }
            }
            .addOnFailureListener {

                imageScanLiveData.setValue(null)

            }.addOnCompleteListener {

                imageProxy?.close()
            }
    }
}