package com.example.utilityapp.qrscanner.ui.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.utilityapp.R
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.qrscanner.model.MBarcode
import java.text.SimpleDateFormat

class RecyclerAdapterBarcodes(
    val context: Context,
    private val barcodeClickListener: IBarcodeClickListener
) :
    RecyclerView.Adapter<RecyclerAdapterBarcodes.ViewHolder>() {

    private val barcodes = ArrayList<MBarcode>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val textViewType: TextView = itemView.findViewById(R.id.text_view_type)
        val textViewDate: TextView = itemView.findViewById(R.id.text_view_date)
        val textViewQrType: TextView = itemView.findViewById(R.id.text_view_qr_type)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_item_barcode,
            parent, false
        )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val barcode = barcodes[position]

        holder.textViewDate.text =
            if (StringUtils.isDateToday(barcode.dateCreated)) "Today" else barcode.dateCreated

        holder.textViewType.text = StringUtils.getBarcodeType(barcode.type)
        holder.textViewQrType.text = if(barcode.creationType == 0) "Scanned" else "Created"

        holder.itemView.setOnClickListener {

            barcodeClickListener.onBarcodeClick(barcodes[position])
        }
    }

    override fun getItemCount(): Int {

        return barcodes.size
    }

    @SuppressLint("SimpleDateFormat")
    fun updateData(newList: List<MBarcode>) {

        barcodes.clear()
        barcodes.addAll(newList)

        // sort all barcodes
        barcodes.sortedByDescending { barcode ->

            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            sdf.parse(barcode.dateCreated)?.time
        }

        notifyItemRangeChanged(0, barcodes.size)
    }
}

interface IBarcodeClickListener {

    fun onBarcodeClick(barcode: MBarcode)
}