package com.example.utilityapp.translator.text.repository

import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.translator.common.data.network.api.TranslatorApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TextTranslatorRepository() {

    private lateinit var api: TranslatorApiService
    private lateinit var translationLiveData: MutableLiveData<String?>

    fun init(apiService: TranslatorApiService) {

        this.api = apiService
        translationLiveData = MutableLiveData()
    }

    fun getTranslationLiveData(): MutableLiveData<String?> {

        return this.translationLiveData
    }

    fun getTranslation(
        sourceLanguageCode: String,
        targetLanguageCode: String,
        text: String
    ) {
        CoroutineScope(Dispatchers.IO).launch {

            api
                .getTranslation("gtx", sourceLanguageCode, targetLanguageCode, "t", text)
                .enqueue(object : Callback<String> {

                    override fun onResponse(
                        call: Call<String>,
                        response: Response<String>
                    ) {

                        if (response.isSuccessful && response.code() <= 299 && response.body() != null) {

                            parseResponse(response.body()!!)

                        } else {

                            CoroutineScope(Dispatchers.Main).launch {

                                translationLiveData.value = null
                            }
                        }
                    }

                    override fun onFailure(call: Call<String>, t: Throwable) {

                        CoroutineScope(Dispatchers.Main).launch {

                            translationLiveData.value = null
                        }
                    }
                })
        }
    }

    private fun parseResponse(response: String) {

        CoroutineScope(Dispatchers.IO).launch {

            try {
                var translation = ""
                val responseArray = JSONArray(response)
                val responseFirst = responseArray[0] as JSONArray

                for (i in 0 until responseFirst.length()) {

                    val currentLine = responseFirst[i] as JSONArray

                    translation += currentLine[0].toString()
                }

                if (translation.isNotEmpty()) {

                    CoroutineScope(Dispatchers.Main).launch {

                        translationLiveData.value = translation
                    }

                } else {

                    CoroutineScope(Dispatchers.Main).launch {

                        translationLiveData.value = null
                    }
                }
            } catch (e: Exception) {

                e.printStackTrace()

                CoroutineScope(Dispatchers.Main).launch {

                    translationLiveData.value = null
                }
            }
        }
    }
}