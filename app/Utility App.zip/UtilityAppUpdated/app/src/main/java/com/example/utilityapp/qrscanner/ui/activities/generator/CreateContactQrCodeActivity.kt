package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateContactQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreateContactQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateContactQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateContactQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Contact"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }


    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateContactQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val firstName: String = binding.content.editTextFirstName.text.toString().trim()
        val lastName: String = binding.content.editTextLastName.text.toString().trim()
        val phone: String = binding.content.editTextPhoneNumber.text.toString().trim()
        val email: String = binding.content.editTextEmail.text.toString().trim()
        val company: String = binding.content.editTextCompany.text.toString().trim()
        val address: String = binding.content.editTextAddress.text.toString().trim()

        var isInputValid = true

        if (firstName.isEmpty()) {

            binding.content.editTextFirstName.error = "Field is required"
            isInputValid = false
        }

        if (lastName.isEmpty()) {

            binding.content.editTextLastName.error = "Field is required"
            isInputValid = false
        }

        if (phone.isEmpty()) {

            binding.content.editTextPhoneNumber.error = "Field is required"
            isInputValid = false
        }

        if (email.isEmpty()) {

            binding.content.editTextEmail.error = "Field is required"
            isInputValid = false
        }

        if (company.isEmpty()) {

            binding.content.editTextCompany.error = "Field is required"
            isInputValid = false
        }

        if (address.isEmpty()) {

            binding.content.editTextAddress.error = "Field is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createContactQrCode(
                1,firstName, lastName, phone, email, company, address
            )
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}