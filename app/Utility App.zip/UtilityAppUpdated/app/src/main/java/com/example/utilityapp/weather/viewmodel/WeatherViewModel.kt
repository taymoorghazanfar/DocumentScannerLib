package com.example.utilityapp.weather.viewmodel

import android.app.Application
import android.content.Context
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.utilityapp.common.repository.LocationRepository
import com.example.utilityapp.weather.data.network.api.WeatherApiService
import com.example.utilityapp.weather.model.ForecastData
import com.example.utilityapp.weather.model.TodayData
import com.example.utilityapp.weather.model.WeatherData
import com.example.utilityapp.weather.repository.WeatherRepository

class WeatherViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var locationRepository: LocationRepository
    private lateinit var weatherRepository: WeatherRepository

    private lateinit var locationLiveData: LiveData<Location?>
    private lateinit var lastLocationLiveData: LiveData<Location?>
    private lateinit var weatherLiveData: MutableLiveData<WeatherData?>
    private lateinit var todayLiveData: MutableLiveData<List<TodayData>?>
    private lateinit var forecastLiveData: MutableLiveData<List<ForecastData>?>

    fun init(context: Context, apiService: WeatherApiService) {

        locationRepository = LocationRepository(context)
        locationLiveData = locationRepository.getLocationLiveData()
        lastLocationLiveData = locationRepository.getLastLocationLiveData()

        weatherRepository = WeatherRepository()
        weatherRepository.init(apiService)

        weatherLiveData = weatherRepository.getWeatherLiveData()
        todayLiveData = weatherRepository.getTodayLiveData()
        forecastLiveData = weatherRepository.getForecastLiveData()
    }

    fun getLocationLiveData(): LiveData<Location?> {

        return this.locationLiveData
    }

    fun getLastLocationLiveData(): LiveData<Location?> {

        return this.lastLocationLiveData
    }

    fun getWeatherLiveData(): MutableLiveData<WeatherData?> {

        return this.weatherLiveData
    }

    fun getTodayLiveData(): MutableLiveData<List<TodayData>?> {

        return this.todayLiveData
    }

    fun getForecastLiveData(): MutableLiveData<List<ForecastData>?> {

        return this.forecastLiveData
    }

    fun requestCurrentLocation() {

        locationRepository.requestCurrentLocation()
    }

    fun getLastKnownLocation() {

        locationRepository.getLastKnownLocation()
    }

    fun getWeatherUpdates(context: Context, lat: Double, lng: Double, newUpdate: Boolean) {

        weatherRepository.getWeatherUpdates(context, lat, lng, newUpdate)
        weatherRepository.getForecastUpdates(context, lat, lng, newUpdate)
    }
}