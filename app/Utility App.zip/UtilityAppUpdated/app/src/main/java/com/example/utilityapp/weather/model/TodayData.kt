package com.example.utilityapp.weather.model

class TodayData {

    var iconUrl:String
    var temperature:String
    var time:String

    constructor(iconUrl: String, temperature: String, time: String) {
        this.iconUrl = iconUrl
        this.temperature = temperature
        this.time = time
    }
}