package com.example.utilityapp.translator.common.data.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.utilityapp.translator.model.MTranslation

@Dao
interface TranslationsDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(translation: MTranslation)

    @Query("DELETE FROM translations WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("Select * from translations order by date_created DESC")
    fun getAllTranslations(): LiveData<List<MTranslation>>

    @Update
    suspend fun update(translation: MTranslation)
}