package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreatePhoneQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreatePhoneQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreatePhoneQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreatePhoneQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Phone"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreatePhoneQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val phoneNumber: String = binding.content.editTextPhoneNumber.text.toString().trim()

        var isInputValid = true

        if (phoneNumber.isEmpty()) {

            binding.content.editTextPhoneNumber.error = "Phone number is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createPhoneQrCode(1,phoneNumber)
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}