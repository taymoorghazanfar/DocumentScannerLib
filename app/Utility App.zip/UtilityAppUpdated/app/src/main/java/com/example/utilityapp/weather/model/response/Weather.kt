package com.example.utilityapp.weather.model.response

import com.google.gson.annotations.SerializedName

class Weather {

    @SerializedName("id")
    var id:Int

    @SerializedName("main")
    var main:String

    @SerializedName("description")
    var description:String

    @SerializedName("icon")
    var icon:String

    constructor(id: Int, main: String, description: String, icon: String) {
        this.id = id
        this.main = main
        this.description = description
        this.icon = icon
    }
}