package com.example.utilityapp.common.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.common.util.NetworkUtils
import com.example.utilityapp.common.viewmodel.RemoteViewModel
import com.example.utilityapp.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private lateinit var viewModel: RemoteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(binding.root)

        if (NetworkUtils.isNetworkAvailable(this@SplashActivity)) {

            initViewModel()

        } else {

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Network Error")
            builder.setMessage("Check your internet & try again later")
            builder.setCancelable(false)

            builder.setPositiveButton("OK") { _, _ ->
                finish()
            }

            builder.show()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[RemoteViewModel::class.java]

        viewModel
            .getRemoteLiveData()
            .observe(this@SplashActivity) { isSet ->

                if (isSet) {

                    Log.d("rm_cfg", "initViewModel: tr url: " + RemoteConfig.translationApiUrl)
                    Log.d("rm_cfg", "initViewModel: wr url: " + RemoteConfig.weatherApiUrl)
                    Log.d("rm_cfg", "initViewModel: wri url: " + RemoteConfig.weatherApiImageUrl)
                    Log.d("rm_cfg", "initViewModel: key : " + RemoteConfig.weatherApiKey)

                    startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                    finish()

                } else {

                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Server Error")
                    builder.setMessage("Please try again later")
                    builder.setCancelable(false)

                    builder.setPositiveButton("OK") { _, _ ->
                        finish()
                    }

                    builder.show()
                }
            }

        viewModel.getTranslationApiUrl()
    }
}