package com.example.utilityapp.qrscanner.util

import com.google.mlkit.vision.barcode.common.Barcode

class BarcodeDataParser {

    companion object {

        fun getBarcodeData(barcode: Barcode): String? {

            when (barcode.valueType) {

                Barcode.TYPE_URL -> {

                    return getUrlData(barcode)
                }

                Barcode.TYPE_CALENDAR_EVENT -> {

                    return getCalenderEventData(barcode)
                }

                Barcode.TYPE_CONTACT_INFO -> {

                    return getContactData(barcode)
                }

                Barcode.TYPE_EMAIL -> {

                    return getEmailData(barcode)
                }

                Barcode.TYPE_GEO -> {

                    return getLocationData(barcode)
                }

                Barcode.TYPE_PHONE -> {

                    return getPhoneData(barcode)
                }

                Barcode.TYPE_SMS -> {

                    return getSmsData(barcode)
                }

                Barcode.TYPE_TEXT -> {

                    return getTextData(barcode)
                }

                Barcode.TYPE_WIFI -> {

                    return getWifiData(barcode)
                }
                else->{

                    return barcode.rawValue
                }
            }
        }

        fun getWifiData(
            barcode: Barcode? = null,
            ssid: String? = null,
            securityType: Int? = null,
            password: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.wifi == null) {

                    return null
                }

                var ssid1 = ""
                var securityType1 = "nopass"
                var password1 = ""

                if (!barcode.wifi!!.ssid.isNullOrEmpty()) {

                    ssid1 = barcode.wifi!!.ssid.toString()
                }

                if (barcode.wifi!!.encryptionType == Barcode.WiFi.TYPE_WPA) {

                    securityType1 = "WPA"

                } else if (barcode.wifi!!.encryptionType == Barcode.WiFi.TYPE_WEP) {

                    securityType1 = "WEP"
                }

                if (!barcode.wifi!!.password.isNullOrEmpty()) {

                    password1 = barcode.wifi!!.password.toString()
                }

                return "WIFI:T:$securityType1;S:$ssid1;P:$password1;H:;"
            }

            return when (securityType) {

                Barcode.WiFi.TYPE_WPA -> {

                    "WIFI:T:WPA;S:$ssid;P:$password;H:;"
                }

                Barcode.WiFi.TYPE_WEP -> {

                    "WIFI:T:WEP;S:$ssid;P:$password;H:;"
                }

                else -> {

                    "WIFI:T:nopass;S:$ssid;P:;H:;"
                }
            }
        }

        fun getTextData(barcode: Barcode? = null, text: String? = null): String? {

            if (barcode != null) {

                if (barcode.rawValue == null) {

                    return null
                }

                return barcode.rawValue.toString()
            }

            return text
        }

        fun getSmsData(
            barcode: Barcode? = null,
            phoneNumber: String? = null,
            message: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.sms == null) {

                    return null
                }

                var phoneNumber1 = ""
                var message1 = ""

                if (!barcode.sms!!.phoneNumber.isNullOrEmpty()) {

                    phoneNumber1 = barcode.sms!!.phoneNumber.toString()
                }

                if (!barcode.sms!!.message.isNullOrEmpty()) {

                    message1 = barcode.sms!!.message.toString()
                }

                return "smsto:${phoneNumber1}:${message1}"
            }

            return "smsto:${phoneNumber}:${message}"
        }

        fun getPhoneData(barcode: Barcode? = null, phoneNumber: String? = null): String? {

            if (barcode != null) {

                if (barcode.phone == null) {

                    return null
                }

                var phoneNumber1 = ""

                if (!barcode.phone!!.number.isNullOrEmpty()) {

                    phoneNumber1 = barcode.phone!!.number.toString()
                }

                return "tel:${phoneNumber1}"
            }

            return "tel:${phoneNumber}"
        }

        fun getLocationData(
            barcode: Barcode? = null,
            lat: Float? = null,
            lng: Float? = null

        ): String? {

            if (barcode != null) {

                if (barcode.geoPoint == null) {

                    return null
                }

                return "geo:${barcode.geoPoint!!.lat},${barcode.geoPoint!!.lng}"
            }

            return "geo:${lat},${lng}"
        }

        fun getEmailData(
            barcode: Barcode? = null,
            address: String? = null,
            subject: String? = null,
            body: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.email == null) {

                    return null
                }

                var address1 = ""
                var subject1 = ""
                var body1 = ""

                if (!barcode.email!!.address.isNullOrEmpty()) {

                    address1 = barcode.email!!.address.toString()
                }

                if (!barcode.email!!.subject.isNullOrEmpty()) {

                    subject1 = barcode.email!!.subject.toString()
                }

                if (!barcode.email!!.body.isNullOrEmpty()) {

                    body1 = barcode.email!!.body.toString()
                }

                return "mailto:$address1?subject=$subject1&body=$body1"
            }

            return "mailto:$address?subject=$subject&body=$body"
        }

        fun getContactData(
            barcode: Barcode? = null,
            firstName: String? = null,
            lastName: String? = null,
            phone: String? = null,
            email: String? = null,
            company: String? = null,
            address: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.contactInfo == null) {

                    return null
                }

                var firstName1 = ""
                var lastName1 = ""
                var phone1 = ""
                var email1 = ""
                var company1 = ""
                var address1 = ""

                if (!barcode.contactInfo!!.name?.first.isNullOrEmpty()) {

                    firstName1 = barcode.contactInfo!!.name!!.first.toString()
                }

                if (!barcode.contactInfo!!.name?.last.isNullOrEmpty()) {

                    lastName1 = barcode.contactInfo!!.name!!.last.toString()
                }

                if (!barcode.contactInfo!!.phones[0].number.isNullOrEmpty()) {

                    phone1 = barcode.contactInfo!!.phones[0].number.toString()
                }

                if (!barcode.contactInfo!!.emails[0].address.isNullOrEmpty()) {

                    email1 = barcode.contactInfo!!.emails[0].address.toString()
                }

                if (!barcode.contactInfo!!.organization.isNullOrEmpty()) {

                    company1 = barcode.contactInfo!!.organization.toString()
                }

                if (barcode.contactInfo!!.addresses.isNotEmpty()) {

                    if (barcode.contactInfo!!.addresses[0].addressLines.isNotEmpty()) {

                        address1 = barcode.contactInfo!!.addresses[0].addressLines[0].toString()
                    }
                }

                return "BEGIN:VCARD\n" +
                        "VERSION:3.0\n" +
                        "N:$firstName1 $lastName1\n" +
                        "ORG:$company1\n" +
                        "ADR:$address1\n" +
                        "TEL:$phone1\n" +
                        "EMAIL:$email1\n" +
                        "END:VCARD"
            }

            return "BEGIN:VCARD\n" +
                    "VERSION:3.0\n" +
                    "N:$firstName $lastName\n" +
                    "ORG:$company\n" +
                    "ADR:$address\n" +
                    "TEL:$phone\n" +
                    "EMAIL:$email\n" +
                    "END:VCARD"
        }

        fun getCalenderEventData(
            barcode: Barcode? = null,
            summary: String? = null,
            location: String? = null,
            start: String? = null,
            end: String? = null,
            description: String? = null

        ): String? {

            if (barcode != null) {

                if (barcode.calendarEvent == null) {

                    return null
                }

                var summary1 = ""
                var location1 = ""
                var start1 = ""
                var end1 = ""
                var description1 = ""

                if (!barcode.calendarEvent!!.summary.isNullOrEmpty()) {

                    summary1 = barcode.calendarEvent!!.summary!!
                }

                if (!barcode.calendarEvent!!.location.isNullOrEmpty()) {

                    location1 = barcode.calendarEvent!!.location.toString()
                }

                if (barcode.calendarEvent!!.start != null) {

                    val startValue = barcode.calendarEvent!!.start

                    start1 =
                        startValue!!.year.toString() +
                                startValue.month.toString() +
                                startValue.day.toString() + "T" +
                                startValue.hours.toString() +
                                startValue.minutes.toString() +
                                startValue.seconds.toString()
                }

                if (barcode.calendarEvent!!.end != null) {

                    val endValue = barcode.calendarEvent!!.end

                    end1 =
                        endValue!!.year.toString() +
                                endValue.month.toString() +
                                endValue.day.toString() + "T" +
                                endValue.hours.toString() +
                                endValue.minutes.toString() +
                                endValue.seconds.toString()
                }

                if (!barcode.calendarEvent!!.description.isNullOrEmpty()) {

                    description1 = barcode.calendarEvent!!.description.toString()
                }

                return "BEGIN:VEVENT\n" +
                        "SUMMARY:$summary1\n" +
                        "DTSTART:$start1\n" +
                        "DTEND:$end1\n" +
                        "LOCATION:$location1\n" +
                        "DESCRIPTION:$description1\n" +
                        "END:VEVENT"
            }

            return "BEGIN:VEVENT\n" +
                    "SUMMARY:$summary\n" +
                    "DTSTART:$start\n" +
                    "DTEND:$end\n" +
                    "LOCATION:$location\n" +
                    "DESCRIPTION:$description\n" +
                    "END:VEVENT"
        }

        fun getUrlData(barcode: Barcode? = null, url: String? = null): String? {

            if (barcode != null) {

                if (barcode.url == null) {

                    return null
                }

                return barcode.url!!.url
            }

            return url
        }
    }
}