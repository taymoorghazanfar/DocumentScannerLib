package com.example.utilityapp.translator.common.ui.interfaces

interface BSPickImageListener {

    fun onGallerySelected()
    fun onCameraSelected()
    fun onDismissed()
}