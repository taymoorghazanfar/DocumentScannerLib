package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.utilityapp.databinding.ActivityQrGeneratorHomeBinding

class QrGeneratorHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQrGeneratorHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrGeneratorHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()

        setupViews()
    }

    private fun setupViews() {

        binding.content.buttonLocation.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateLocationQrCodeActivity::class.java))
        }

        binding.content.buttonPhone.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreatePhoneQrCodeActivity::class.java))
        }

        binding.content.buttonEvent.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateEventQrCodeActivity::class.java))
        }

        binding.content.buttonEmail.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateEmailQrCodeActivity::class.java))
        }

        binding.content.buttonMessage.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateSmsQrCodeActivity::class.java))
        }

        binding.content.buttonContacts.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateContactQrCodeActivity::class.java))
        }

        binding.content.buttonWifi.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateWifiQrCodeActivity::class.java))
        }

        binding.content.buttonUrl.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateUrlQrCodeActivity::class.java))
        }

        binding.content.buttonText.setOnClickListener {

            startActivity(Intent(this@QrGeneratorHomeActivity, CreateTextQrCodeActivity::class.java))
        }
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Create QR"

        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }
}