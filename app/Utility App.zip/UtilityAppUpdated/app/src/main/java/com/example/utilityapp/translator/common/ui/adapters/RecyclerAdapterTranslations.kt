package com.example.utilityapp.translator.home.ui.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.utilityapp.R
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.translator.model.MTranslation
import java.text.SimpleDateFormat

class RecyclerAdapterTranslations(
    val context: Context,
    private val translationListener: ITranslationClickListener
) :
    RecyclerView.Adapter<RecyclerAdapterTranslations.ViewHolder>() {

    private val translations = ArrayList<MTranslation>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val textViewType: TextView = itemView.findViewById(R.id.text_view_type)
        val textViewDate: TextView = itemView.findViewById(R.id.text_view_date)
        val textViewName: TextView = itemView.findViewById(R.id.text_view_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_item_translation,
            parent, false
        )
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val translation = translations[position]

        holder.textViewDate.text =
            if (StringUtils.isDateToday(translation.dateCreated)) "Today" else translation.dateCreated

        holder.textViewType.text = translation.type
        holder.textViewName.text =
            if (translation.text.length <= 20) translation.text + "..."
            else translation.text.substring(0, 20) + "..."

        holder.itemView.setOnClickListener {

            translationListener.onTranslationClick(translations[position])
        }
    }

    override fun getItemCount(): Int {

        return translations.size
    }

    @SuppressLint("SimpleDateFormat")
    fun updateData(newList: List<MTranslation>) {

        translations.clear()
        translations.addAll(newList)

        // sort all barcodes
        translations.sortedByDescending { translation ->

            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            sdf.parse(translation.dateCreated)?.time
        }

        notifyItemRangeChanged(0, translations.size)
    }
}

interface ITranslationClickListener {

    fun onTranslationClick(translation: MTranslation)
}