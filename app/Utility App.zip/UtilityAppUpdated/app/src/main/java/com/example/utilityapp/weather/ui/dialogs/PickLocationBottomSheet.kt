package com.example.utilityapp.weather.ui.dialogs

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.example.utilityapp.R
import com.example.utilityapp.common.ui.dialogs.RoundedBottomSheetDialogFragment
import com.example.utilityapp.weather.ui.interfaces.BSPickLocationListener

class PickLocationBottomSheet : RoundedBottomSheetDialogFragment() {

    private lateinit var buttonCurrentLocation: LinearLayout
    private lateinit var buttonMap: LinearLayout
    private lateinit var listener: BSPickLocationListener

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {

        val view = inflater.inflate(R.layout.bottom_sheet_pick_location, container, false)

        buttonCurrentLocation = view.findViewById(R.id.button_current)
        buttonMap = view.findViewById(R.id.button_map)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        buttonCurrentLocation.setOnClickListener {

            listener.onCurrentLocationSelected()
        }

        buttonMap.setOnClickListener {

            listener.onMapSelected()
        }
    }

    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)

        listener.onDialogDismissed()
    }

    fun setListener(listener: BSPickLocationListener) {

        this.listener = listener
    }
}