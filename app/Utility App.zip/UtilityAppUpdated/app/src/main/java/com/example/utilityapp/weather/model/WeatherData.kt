package com.example.utilityapp.weather.model

class WeatherData {

    var cityNameDate: String
    var currentTime: String
    var weatherIconUrl: String
    var temperature: String
    var weatherTitle: String
    var lastUpdated: String

    var rain: String
    var humidity: String
    var wind: String

    constructor(
        cityNameDate: String,
        currentTime: String,
        weatherIconUrl: String,
        temperature: String,
        weatherTitle: String,
        lastUpdated: String,
        rain: String,
        humidity: String,
        wind: String
    ) {
        this.cityNameDate = cityNameDate
        this.currentTime = currentTime
        this.weatherIconUrl = weatherIconUrl
        this.temperature = temperature
        this.weatherTitle = weatherTitle
        this.lastUpdated = lastUpdated
        this.rain = rain
        this.humidity = humidity
        this.wind = wind
    }
}