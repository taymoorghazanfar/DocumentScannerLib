package com.example.utilityapp.pdfreader.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.utilityapp.R
import com.example.utilityapp.common.ui.decorators.SpacesItemDecoration
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityPdfReaderHomeBinding
import com.example.utilityapp.pdfreader.model.MPdf
import com.example.utilityapp.pdfreader.ui.adapters.IPdfClickListener
import com.example.utilityapp.pdfreader.ui.adapters.RecyclerAdapterPdfs
import com.example.utilityapp.pdfreader.viewmodel.PdfFilesViewModel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PdfReaderHomeActivity : AppCompatActivity(), IPdfClickListener {

    private lateinit var binding: ActivityPdfReaderHomeBinding
    private lateinit var viewModel: PdfFilesViewModel
    private lateinit var resultLauncher: ActivityResultLauncher<Intent>

    @SuppressLint("StaticFieldLeak")
    private lateinit var adapter: RecyclerAdapterPdfs

    // picked file uri
    private var fileUri: Uri? = null

    // pdf to be saved in DB (if picked for 1st time)
    private var pdf: MPdf? = null

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfReaderHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()

        initViews()

        initViewModel()

        resultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (result.resultCode != RESULT_CANCELED) {

                if (result.data != null) {

                    val uri = result.data!!.data

                    if (uri != null) {

                        try {

//                            this@PdfReaderHomeActivity.grantUriPermission(
//                                this@PdfReaderHomeActivity.packageName,
//                                uri,
//                                Intent.FLAG_GRANT_READ_URI_PERMISSION
//                            )

                            val takeFlags: Int =
                                result.data!!.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
                            this@PdfReaderHomeActivity.contentResolver.takePersistableUriPermission(
                                uri,
                                takeFlags
                            )

                            handleFilePickerResult(result)

                        } catch (e: Exception) {

                            e.printStackTrace()

                            try {

                                this@PdfReaderHomeActivity.grantUriPermission(
                                    this@PdfReaderHomeActivity.packageName,
                                    uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )

                                val takeFlags: Int =
                                    result.data!!.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
                                this@PdfReaderHomeActivity.contentResolver.takePersistableUriPermission(
                                    uri,
                                    takeFlags
                                )

                                handleFilePickerResult(result)

                            } catch (e: Exception) {

                                e.printStackTrace()

                                handleFilePickerResult(result)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun initViews() {

        CoroutineScope(Dispatchers.Main).launch {

            binding.contentEmpty.root.visibility = View.GONE
            binding.contentRecents.root.visibility = View.GONE

            binding.contentEmpty.buttonOpenPdf.setOnClickListener {

                openFilePicker()
            }

            binding.contentRecents.buttonOpenPdf.setOnClickListener {

                openFilePicker()
            }

            binding.contentRecents.recyclerView.layoutManager =
                LinearLayoutManager(this@PdfReaderHomeActivity)
            val spacingInPixels =
                resources.getDimensionPixelSize(R.dimen.recycler_view_spacing)
            binding.contentRecents.recyclerView.addItemDecoration(
                SpacesItemDecoration(spacingInPixels,0)
            )
            adapter = RecyclerAdapterPdfs(
                this@PdfReaderHomeActivity,
                this@PdfReaderHomeActivity
            )
            binding.contentRecents.recyclerView.adapter = adapter
        }
    }

    private fun setupHeader() {

        CoroutineScope(Dispatchers.Main).launch {

            binding.header.textViewTitle.text = getString(R.string.pdf_reader)
            binding.header.buttonBack.setOnClickListener {

                finish()
            }
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[PdfFilesViewModel::class.java]

        viewModel.init()

        // getting list of all recent files
        viewModel.getRecentPdfFilesLiveData().observe(this) { recentPdfFiles ->

            if (recentPdfFiles.isNullOrEmpty()) {

                updateViews(true)

            } else {

                updateViews(false, recentPdfFiles)
            }
        }

        viewModel.queryPdf.observe(this) { queryPdf ->

            try {

                // no pdf with [uri] was found (file not opened before)
                if (queryPdf == null) {

                    // create & save the PDF FILE to database

                    val file: DocumentFile? =
                        DocumentFile.fromSingleUri(this@PdfReaderHomeActivity, fileUri!!)

                    if (file != null) {

                        val name = file.name
                        val totalPages = getPagesCount(fileUri!!)

                        if (!(name.isNullOrEmpty() || totalPages == -1)) {

                            pdf = MPdf(
                                0,
                                fileUri.toString(),
                                name,
                                totalPages,
                                0,
                                StringUtils.getCurrentDateTime()
                            )

                            viewModel.savePdfFile(pdf!!)

                        } else {

                            Snackbar.make(
                                binding.root,
                                "Error occurred while opening the file",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        }

                    } else {

                        Snackbar.make(
                            binding.root,
                            "Error occurred while opening the file",
                            Snackbar.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Log.d("pdf_d", "initViewModel: pdf already exist")
                    val i = Intent(this@PdfReaderHomeActivity, PdfViewerActivity::class.java)
                    i.putExtra("pdf", queryPdf)
                    startActivity(i)
                }

            } catch (e: Exception) {

                e.printStackTrace()

                Snackbar.make(
                    binding.root,
                    "Error occurred while opening the file",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }

        viewModel.insertedPdfId.observe(this) { id ->

            pdf!!.id = id.toInt()

            val i =
                Intent(this@PdfReaderHomeActivity, PdfViewerActivity::class.java)
            i.putExtra("pdf", pdf)
            startActivity(i)
        }
    }

    private fun updateViews(isEmpty: Boolean, pdfFiles: List<MPdf>? = null) {

        // if there are no recent files
        if (isEmpty) {

            CoroutineScope(Dispatchers.Main).launch {

                binding.contentEmpty.root.visibility = View.VISIBLE
                binding.contentRecents.root.visibility = View.GONE
            }

        } else {

            CoroutineScope(Dispatchers.Main).launch {

                binding.contentEmpty.root.visibility = View.GONE
                binding.contentRecents.root.visibility = View.VISIBLE

                adapter.updateData(pdfFiles!!)
            }
        }
    }

    private fun openFilePicker() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            intent.type = "application/pdf"
            resultLauncher.launch(intent)

        } else {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                REQUEST_CODE_STORAGE_PERMISSION
            )
        }
    }

    private fun handleFilePickerResult(result: ActivityResult?) {

        try {

            val data: Intent? = result?.data

            if (data != null) {

                if (data.data != null) {

                    val fileUri = data.data!!

                    this.fileUri = fileUri

                    viewModel.getPdfByUri(fileUri.toString())

                } else {

                    Snackbar.make(
                        binding.root,
                        "Error occurred while opening the file",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
            } else {

                Snackbar.make(
                    binding.root,
                    "Error occurred while opening the file",
                    Snackbar.LENGTH_SHORT
                ).show()
            }

        } catch (e: Exception) {

            e.printStackTrace()

            Snackbar.make(
                binding.root,
                "Error occurred while opening the file",
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun getPagesCount(fileUri: Uri): Int {

        return try {

            val parcelFileDescriptor: ParcelFileDescriptor =
                contentResolver.openFileDescriptor(fileUri, "r")!!

            val pdfRenderer = PdfRenderer(parcelFileDescriptor)

            pdfRenderer.pageCount

        } catch (e: Exception) {

            e.printStackTrace()

            -1
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "application/pdf"
                resultLauncher.launch(intent)

            } else {

                Snackbar.make(
                    binding.root,
                    "Storage permission is required to use this feature",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onPdfClick(pdf: MPdf) {

        // check if file still exists or deleted
        if (getPagesCount(Uri.parse(pdf.uri)) == -1) {

            Snackbar.make(
                binding.root,
                "An error occurred while opening the file",
                Snackbar.LENGTH_SHORT
            ).show()

            return
        }

        val i = Intent(this@PdfReaderHomeActivity, PdfViewerActivity::class.java)
        i.putExtra("pdf", pdf)
        startActivity(i)
    }

    companion object {

        private const val REQUEST_CODE_STORAGE_PERMISSION = 1
    }
}