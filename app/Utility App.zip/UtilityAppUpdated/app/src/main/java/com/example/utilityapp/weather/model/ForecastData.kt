package com.example.utilityapp.weather.model

class ForecastData {

    var day:String
    var title:String
    var high:String
    var low:String
    var icon:String

    constructor(day: String, title: String, high: String, low: String, icon: String) {
        this.day = day
        this.title = title
        this.high = high
        this.low = low
        this.icon = icon
    }
}