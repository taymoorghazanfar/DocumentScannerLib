package com.example.utilityapp.qrscanner.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "barcodes")
class MBarcode : java.io.Serializable {

    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    // ie SMS
    @ColumnInfo(name = "type")
    var type: Int = 0

    // ie Scanned = 0. Generated = 1
    @ColumnInfo(name = "creation_type")
    var creationType: Int = 0

    // ie. SMSTO:phone_no:message_here (USED TO CREATE QR CODE)
    @ColumnInfo(name = "data")
    var data: String = ""

    // ie. phone_no, message_here
    @ColumnInfo(name = "readable_value")
    var readableValue: String = ""

    @ColumnInfo(name = "date_created")
    var dateCreated: String = ""

    constructor(
        id: Int,
        type: Int,
        creationType: Int,
        data: String,
        readableValue: String,
        dateCreated: String
    ) {
        this.id = id
        this.type = type
        this.creationType = creationType
        this.data = data
        this.readableValue = readableValue
        this.dateCreated = dateCreated
    }
}