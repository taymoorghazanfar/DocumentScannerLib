package com.example.utilityapp.qrscanner.repository

import androidx.lifecycle.LiveData
import com.example.utilityapp.qrscanner.data.database.dao.BarcodesDao
import com.example.utilityapp.qrscanner.model.MBarcode

class BarcodesRepository(private val dao: BarcodesDao) {

    val allBarcodes: LiveData<List<MBarcode>> = dao.getAllBarcodes()

    suspend fun insert(barcode: MBarcode) {
        dao.insert(barcode)
    }
}