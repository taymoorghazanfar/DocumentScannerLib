package com.example.utilityapp.qrscanner.ui.activities.generator

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.utilityapp.databinding.ActivityCreateLocationQrCodeBinding
import com.example.utilityapp.qrscanner.viewmodel.QrCodeViewModel

class CreateLocationQrCodeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateLocationQrCodeBinding
    private lateinit var viewModel: QrCodeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateLocationQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupHeader()
        initViews()
        initViewModel()
    }

    private fun setupHeader() {

        binding.header.textViewTitle.text = "Location"
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
    }

    private fun initViews() {

        binding.content.buttonCreateQr.setOnClickListener {

            createQrCode()
        }
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[QrCodeViewModel::class.java]

        viewModel.init()

        viewModel.getBarcodeLiveData().observe(this) { barcode ->

            hideLoading()
            val intent =
                Intent(this@CreateLocationQrCodeActivity, QrGeneratorResultActivity::class.java)
            intent.putExtra("barcode", barcode)
            startActivity(intent)
            finish()
        }
    }

    private fun createQrCode() {

        val lat: String = binding.content.editTextLat.text.toString().trim()
        val lng: String = binding.content.editTextLng.text.toString().trim()

        var isInputValid = true

        if (lat.isEmpty()) {

            binding.content.editTextLat.error = "LAT is required"
            isInputValid = false
        }

        if (lng.isEmpty()) {

            binding.content.editTextLng.error = "LNG is required"
            isInputValid = false
        }

        if (isInputValid) {

            showLoading()
            viewModel.createLocationQrCode(1,lat.toFloat(), lng.toFloat())
        }
    }

    private fun showLoading() {

        binding.loadingAnim.visibility = View.VISIBLE
        binding.loadingAnim.bringToFront()
    }

    private fun hideLoading() {

        binding.loadingAnim.visibility = View.GONE
        binding.loadingAnim.bringToFront()
    }
}