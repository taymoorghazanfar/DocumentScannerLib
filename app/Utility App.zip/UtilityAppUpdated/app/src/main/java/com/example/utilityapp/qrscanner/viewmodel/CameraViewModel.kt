package com.example.utilityapp.qrscanner.viewmodel

import android.app.Application
import android.util.Log
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.util.concurrent.ExecutionException

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private var cameraLiveData: MutableLiveData<ProcessCameraProvider>? = null

    val processCameraProvider: LiveData<ProcessCameraProvider>
        get() {

            if (cameraLiveData == null) {

                cameraLiveData = MutableLiveData()

                val cameraProviderFuture = ProcessCameraProvider.getInstance(getApplication())

                cameraProviderFuture.addListener(
                    {
                        try {

                            cameraLiveData!!.setValue(cameraProviderFuture.get())

                        } catch (e: ExecutionException) {

                            Log.e(TAG, ": ", e)

                        } catch (e: InterruptedException) {

                            Log.e(TAG, "Unhandled exception", e)
                        }
                    },
                    ContextCompat.getMainExecutor(getApplication())
                )
            }

            return cameraLiveData!!
        }

    companion object {
        private const val TAG = "CameraViewModel"
    }
}