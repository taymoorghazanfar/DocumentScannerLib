package com.example.utilityapp.common.util

import android.annotation.SuppressLint
import android.text.format.DateUtils
import android.util.Log
import com.google.mlkit.vision.barcode.common.Barcode
import java.sql.Timestamp
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


class StringUtils {

    companion object {

        fun getRoundOffValue(value: Double, places: Int): Double {

            try {

                val valStr = value.toString()

                val arr = valStr.split(".")

                val round = if (arr[1].length <= places) arr[1] else arr[1].substring(0, places)

                val roundedValue = arr[0] + "." + round

                Log.d("rounded_value", "getRoundOffLatLng: " + roundedValue.toDouble())

                return roundedValue.toDouble()

            } catch (e: Exception) {

                e.printStackTrace()
                return value
            }
        }

        @SuppressLint("SimpleDateFormat")
        fun getCurrentDateTime(): String {

            return SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Date())
        }

        @SuppressLint("SimpleDateFormat")
        fun getCurrentDateForWeather(): String {

            return SimpleDateFormat("dd MMMM yyyy").format(Date())
        }

        @SuppressLint("SimpleDateFormat")
        fun getCurrentDate(): String {

            return SimpleDateFormat("yyyy-MM-dd").format(Date())
        }

        @SuppressLint("SimpleDateFormat")
        fun getCurrentTime(): String {

            val cal = Calendar.getInstance()
            val outputFormat: DateFormat = SimpleDateFormat("hh:mm a")
            return outputFormat.format(cal.time).uppercase()
        }

        @SuppressLint("SimpleDateFormat")
        fun dateToTime(date: String): String {

            val format1 = SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
            val format2 = SimpleDateFormat("hh:mm a")
            val date1 = format1.parse(date)
            return format2.format(date1!!)

//            return try {
//
//                val date = Date(timestamp)
//                val df2 = SimpleDateFormat("hh:mm a")
//
//                df2.format(date)
//
//            } catch (e: Exception) {
//
//                ""
//            }
        }

        @SuppressLint("SimpleDateFormat")
        fun timestampToDate(timestamp: Long): String {

            val ts = Timestamp(timestamp)
            val date: Date = ts
            return date.toString()
        }

        @SuppressLint("SimpleDateFormat")
        fun getDayName(date: String): String {

            val format1 = SimpleDateFormat("yyyy-MM-dd")
            val format2 = SimpleDateFormat("EEEE")
            val date1 = format1.parse(date)
            return format2.format(date1!!)
        }

        @SuppressLint("SimpleDateFormat")
        fun isDateToday(dateString: String): Boolean {

            return try {

                val format = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                val date = format.parse(dateString)
                DateUtils.isToday(date!!.time)

            } catch (e: ParseException) {
                false
            }
        }

        @SuppressLint("SimpleDateFormat")
        fun isDateToday(timestamp: Long): Boolean {

            return try {

                val date = Date(timestamp)
                val df2 = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                val dateText = df2.format(date)

                isDateToday(dateText)

            } catch (e: Exception) {

                false
            }
        }


        fun getBarcodeType(type: Int?): String {

            when (type) {

                Barcode.TYPE_CALENDAR_EVENT -> {

                    return "Calender Event"
                }
                Barcode.TYPE_CONTACT_INFO -> {

                    return "Contact Info"
                }
                Barcode.TYPE_EMAIL -> {

                    return "Email"
                }
                Barcode.TYPE_GEO -> {

                    return "Geo Point"
                }
                Barcode.TYPE_PHONE -> {

                    return "Phone Number"
                }
                Barcode.TYPE_SMS -> {

                    return "SMS"
                }
                Barcode.TYPE_TEXT -> {

                    return "Text"
                }
                Barcode.TYPE_URL -> {

                    return "Web Page"
                }
                Barcode.TYPE_WIFI -> {

                    return "WIFI"
                }
                else -> {

                    return "Barcode"
                }
            }
        }
    }
}