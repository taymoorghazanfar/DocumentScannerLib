package com.example.utilityapp.qrscanner.model

import com.google.mlkit.vision.barcode.common.Barcode

class BarcodeScanResponse {

    val barcode:Barcode?
    val isFromGallery:Boolean

    constructor(barcode: Barcode?, isFromGallery: Boolean) {
        this.barcode = barcode
        this.isFromGallery = isFromGallery
    }
}