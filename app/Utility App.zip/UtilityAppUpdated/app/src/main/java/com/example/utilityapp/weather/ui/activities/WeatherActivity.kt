package com.example.utilityapp.weather.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.utilityapp.R
import com.example.utilityapp.common.data.RemoteConfig
import com.example.utilityapp.common.data.network.RetrofitBuilder
import com.example.utilityapp.common.ui.activities.PickLocationActivity
import com.example.utilityapp.common.ui.decorators.EqualSpacingItemDecoration
import com.example.utilityapp.common.ui.dialogs.LoadingDialog
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.databinding.ActivityWeatherBinding
import com.example.utilityapp.weather.model.ForecastData
import com.example.utilityapp.weather.model.TodayData
import com.example.utilityapp.weather.model.WeatherData
import com.example.utilityapp.weather.ui.adapters.RecyclerAdapterForecast
import com.example.utilityapp.weather.ui.adapters.RecyclerAdapterToday
import com.example.utilityapp.weather.ui.dialogs.PickLocationBottomSheet
import com.example.utilityapp.weather.ui.interfaces.BSPickLocationListener
import com.example.utilityapp.weather.viewmodel.WeatherViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WeatherActivity : AppCompatActivity(), BSPickLocationListener {

    private lateinit var binding: ActivityWeatherBinding
    private lateinit var viewModel: WeatherViewModel
    private var selectedLocation: Location? = null

    @SuppressLint("StaticFieldLeak")
    private lateinit var todayAdapter: RecyclerAdapterToday

    @SuppressLint("StaticFieldLeak")
    private lateinit var forecastAdapter: RecyclerAdapterForecast

    private lateinit var loadingDialog: LoadingDialog
    private lateinit var bottomSheet: PickLocationBottomSheet

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWeatherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadingDialog = LoadingDialog(this@WeatherActivity)

        initViews()

        requestLocationPermission()
    }

    private fun requestLocationPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            initViewModel()

        } else {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_CODE_LOCATION_PERMISSION
            )
        }
    }

    private fun initViews() {

        binding.header.buttonLocation.setOnClickListener {

            openLocationDialog()
        }
        binding.header.buttonBack.setOnClickListener {

            finish()
        }
        binding.header.textViewTitle.text = "Weather"


        binding.content.recyclerViewToday.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.content.recyclerViewToday.addItemDecoration(
            EqualSpacingItemDecoration(
                resources.getDimensionPixelSize(R.dimen.recycler_view_spacing),
                EqualSpacingItemDecoration.HORIZONTAL
            )
        )
        todayAdapter = RecyclerAdapterToday(this)
        binding.content.recyclerViewToday.adapter = todayAdapter


        binding.content.recyclerViewForecast.layoutManager =
            LinearLayoutManager(this)
        binding.content.recyclerViewForecast.addItemDecoration(
            EqualSpacingItemDecoration(
                resources.getDimensionPixelSize(R.dimen.recycler_view_spacing),
                EqualSpacingItemDecoration.VERTICAL
            )
        )
        forecastAdapter = RecyclerAdapterForecast(this)
        binding.content.recyclerViewForecast.adapter = forecastAdapter
    }

    private fun initViewModel() {

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )[WeatherViewModel::class.java]

        viewModel.init(
            this@WeatherActivity,
            RetrofitBuilder.getWeatherApiService(RemoteConfig.weatherApiUrl!!)
        )

        viewModel
            .getLocationLiveData()
            .observe(this@WeatherActivity) { location ->

                if (selectedLocation == null) {

                    parseLocationResponse(location)
                }
            }

        viewModel
            .getLastLocationLiveData()
            .observe(this@WeatherActivity) { location ->

                parseLastLocationResponse(location)
            }

        viewModel
            .getWeatherLiveData()
            .observe(this@WeatherActivity) { weatherData ->

                parseWeatherResponse(weatherData)
            }

        viewModel
            .getTodayLiveData()
            .observe(this@WeatherActivity) { todayData ->

                parseTodayResponse(todayData)
            }

        viewModel
            .getForecastLiveData()
            .observe(this@WeatherActivity) { forecastData ->

                parseForecastResponse(forecastData)
            }

        loadingDialog.show()
        viewModel.requestCurrentLocation()
    }

    private fun parseLocationResponse(location: Location?) {

        Log.d("loc_get", "parseLocationResponse: got location")

        if (location == null) {

            loadingDialog.dismiss()
            // error
            showErrorDialog(
                "Error occurred",
                "Cannot retrieve weather at this time, try again later"
            )

        } else {

            selectedLocation = location
            getWeatherUpdates(location.latitude, location.longitude, false)
        }
    }

    private fun getWeatherUpdates(lat: Double, lng: Double, newUpdate: Boolean) {

        viewModel.getWeatherUpdates(
            this@WeatherActivity,
            StringUtils.getRoundOffValue(lat, 3),
            StringUtils.getRoundOffValue(lng, 3),
            newUpdate
        )
    }

    private fun parseLastLocationResponse(location: Location?) {

        if (location == null) {

            loadingDialog.dismiss()
            // error
            showErrorDialog(
                "Error occurred",
                "Cannot retrieve weather at this time, try again later"
            )

        } else {

            selectedLocation = location
            getWeatherUpdates(location.latitude, location.longitude, true)
        }
    }

    private fun parseWeatherResponse(weatherData: WeatherData?) {

        if (weatherData == null) {

            loadingDialog.dismiss()
            // error
            showErrorDialog(
                "Error occurred",
                "Cannot retrieve weather at this time, try again later"
            )

        } else {

            loadingDialog.dismiss()
            setupWeatherViews(weatherData)
        }
    }

    private fun parseTodayResponse(todayData: List<TodayData>?) {

        if (todayData == null) {

            loadingDialog.dismiss()
            // error
            showErrorDialog(
                "Error occurred",
                "Cannot retrieve weather at this time, try again later"
            )

        } else {

            loadingDialog.dismiss()
            todayAdapter.updateData(todayData)
        }
    }

    private fun parseForecastResponse(forecastData: List<ForecastData>?) {

        if (forecastData == null) {

            // error
            showErrorDialog(
                "Error occurred",
                "Cannot retrieve weather at this time, try again later"
            )

        } else {

            loadingDialog.dismiss()
            forecastAdapter.updateData(forecastData)
        }
    }

    private fun setupWeatherViews(weatherData: WeatherData) {

        binding.content.swipeRefreshLayout.setOnRefreshListener {

            binding.content.swipeRefreshLayout.isRefreshing = false

            loadingDialog.show()

            getWeatherUpdates(selectedLocation!!.latitude, selectedLocation!!.longitude, false)
        }

        binding.content.card.textViewLastUpdated.setOnClickListener {

            loadingDialog.show()

            getWeatherUpdates(selectedLocation!!.latitude, selectedLocation!!.longitude, false)
        }

        CoroutineScope(Dispatchers.Main).launch {

            animateView(binding.content.card.textViewDateLocation, weatherData.cityNameDate)
            animateView(binding.content.card.textViewTime, weatherData.currentTime)
            animateView(binding.content.card.textViewTemperature, weatherData.temperature)
            animateView(binding.content.card.textViewTemperatureTitle, weatherData.weatherTitle)
            animateView(binding.content.card.textViewLastUpdated, weatherData.lastUpdated)

            animateView(binding.content.textViewRain, weatherData.rain)
            animateView(binding.content.textViewHumidity, weatherData.humidity)
            animateView(binding.content.textViewWind, weatherData.wind)

            Glide
                .with(this@WeatherActivity)
                .load(RemoteConfig.weatherApiImageUrl + weatherData.weatherIconUrl)
                .centerCrop()
                .into(binding.content.card.imageViewWeather)
        }
    }

    private fun openLocationDialog() {

        bottomSheet = PickLocationBottomSheet()
        bottomSheet.setListener(this)
        bottomSheet.show(supportFragmentManager, bottomSheet.tag)
    }

    private fun animateView(view: View, data: String) {

        val animOut: Animation =
            AnimationUtils.loadAnimation(
                this@WeatherActivity,
                android.R.anim.fade_out
            )
        val animIn: Animation =
            AnimationUtils.loadAnimation(
                this@WeatherActivity,
                android.R.anim.fade_in
            )

        animOut.setAnimationListener(object :
            Animation.AnimationListener {
            override fun onAnimationStart(p0: Animation?) {

            }

            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {

                (view as TextView).text = data
                view.startAnimation(animIn)
            }
        })

        view.startAnimation(animOut)
    }

    override fun onCurrentLocationSelected() {

        bottomSheet.dismiss()
        loadingDialog.show()

        viewModel.getLastKnownLocation()
    }

    override fun onMapSelected() {

        bottomSheet.dismiss()

        val intent = Intent(this@WeatherActivity, PickLocationActivity::class.java)
        intent.putExtra(PickLocationActivity.FORM_VIEW_INDICATOR, DESTINATION_ID)
        startActivityForResult(intent, REQUEST_CODE_LOCATION)
    }

    override fun onDialogDismissed() {

        bottomSheet.dismiss()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_LOCATION_PERMISSION) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {

                initViewModel()

            } else {

                showErrorDialog(
                    "Location Permission Required", "Goto app settings " +
                            "& grant location permission to use this feature"
                )
            }
        }
    }

    private fun showErrorDialog(title: String, message: String) {

        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(
            message
        )
        builder.setCancelable(false)

        builder.setPositiveButton("OK") { _, _ ->
            finish()
        }

        builder.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_LOCATION && resultCode == RESULT_OK) {

            try {

                if (data != null) {

                    selectedLocation =
                        data.getParcelableExtra<Parcelable>(PickLocationActivity.LOCATION_LAT_LONG) as Location

                    if (selectedLocation != null) {

                        loadingDialog.show()

                        getWeatherUpdates(
                            selectedLocation!!.latitude,
                            selectedLocation!!.longitude,
                            true
                        )
                    } else {

                        // error
                        showErrorDialog(
                            "Error occurred",
                            "Cannot retrieve weather at this time, try again later"
                        )
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                // error
                showErrorDialog(
                    "Error occurred",
                    "Cannot retrieve weather at this time, try again later"
                )
            }
        }
    }

    companion object {

        const val REQUEST_CODE_LOCATION_PERMISSION = 1
        const val REQUEST_CODE_LOCATION = 2
        const val DESTINATION_ID = 3
    }
}