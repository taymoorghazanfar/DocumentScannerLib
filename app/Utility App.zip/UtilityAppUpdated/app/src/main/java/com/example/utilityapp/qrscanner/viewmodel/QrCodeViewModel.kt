package com.example.utilityapp.qrscanner.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.utilityapp.qrscanner.util.BarcodeDataParser
import com.example.utilityapp.qrscanner.util.BarcodeReadableDataParser
import com.example.utilityapp.common.util.StringUtils
import com.example.utilityapp.qrscanner.data.database.BarcodesDatabase
import com.example.utilityapp.qrscanner.model.MBarcode
import com.example.utilityapp.qrscanner.repository.BarcodesRepository
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QrCodeViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var barcodeLiveData: MutableLiveData<MBarcode>
    private lateinit var allBarcodes: LiveData<List<MBarcode>>
    private lateinit var barcodeImageLiveData: MutableLiveData<Bitmap>
    private lateinit var repository: BarcodesRepository

    fun init() {

        val dao = BarcodesDatabase.getDatabase(getApplication()).getBarcodesDao()

        barcodeLiveData = MutableLiveData()
        repository = BarcodesRepository(dao)
        allBarcodes = repository.allBarcodes
        barcodeImageLiveData = MutableLiveData()
    }

    fun getBarcodeLiveData(): MutableLiveData<MBarcode> {

        return this.barcodeLiveData
    }

    fun getAllBarcodes(): LiveData<List<MBarcode>> {

        return this.allBarcodes
    }

    fun getBarcodeImageLiveData(): MutableLiveData<Bitmap> {

        return this.barcodeImageLiveData
    }

    fun createLocationQrCode(creationType: Int, lat: Float, lng: Float) {

        val data = BarcodeDataParser.getLocationData(null, lat, lng)

        val readableValue = BarcodeReadableDataParser.getLocationReadableData(null, lat, lng)

        generateQrCode(null, Barcode.TYPE_GEO, creationType, data!!, readableValue)
    }

    fun createPhoneQrCode(creationType: Int, phoneNumber: String) {

        val data = BarcodeDataParser.getPhoneData(null, phoneNumber)

        val readableValue = BarcodeReadableDataParser.getPhoneReadableData(null, phoneNumber)

        generateQrCode(null, Barcode.TYPE_PHONE, creationType, data!!, readableValue)
    }

    fun createEventQrCode(
        creationType: Int,
        summary: String,
        location: String,
        description: String,
        start: String,
        end: String
    ) {

        val data = BarcodeDataParser.getCalenderEventData(
            null,
            summary,
            location,
            start,
            end,
            description
        )

//        Log.d("scaan", "createEventQrCode: " + data)
        val readableValue = BarcodeReadableDataParser.getCalenderEventReadableData(
            null,
            summary,
            location,
            start,
            end,
            description
        )

        generateQrCode(null, Barcode.TYPE_CALENDAR_EVENT, creationType, data!!, readableValue)
    }

    fun createEmailQrCode(creationType: Int, address: String, subject: String, body: String) {

        val data = BarcodeDataParser.getEmailData(null, address, subject, body)

        val readableValue = BarcodeReadableDataParser.getEmailReadableData(null, address, subject, body)

        generateQrCode(null, Barcode.TYPE_EMAIL, creationType, data!!, readableValue)
    }

    fun createSmsQrCode(creationType: Int, phoneNumber: String, message: String) {

        val data = BarcodeDataParser.getSmsData(null, phoneNumber, message)

        val readableValue = BarcodeReadableDataParser.getSmsReadableData(null, phoneNumber, message)

        generateQrCode(null, Barcode.TYPE_SMS, creationType, data!!, readableValue)
    }

    fun createContactQrCode(
        creationType: Int,
        firstName: String,
        lastName: String,
        phone: String,
        email: String,
        company: String,
        address: String
    ) {

        val data = BarcodeDataParser.getContactData(
            null,
            firstName,
            lastName,
            phone,
            email,
            company,
            address
        )

        val readableValue = BarcodeReadableDataParser.getContactReadableData(
            null,
            firstName,
            lastName,
            phone,
            email,
            company,
            address
        )

        generateQrCode(null, Barcode.TYPE_CONTACT_INFO, creationType, data!!, readableValue)
    }

    fun createWifiQrCode(creationType: Int, ssid: String, password: String, securityType: Int) {

        val data = BarcodeDataParser.getWifiData(null, ssid, securityType, password)

        val readableValue =
            BarcodeReadableDataParser.getWifiReadableData(null, ssid, securityType, password)

        generateQrCode(null, Barcode.TYPE_WIFI, creationType, data!!, readableValue)
    }

    fun createUrlQrCode(creationType: Int, url: String) {

        generateQrCode(
            null,
            Barcode.TYPE_URL,
            creationType,
            BarcodeDataParser.getUrlData(null, url)!!,
            BarcodeReadableDataParser.getUrlReadableData(null, url)
        )
    }

    fun createTextQrCode(creationType: Int, text: String) {

        generateQrCode(
            null,
            Barcode.TYPE_TEXT,
            creationType,
            BarcodeDataParser.getTextData(null, text)!!,
            BarcodeReadableDataParser.getTextReadableData(null, text)
        )
    }

    // creation type: 0 = scanned, 1 = generated
    fun generateQrCode(
        mBarcode: MBarcode? = null,
        barcodeType: Int? = null,
        creationType: Int? = null,
        data: String? = null,
        readableValue: String? = null
    ) {

        viewModelScope.launch(Dispatchers.Default) {

            val bitmap = generateBarcodeImage(mBarcode?.data ?: data)

            if (mBarcode != null) {

                saveBarcode(mBarcode)

                viewModelScope.launch(Dispatchers.Main) {

                    barcodeImageLiveData.setValue(bitmap)
                }

            } else {

                val barcode = MBarcode(
                    0,
                    barcodeType!!,
                    creationType!!,
                    data!!,
                    readableValue!!,
                    StringUtils.getCurrentDateTime()
                )

                saveBarcode(barcode)

                viewModelScope.launch(Dispatchers.Main) {

                    barcodeLiveData.setValue(barcode)
                }
            }
        }
    }

    fun generateBarcodeImage(data: String?, getResults: Boolean = false): Bitmap {

        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(data, BarcodeFormat.QR_CODE, 400, 400)

        val w = bitMatrix.width
        val h = bitMatrix.height
        val pixels = IntArray(w * h)

        for (y in 0 until h) {

            for (x in 0 until w) {

                pixels[y * w + x] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
            }
        }

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h)

        if (getResults) {

            viewModelScope.launch(Dispatchers.Main) {

                barcodeImageLiveData.setValue(bitmap)
            }
        }

        return bitmap
    }

    private fun saveBarcode(barcode: MBarcode) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(barcode)
        }
}