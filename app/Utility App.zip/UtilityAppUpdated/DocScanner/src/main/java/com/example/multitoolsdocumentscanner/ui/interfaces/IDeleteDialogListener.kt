package com.example.multitoolsdocumentscanner.ui.interfaces

interface IDeleteDialogListener {

    fun onDeleteDialogCancelled()
    fun onDeleteDialogSubmit()
}