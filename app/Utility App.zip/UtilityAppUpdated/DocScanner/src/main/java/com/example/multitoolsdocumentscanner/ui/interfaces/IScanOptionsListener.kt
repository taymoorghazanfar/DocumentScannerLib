package com.example.multitoolsdocumentscanner.ui.interfaces

interface IScanOptionsListener {

    fun onCameraSelected()

    fun onGallerySelected()

    fun onDialogDismissed()
}