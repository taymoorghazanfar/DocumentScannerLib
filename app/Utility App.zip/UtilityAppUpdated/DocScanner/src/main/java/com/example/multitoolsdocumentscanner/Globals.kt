package com.example.multitoolsdocumentscanner

import androidx.documentfile.provider.DocumentFile

class Globals {
    companion object {

        var openedDoc: DocumentFile? = null
        var updateList:Boolean = false
    }
}