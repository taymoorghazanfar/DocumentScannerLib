package com.example.multitoolsdocumentscanner.ui.interfaces

interface IRenameDialogListener {

    fun onRenameDialogCancelled()
    fun onRenameDialogSubmit(name:String)
}